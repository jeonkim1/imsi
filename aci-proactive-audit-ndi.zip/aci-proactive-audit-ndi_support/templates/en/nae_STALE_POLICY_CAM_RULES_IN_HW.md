<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Leaf with stale policy cam rules in hardware


The following leaf switches have stale policy cam rules.
No impact, unless the number of stale entries and Policy CAM utilization is high.

Table: Leaf Switches with stale Policy CAM rules

| Leaf |
| ---- |
{% if data_source == "ndi" %}
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "leafs" -%}
            {%- set _=table.__setitem__("leaf", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.leaf}} |
{% endfor %}
{% else %}
{% for item in event_list %}
|{{item[0].name}}|
{% endfor %}
{% endif %}

If a large number of stale entries are shown, and current impact is severe, a clean reload of the switch may clear the issue. Use caution when performing this step as other EPGs may be affected. Ensure all documentation (leaf tech support) has been collected beforehand in order for RCA to be performed. It is highly recommended to call TAC before this option is pursued.

More information about Contract configuration can be found in the [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) Whitepaper on cisco.com