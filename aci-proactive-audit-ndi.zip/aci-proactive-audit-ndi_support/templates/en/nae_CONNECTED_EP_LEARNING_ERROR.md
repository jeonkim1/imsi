<!--
category:
  - Healthcheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Endpoint information is not consistent across the fabric leafs and spines

A number of endpoints has been identified having inconsistent information across the fabric leaf and spine switches. This may cause communication to/from these endpoints to be impacted. The table below lists the endpoints affected by inconsistent information.

Table: Endpoint information is not consistent across the fabric leafs and spines

{% if data_source == "ndi" %}
| Leaf/Spine(s) | EP MAC | EP IP | Tenant | VRF | BD | EPG | Interface |
| ------------- | ------ | ----- | ------ | --- | -- | --- | --------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "macs" -%}
            {%- set _=table.__setitem__("macs", object.objectValue[0]) -%}
        {%- elif object.objectType == "bds" -%}
                {% set _=table.__setitem__("bds", object.objectValue[0]) %}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epgs", object.objectValue[0]) %}
        {%- elif object.objectType == "tenants" -%}
            {% set _=table.__setitem__("tenants", object.objectValue) %}
        {%- elif object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leafs", object.objectValue) %}
        {%- elif object.objectType == "interfaces" -%}
            {% set _=table.__setitem__("interfaces", object.objectValue[0]) %}
        {%- elif object.objectType == "encaps" -%}
            {% set _=table.__setitem__("encaps", object.objectValue[0]) %}
        {%- elif object.objectType == "ips" -%}
            {% set _=table.__setitem__("ips", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leafs|join(", ")}} | {{table.macs}} | {{table.ips}} | {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.bds}} | {{table.epgs}} | {{table.interfaces}} |
{% endfor %}
{%else%}
| Leaf/Spine(s) | EP MAC | EP IP | Tenant | VRF | BD | EPG | Interface |
| ------------- | ------ | ----- | ------ | --- | -- | --- | --------- |
{% for item in event_list %}
{% set table = dict() %}
{% set leaf_list = []%}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}

        {%- elif object.object_types[0].code == 3 -%}
            {% set _=table.__setitem__("bd", object.name) %}

        {%- elif object.object_types[0].code == 304 -%}
            {% set _=table.__setitem__("ep_mac", object.name) %}

        {%- elif object.object_types[0].code == 327 -%}
            {% set _=table.__setitem__("ep_ip", object.name) %}

        {%- elif object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}

        {%- elif object.object_types[0].code == 1 or object.object_types[0].code == 384 or object.object_types[0].code == 385 -%}
            {% set _=leaf_list.append(object.name) %}

        {%- elif object.object_types[0].code == 233 -%}
            {% set interface_components = object.identifier.split("/") %}
            {% set interface_node = " (" ~ interface_components[2] ~ ")" %}
            {% set _=interface_list.append(object.name ~ interface_node) %}
        {%- endif -%}
    {%- endfor -%}
| {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} | {% if table.ep_mac != "" %}{{ table.ep_mac }}{% else %} - {% endif %} | {% if table.ep_ip != "" %}{{ table.ep_ip }} {% else %} - {% endif %} | {{table.tenant}} | {{table.vrf}} | {{table.bd}} | {{table.epg}} | {% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %} |
{% endfor %}
{%endif%}

Inconsistent endpoint information can be due to several conditions:

* Endpoint marked as local on multiple leafs
* Endpoint is missing from COOP database on a few ACI spines switches
* Endpoint information inconsistent across vPC leafs
* IP address association to an Endpoint MAC is inconsistent across ACI spines and leafs
* Endpoint found on spine is no marked as local on any leaf
* Endpoint flag on the spine do not match those of the leaf where the Endpoint is local
* Endpoints BD information in the EPM table is different from the BD association as defined on the APIC
* Endpoints VRF information in the EPM table is different from the BD VNID allocate by the APIC
* Endpoint details on the spines have more than one NextHop Tunnel Endpoint (TEP) IP address
* Endpoint details in the global endpoint table are pointing to incorrect NextHop Tunnel Endpoint (TEP) IP address
* Endpoint has been inaccurately programmed on the spines
* A non-locally attached endpoint IP or MAC is present in the global endpoint forwarding table of a leaf but not present as a locally attached host in any of the other leafs in the fabric
* Endpoint details on Spines are pointing to incorrect NextHop Tunnel Endpoint (TEP) IP address. Note: vPC TEP is a virtual TEP.

It is recommended to check if the inconsistent endpoint information can be caused by misconfiguration like hosts with duplicated IP addresses, etc. If no obvious reason can be found, then it is recommended to open a TAC case in order to investigate the issue further.

More information about Endpoint learning can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html) available on cisco.com.
