<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Application EPG Static Port Path may not deploy

The following EPGs have static paths that may fail deployment due to an error in fabric access policy or EPG port path binding.

Table: EPG Static Port Path may not deploy

{% if data_source == "ndi" %}
| Tenant | Application Profile | EPG Name | Encapsulation |
| ------ |-------------------- | -------- | ------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- elif object.objectType == "encaps" -%}
            {% set _=table.__setitem__("encap", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.ap}} | {{table.epg}} | {{table.encap}} |
{% endfor %}
{% else %}
| Tenant | Application Profile | EPG Name | Interface Policy Group | Encapsulation |
| ------ | ------------------- | -------- | ------------------------------- | ------------- |
{% for epg in event_list %}
| {{epg.1.name}} | {{epg.2.name}} | {{epg.3.name}} | {% for entry in epg %}{% if entry.object_types.0.name == "CANDID_OBJECT_TYPE_INTERFACE_POLICY_GROUP" %}{{entry.name}}{% endif %}{% endfor %} | {{epg.0.identifier}}
{% endfor %}
{% endif %}

Note: Entries in the table above with Interface Policy Group being empty is due to the static port binding being an access interface.

It is recommended to verify the configuration of the fabric access policies and EPG port path bindings used by these EPGs.

More information about EPG configuration and design can be found in the [Endpoint Group (EPG) Usage and Design Whitepaper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-731630.html) on cisco.com.
