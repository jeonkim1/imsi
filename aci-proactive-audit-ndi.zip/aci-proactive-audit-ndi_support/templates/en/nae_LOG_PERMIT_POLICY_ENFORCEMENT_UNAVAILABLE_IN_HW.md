<!--
category:
  - Healthcheck
severity: warning
affected_count: "{{event_list|length}}"
-->

#### Configured Permit logging policy not supported on leaf switches

Leaf hardware does not support permit logging policy that is configured for number of filter subjects. The permit entries will not be logged for the leaf.

Table: Contracts and EPGs affected

| Consumer Tenant | Consumer EPG | Contract | Filter | Subject | Leaf nodes not supporting logging |
|-----------------| ------------ | -------- | ------ | ------- | -------------------------------------- |
{% for event in event_list %}
{% set leaf_list = [] %}
{% set table = dict() %}
    {% for item in event %}
        {%- for object_type in item.object_types -%}
            {%- if object_type.code == 14 -%}
                {% set _=table.__setitem__("cons_tenant", item.name) %}

            {%- elif object_type.code == 16 -%}
                {% set _=table.__setitem__("cons_epg", item.name) %}

            {%- elif object_type.code == 19 -%}
                {% set _=table.__setitem__("contract", item.name) %}

            {%- elif object_type.name == 'CANDID_OBJECT_TYPE_FILTER' -%}
                {% set _=table.__setitem__("filter", item.name) %}

            {%- elif object_type.code == 20 -%}
                {% set _=table.__setitem__("subject", item.name) %}

            {%- elif item.object_types[0].code == 384 -%}
                {% set _=leaf_list.append(item.name) %}


            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}
| {{table.cons_tenant}} | {{table.cons_epg}} | {{table.contract}} | {{table.filter}} | {{table.subject}} | {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}

It is recommended to move EPGs consuming the contract that has a permit log to EX version switched or remove permit logging from the contract policy if it is not required. Permit and Deny logging support was introduced in the "EX" model of leaf hardware. Any version of hardware from EX onward will support this feature.