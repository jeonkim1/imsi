<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Partial Configured Leaf vPC Interface with all member links having Link Down

The following leaf vPC interfaces have been partial configured for consumption by the Fabric Access Policy, but have link down on all member links.

Table: Partial Configured Leaf vPC Interface with all member links having Link Down

{% if data_source == "ndi" %}
| Interface Policy Group | Leaf |
| ---------------------- | -----|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "interfacePolicyGroups" -%}
            {%- set _=table.__setitem__("interfacePolicyGroup", object.objectValue[0]) -%}
        {%- elif object.objectType == "leafs" -%}
                {% set _=table.__setitem__("leaf", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.interfacePolicyGroup}} | {{table.leaf}} |
{% endfor %}
{% else %}
| Interface Policy Group | Leaf 1 | Leaf 2 | AAEP | Leaf Interface |
| ---------------------- | -------| ------ | ---- | -------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set node_list = []%}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 384 -%}
            {% set _=node_list.append(object.name) %}
        {%- elif object.object_types[0].code == 244 -%}
            {% set _=table.__setitem__("pc_ipg", object.name) %}
        {%- elif object.object_types[0].code == 237 -%}
            {% set _=table.__setitem__("aap", object.name) %}
        {%- elif object.object_types[0].code == 233 -%}
            {% set interface_components = object.identifier.split("/") %}
            {% set interface_node = " (" ~ interface_components[2] ~ ")" %}
            {% set _=interface_list.append(object.name ~ interface_node) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.pc_ipg}} | {{node_list[0]}} | {{node_list[1]}} | {{table.aap}} |{% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

Best practice is to keep an partially configured Virtual Port Channel administratively disabled but this VPC is operationally down.
Sugested Next Steps:

1. Determine if the issue is related to Leaf Deployment status and check
* if the APIC and Leaf have the same version
* determine if the interface(s) in question are configured with the right set of fabric access policies. Check for static or dynamic path binding errors associated with this interface

2. Check the port status reason and if the problem appears to be with the port then do the following based on the status

* Suspend: There are multiple reasons for suspend state. Most common one is suspend-due-to-no-lacp-pdu so check that LACP is enabled on the other side, PDU mismatch with the other port, cabling or channeling mismatch. Other issues causing suspend state include:  suspended-due-to-minlinks, suspended-by-vpc, hot-standby-in-bundle
* Error Disable: There are multiple reason for err-disable. If it is epm-err-disable this may be due to likely EP move/flap and check epm logs or event. Check the cable to see if it is damaged or if there are transceiver issues. Other problems related to Error Disable condition include: mcp-loop-err-disable, handshake-fail-errdisable, hw-fail, diag-failure-errdisable, pause-rate-limit-err-disable, dot1x-security-errdisable
* Link Failure: So check the fiber or transceiver or copper ports for L1 issues. Other problems related to link failures include: sfp-missing, sfp-speed-mismatch, xcvr-invalid
* Others: Check the details of the port on the Leaf with the error condition

3. If the problem persists then collect the techsupport and call TAC

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)
