<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
affected_count: "{{event_list|length}}"
-->

#### Exclusion from Preferred Group Violation


For given VRFs that are in enforced mode and enabled Preferred Group feature, implicit rules to deny traffic of excluded EPGs are not programmed correctly on the leaf.
This could be due to a rule not being present or a higher priority stale rule.
The impact is that some or all of EPGs excluded from the preferred group are able to communicate with other EPGs in the VRF.

Table: Leaf Switches with Policy Violation

| Tenant | VRF | Leaf switches affected |
| ------ | --- | ---------------------- |
{% for event in event_list %}
{% set leaf_list = [] %}
{% set table = dict() %}
    {%- for object in event -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
               {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object_type.code == 384 -%}
                {% set _=leaf_list.append(object.name) %}

            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{ table.tenant }} | {{ table.vrf }} | {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}

It is likely a programming issue within switch Hardware Abstraction Layer (HAL). It is recommended to collect a techsupport from leaf switches and contact Cisco TAC for assistance with Root Cause Analysis (RCA) and providing a workaround.

More information about Contract configuration can be found in the [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) Whitepaper on cisco.com
