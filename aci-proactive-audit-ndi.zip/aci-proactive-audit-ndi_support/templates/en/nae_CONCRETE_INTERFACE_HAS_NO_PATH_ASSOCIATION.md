<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Concrete interface has no path association

An interface of a concrete device has no association to a path endpoint.
Impact is that the device cannot be deployed.

Table: Concrete interface with no path association
{% if data_source == "ndi" %}
| Tenant | Cluster | Concrete Device | Concrete Interface |
| ------ | ------- | --------------- | ------------------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "concreteInterface" -%}
            {%- set _=table.__setitem__("concreteInterface", object.objectValue[0][1:-1]) -%}
        {%- endif -%}
    {%- endfor -%}
| | | | {{table.concreteInterface}} |
{% endfor %}
{% else %}
| Tenant | Cluster | Concrete Device | Concrete Interface |
| ------ | ------- | --------------- | ------------------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 486 -%}
            {% set _=table.__setitem__("cluster", object.name) %}
        {%- elif object.object_types[0].code == 488 -%}
            {% set _=table.__setitem__("device", object.name) %}
        {%- elif object.object_types[0].code == 489 -%}
            {% set _=table.__setitem__("interface", object.name) %}

        {%- endif -%}

    {%- endfor -%}
| {{table.tenant}} | {{table.cluster}} | {{table.device}} | {{table.interface}} |
{% endfor %}
{% endif %}

Suggested remediation steps:

* Navigate to the concrete interface.
* Navigate to the Path drop down
* Select the desired path.

More information about service graphs configuration can be found in the [Cisco APIC Layer 4 to Layer 7 Services Deployment Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-4-to-layer-7-services-configuration/cisco-apic-layer-4-to-layer-7-services-deployment-guide-52x.html)
