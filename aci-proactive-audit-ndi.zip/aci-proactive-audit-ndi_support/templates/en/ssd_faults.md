<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
{% set count = namespace(value = 0) %}
{% set count.value = count.value + affected_nodes.critical|length %}
{% set count.value = count.value + affected_nodes.major|length %}
affected_count: {{count.value}}
-->

### APIC and Switch SSD (smartctl based findings)

The one or more nodes in the fabric are affected by SSD fault(s).

Table: Nodes with SSD faults

| Node | SSD Fault Severity |
| ---- | ------------------ |
{% for node in affected_nodes.critical %}
| {{node}} | Critical |
{% endfor %}
{% for node in affected_nodes.major %}
| {{node}} | Major |
{% endfor %}

It is recommended to open a TAC case in order to investigate fault(s) and possible RMA the affected devices.

More information about SSD faults in ACI can be found in [Field Notice - 70538](https://www.cisco.com/c/en/us/support/docs/field-notices/705/fn70538.html) and the [ACI Switch Node SSD Lifetime Explained](https://www.cisco.com/c/en/us/support/docs/software/aci-data-center/215167-aci-switch-node-ssd-lifetime-explained.html) TechNote both available on cisco.com.
