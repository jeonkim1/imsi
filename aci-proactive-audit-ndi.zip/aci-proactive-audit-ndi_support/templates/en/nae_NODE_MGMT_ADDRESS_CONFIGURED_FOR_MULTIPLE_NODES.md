<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Duplicate Management IP Address

Duplicate management IP address has been configured for the following nodes.

Table: Duplicate management IP addresses

{% if data_source == "ndi" %}
| Tenant | VRF    | Mgmt IP |
| ------ | ------ | ------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {%- set _=table.__setitem__("vrfs", object.objectValue) -%}
        {%- elif object.objectType == "subnet" -%}
            {%- set _=table.__setitem__("subnet", object.objectValue) -%}
        {%- elif object.objectType == "fabricIP" -%}
            {%- set _=table.__setitem__("fabricIP", object.objectValue) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.subnet|join(", ")}} |
{% endfor %}
{% else %}
| Tenant | VRF    | IP Address | Nodes |
| ------ | ------ | ---------- | ----- |
{% for addr in event_list %}
| {{addr.2.name}} | {{addr.1.name}} | {{addr.0.name}} | {% for node in addr %}{% if node.object_types.0.name == "CANDID_OBJECT_TYPE_TOPOLOGY_NODE" %}{{node.name}}, {% endif %}{% endfor %} |
{% endfor %}
{% endif %}

It is recommended to verify the management IP configuration for these nodes.

More information about EPG configuration and design can be found in the [Cisco APIC and Static Management Access TechNote](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/kb/b_KB_Configuring_Static_Management_Access.html) on cisco.com.
