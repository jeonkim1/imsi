<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Contract Subject has no Filters

The following contract subjects are not associated with a contract filter. The subject will therefore not have any impact on the contract. If these are the only subjects in the contract, the contract is invalid.

Table: Contract Subject with no Filter

{% if data_source == "ndi" %}

| Tenant | Contract |
| ------ | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "contracts" -%}
                {% set _=table.__setitem__("contract", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.contract}} |
{% endfor %}
{% else %}

| Tenant | Contract | Subject | Provider EPG(s) | Consumer EPG(s) |
| ------ |--------- | ------- | --------------- | --------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set consumer_epg_list = [] %}
{% set provider_epg_list = [] %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 20 -%}
                {% set subject_components = object.identifier.split("/") %}
                {% set _=table.__setitem__("subject", object.name) %}
                {%- if subject_components[1][0:3] == "tn-" -%}
                    {% set _=table.__setitem__("tenant", subject_components[1][3:]) %}
                {%- else -%}
                    {% set _=table.__setitem__("tenant", "") %}
                {%- endif -%}

            {%- elif object_type.code == 19 -%}
                {% set _=table.__setitem__("contract", object.name) %}
            {%- endif -%}
            {%- if object_type.code == 11 -%}
                {% set provider_entry = dict() %}
                {% set provider_components = object.identifier.split("/") %}
                {% set _=provider_entry.__setitem__("epg_name", object.name) %}
                {%- if provider_components[1][0:3] == "tn-" -%}
                    {% set _=provider_entry.__setitem__("epg_tenant", provider_components[1][3:]) %}
                {%- else -%}
                    {% set _=provider_entry.__setitem__("epg_tenant", "") %}
                {%- endif -%}
                {% set _=provider_epg_list.append(provider_entry) %}
            {%- endif -%}
            {%- if object_type.code == 16 -%}
                {% set consumer_entry = dict() %}
                {% set consumer_components = object.identifier.split("/") %}
                {% set _=consumer_entry.__setitem__("epg_name", object.name) %}
                {%- if consumer_components[1][0:3] == "tn-" -%}
                    {% set _=consumer_entry.__setitem__("epg_tenant", consumer_components[1][3:]) %}
                {%- else -%}
                    {% set _=consumer_entry.__setitem__("epg_tenant", "") %}
                {%- endif -%}
                {% set _=consumer_epg_list.append(consumer_entry) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.contract}} | {{table.subject}} | {% if provider_epg_list|length > 1 %} {% for entry in provider_epg_list %} {{entry.epg_name}} (tenant: {{entry.epg_tenant}}), {% endfor %} {% elif provider_epg_list|length == 1 %} {{provider_epg_list[0].epg_name}} (tenant: {{provider_epg_list[0].epg_tenant}}) {% else %} {% endif %} | {% if consumer_epg_list|length > 1 %} {% for entry in consumer_epg_list %} {{entry.epg_name}} (tenant: {{entry.epg_tenant}}), {% endfor %} {% elif consumer_epg_list|length == 1 %} {{consumer_epg_list[0].epg_name}} (tenant: {{consumer_epg_list[0].epg_tenant}}) {% else %} {% endif %} |
{% endfor %}

{%- endif -%}

If these subjects are supposed to be used, then it is recommended to associate them with the correct filter. If they are not supposed to be used, then it is recommended to remove subject from the contract to simplify the configuration.

More information about Contract configuration can be found in the [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) Whitepaper on cisco.com
