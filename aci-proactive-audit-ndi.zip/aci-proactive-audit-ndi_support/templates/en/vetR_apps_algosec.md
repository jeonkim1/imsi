<!--
category:
  - Best_Practice
  - Upgradecheck
severity: warning
affected_count: 1
-->

### Disable Algosec Application(s) prior to Software Upgrade

Before attempting any software upgrade of the ACI fabric **must** the following applications from the ACI App Center be deactivated/removed:

- The ConnectivityCompliance APIC App by AlgoSec
- The AlgoSec Firewall Analyzer
- Any other application that may be sending "uribv4Nexthop.type" queries

Failure to deactivating/removing these applications prior to upgrading may lead to loss of connectivity due to bug id [CSCvv12524](https://bst.cloudapps.cisco.com/bugsearch/bug/CSCvv12524).
