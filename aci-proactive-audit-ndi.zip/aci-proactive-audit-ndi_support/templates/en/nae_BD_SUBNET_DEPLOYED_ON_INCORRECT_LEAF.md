<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Bridge Domain Subnet that should not exist on a leaf switch(es) is present

The following bridge domain subnet(s) that should not exist on a leaf switch(es) are present:

Table: Bridge Domain Subnets(s) that should not exist on a leaf switch(es) are present

| Tenant | Configured VRF | Bridge Domain | Subnet | Leaf Switch |
| ------ | -------------- | ------------- | ------ | ----------- |
{% if data_source == "ndi" %}
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "vrfs" -%}
            {%- set _=table.__setitem__("vrf", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "bds" -%}
            {%- set _=table.__setitem__("bd", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "subnet" -%}
            {%- set _=table.__setitem__("subnet", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "leafs" -%}
            {%- set _=table.__setitem__("leaf", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.bd}} | {{table.subnet}} | {{table.leaf}} |
{% endfor %}
{% else %}
{% for bd in event_list %}
| {{bd.2.name}} | {{bd.1.name}} | {{bd.3.name}} | {{bd.0.name}} | {{bd.4.name}} |
{% endfor %}
{% endif %}

It is recommended to verify the configuration of these bridge domains, as the current forwarding behavior may not match the intended behavior.

More information about Bridge Domain configuration can be found in the [Cisco API Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_010.html)
