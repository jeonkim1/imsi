<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### External Bridge Domain Subnet with no Contract relationship to associated L3Out

The following Bridge Domain (BD) Subnet(s) are associated with one or more L3Outs, but do not have a contract relationship with External EPG(s) belonging to these L3Outs. This results in the BD subnet not being advertised on these L3Outs.

Table: External Bridge Domain Subnet with no Contract relationship to associated L3Out

{% if data_source == "ndi" %}
| Subnet | Tenant | VRF |
|------- | ------ | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- elif object.objectType == "subnet" -%}
                {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {% if table.subnet|length > 1 %} {{table.subnet|join(", ")}} {% else %} {{table.subnet[0]}} {% endif %} | {{table.tenant}} | {{table.vrf}} |
{% endfor %}
{% else %}
| Subnet | Tenant | VRF | BD | EPG(s) associated with BD | L3Out(s) | External EPG(s) |
|------- | ------ | --- | -- | ------------------------- | -------- | --------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set l3out_list = [] %}
{% set external_epg_list = [] %}
{% set epg_list = [] %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 3 -%}
                {% set bd_components = object.identifier.split("/") %}
                {% set _=table.__setitem__("bd", object.name) %}
                {% set _=table.__setitem__("tenant", bd_components[1][3:]) %}
            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}
            {%- elif object_type.code == 7 -%}
                {% set epg_components = object.identifier.split("/") %}
                {% if epg_components[2][:4] == "ctx-" %}
                    {% set _=external_epg_list.append(object.name ~ " (vzAny)") %}
                    {% set _=epg_list.append(object.name ~ " (vzAny)") %}
                {% elif epg_components[2][:4] == "out-" %}
                    {% set _=external_epg_list.append(object.name) %}
                {% else %}
                    {% set _=epg_list.append(object.name) %}
                {% endif %}
            {%- elif object_type.code == 28 -%}
                {% set _=l3out_list.append(object.name) %}
            {%- elif object_type.code == 253 -%}
                {% set _=table.__setitem__("subnet", object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{table.subnet}} | {{table.tenant}} | {{table.vrf}} | {{table.bd}} | {% if epg_list|length > 1 %} {{epg_list|join(", ")}} {% else %} {{epg_list[0]}} {% endif %} | {% if l3out_list|length > 1 %} {{l3out_list|join(", ")}} {% else %} {{l3out_list[0]}} {% endif %} | {% if external_epg_list|length > 1 %} {{external_epg_list|join(", ")}} {% else %} {{external_epg_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

It is recommended to use the following steps to investigate the issue:

1. Determine if the subnet(s) needs to be advertised to the L3Out(s) in question
2. If not, then remove the L3Out association from the BD
3. if yes, then determine the right EPG(s) that should be communicating with the corresponding external EPG(s) and use an existing contract or create a new contract as appropriate to enable the communication

More information about bridge domain configuration can be found in the [Cisco ACI Layer 2 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_010.html) available on cisco.com.
