<!--
category:
  - Best_Practice
severity: warning
affected_count: 1
-->

### Rogue Endpoint Control

Rogue EP Control was first introduced in APIC Release 3.2(1l). This configuration is disabled by default to keep the same behavior as previous releases.

This option is located at System > System Settings > Endpoint Controls > Rogue EP Control

Rogue EP Control is used to detect an endpoint that moves frequently and to disable endpoint learning for the particular endpoint. When a leaf node identifies an endpoint as rogue, the endpoint becomes a static endpoint temporarily and will be deleted after the hold interval, so that rapid endpoint movement across different locations can be prevented.

Detection criteria can be configured by using the following values:

- Rogue EP Detection interval: to specify the time in seconds to detect rogue endpoints. The default is 60 seconds. The supported range is 30 to 3600 seconds.
- Rogue EP Detection Multiplication Factor: The endpoint is declared rogue if the endpoint moves more than this number within the Rogue EP Detection interval. The default is 4. The supported range is 2 to 10.
- Hold Interval: the amount of time the endpoint is being handled as rogue and kept as the static endpoint. After this interval, the endpoint is deleted. The default is 1800 seconds. The supported range is 1800 to 3600.

More information about Rouge Endpoint Control can be found in the [Rouge Endpoint Control](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html#RogueEPControl) available on cisco.com.
