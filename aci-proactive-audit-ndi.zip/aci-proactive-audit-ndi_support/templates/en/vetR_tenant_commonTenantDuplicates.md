<!--
category:
  - Best_Practice
severity: notice
{% set count = namespace(value = 0) %}
{% set count.value = count.value + dupVRFs|length %}
{% set count.value = count.value + dupBDs|length %}
{% set count.value = count.value + dupContracts|length %}
{% set count.value = count.value + dupFilters|length %}
affected_count: {{count.value}}
-->

### Duplicate Object Names between common and user Tenants

Cisco ACI is based upon the managed object (MO) model, where each object requires a name. A clear and consistent naming convention is therefore essential to aid manageability and troubleshooting. Any change in naming convention for any MO such as profiles or policies requires disruption.

The following objects has a duplicate name with a object in the common tenant, although this may be a valid configuration does this very easily lead to unexpected behaviors as the common tenant may be used to resolve references to objects not defined in the user tenant.

{% if dupVRFs|length > 0 %}
Table: VRFs with Duplicated Object Name between common and user Tenants

| Tenant | VRF |
| ------ | --- |
{% for entry in dupVRFs %}
{% set entry_components = entry.split("/") %}
{% set tenant = entry_components[1] %}
{% set tenant_components = tenant.split("-") %}
{% set name = entry_components[2] %}
{% set name_components = name.split("-") %}
| {{tenant_components[1:]|join("-")}} |{{name_components[1:]|join("-")}} |
{% endfor %}
{% endif %}

{% if dupBDs|length > 0 %}
Table: BDs with Duplicated Object Name between common and user Tenants

| Tenant | BD |
| ------ | -- |
{% for entry in dupBDs %}
{% set entry_components = entry.split("/") %}
{% set tenant = entry_components[1][3:] %}
{% set name = entry_components[2][3:] %}
| {{tenant}} | {{name}} |
{% endfor %}
{% endif %}

{% if dupContracts|length > 0 %}
Table: Contracts with Duplicated Object Name between common and user Tenants

| Tenant | Contract |
| ------ | -------- |
{% for entry in dupContracts %}
{% set entry_components = entry.split("/") %}
{% set tenant = entry_components[1] %}
{% set tenant_components = tenant.split("-") %}
{% set name = entry_components[2] %}
{% set name_components = name.split("-") %}
| {{tenant_components[1:]|join("-")}} |{{name_components[1:]|join("-")}} |
{% endfor %}
{% endif %}

{% if dupFilters|length > 0 %}
Table: Filters with Duplicated Object Name between common and user Tenants

| Tenant | Filters |
| ------ | ------- |
{% for entry in dupFilters %}
{% set entry_components = entry.split("/") %}
{% set tenant = entry_components[1] %}
{% set tenant_components = tenant.split("-") %}
{% set name = entry_components[2] %}
{% set name_components = name.split("-") %}
| {{tenant_components[1:]|join("-")}} |{{name_components[1:]|join("-")}} |
{% endfor %}
{% endif %}

Note: In case a duplicated is listed above for the 'default' bridge domain within the 'infra' tenant, can this one safely be ignored.

We recommended that you plan ahead and define the policy naming convention before deploying the ACI fabric to ensure that all policies are named consistently and that there are not duplication of object names between common and user tenants.

More information about object naming can be found in the [Cisco ACI Object Naming and Numbering: Best Practices Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/kb/b-Cisco-ACI-Naming-and-Numbering.html) on cisco.com.
