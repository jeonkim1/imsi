<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Configured Leaf Interface has Link Down

The following leaf interfaces has been configured for consumption by the Fabric Access Policy, but have link down.

Table: Configured Leaf Interface has Link Down

{% if data_source == "ndi" %}
| Leaf | Interface |
| ---- | --------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leaf", object.objectValue[0]) %}
        {%- elif object.objectType == "interfaces" -%}
            {% set _=table.__setitem__("interface", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leaf}} | {{table.interface}} |
{% endfor %}
{% else %}
| Leaf | Interface |Associated Interface Policy Group | Associated Interface Profile | Associated AAEP |
| ---- | --------- | --------------------------------- | ---------------------------- | --------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set consumer_epg_list = [] %}
{% set provider_epg_list = [] %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 233 -%}
                {% set _=table.__setitem__("interface", object.name) %}
            {%- elif object_type.code == 234 -%}
                {% set _=table.__setitem__("interface_profile", object.name) %}
            {%- elif object_type.code == 237 -%}
                {% set _=table.__setitem__("aaep", object.name) %}
            {%- elif object_type.code == 244 -%}
                {% set _=table.__setitem__("interface_policy_group", object.name) %}
            {%- elif object_type.code == 384 -%}
                {% set _=table.__setitem__("leaf", object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{table.leaf}} | {{table.interface}} | {{table.interface_policy_group}} | {{table.interface_profile}} | {{table.aaep}} |
{% endfor %}
{% endif %}

If these interfaces are supposed to be in used, then it is recommended investigate why they have link down.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)
