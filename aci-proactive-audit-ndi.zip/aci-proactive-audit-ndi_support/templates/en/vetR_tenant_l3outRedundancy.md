<!--
category:
  - Best_Practice
  - Upgradecheck
severity: notice
affected_count: "{{nonRedundantL3outs|length}}"
-->

### L3Out Redundancy

It is generally recommended to configure L3Outs across at least two nodes. This will ensure redundancy during upgrades and in the event of a border leaf failure. Although this is a general best practice, there are designs where this is not necessary, e.g. redundancy provided across separate L3Outs.

Table: L3Out Redundancy

| Tenant | L3Out Name |
| ------ | ---------- |
{% for entry in nonRedundantL3outs %}
| {{entry.tenant}} | {{entry.l3out}} |
{% endfor %}

Please reference the [ACI Fabric L3Out Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) for information about how to configure L3Outs
