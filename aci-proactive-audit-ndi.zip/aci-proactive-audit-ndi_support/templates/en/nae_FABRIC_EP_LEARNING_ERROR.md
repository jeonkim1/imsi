<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Fabric Endpoint Learning Error

Endpoint information is not consistent across the fabric leafs and spines. The failing condition is that the EndPoint found on Spine is not marked as local on any Leaf.
This may cause communication to/from these endpoints to be impacted.

Table: Spines with Endpoint Inconsistent Information

{% if data_source == "ndi" %}
| Spine(s) | EP MAC | EP IP | Tenant | VRF |
| -------- | ------ | ----- | ------ | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "ips" -%}
            {%- set _=table.__setitem__("ips", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrfs", object.objectValue[0]) %}
        {%- elif object.objectType == "tenants" -%}
            {% set _=table.__setitem__("tenants", object.objectValue[0]) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bds", object.objectValue[0]) %}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3Outs", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| | | {{table.ips}} | {{table.tenants}} | {{table.vrfs}} |
{% endfor %}
{% else %}
| Spine(s) | EP MAC | EP IP | Tenant | VRF |
| -------- | ------ | ----- | ------ | --- |
{% for item in event_list %}
{% set table = dict() %}
{% set _=table.__setitem__("ep_mac", "") %}
{% set _=table.__setitem__("ep_ip", "") %}
{% set spine_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}

        {%- elif object.object_types[0].code == 304 -%}
            {% set _=table.__setitem__("ep_mac", object.name) %}

        {%- elif object.object_types[0].code == 327 -%}
            {% set _=table.__setitem__("ep_ip", object.name) %}

        {%- elif object.object_types[0].code == 1 or object.object_types[0].code == 385 -%}
            {% set _=spine_list.append(object.name) %}

        {%- endif -%}

    {%- endfor -%}
| {% if spine_list|length > 1 %} {{spine_list|join(", ")}} {% else %} {{spine_list[0]}} {% endif %} | {% if table.ep_mac != "" %} {{ table.ep_mac }} {% else %} - {% endif %} | {% if table.ep_ip != "" %}{{ table.ep_ip }} {% else %} - {% endif %} | {{table.tenant}} | {{table.vrf}} |
{% endfor %}
{% endif %}
Suggested next steps:

1. Identify the spines where EndPoint is learnt incorrectly.
2. Login into the APIC UI and verify that the endpoint is present on the spines shown by going to: Fabric→Inventory→Pod#→SpineName→Protocols→COOP→Coop for VRF-overlay-1→EndPoint Database and then search for the endpoint in question.
3. Collect a techsupport from each APIC, each affected spine where the endpoint is incorrectly learned. Also open a case with Cisco TAC and provide the collected logs and this event detail as supporting information.

More information about Endpoint learning can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html) available on cisco.com.
