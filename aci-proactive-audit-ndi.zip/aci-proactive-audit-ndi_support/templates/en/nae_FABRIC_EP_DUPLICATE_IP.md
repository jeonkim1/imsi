<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
affected_count: "{{event_list|length}}"
-->

#### Fabric Endpoint Duplicate IP

IP addresses are in use by multiple MAC addresses within the same VRF. Multiple MACs sharing a single IP address will cause intermittent connectivity issues.

The follow IP Endpoints are associated with two or more MAC addresses.

Table: Endpoint with Duplicate IP

| Tenant | VRF | BD | Endpoint IP | Interface where EP is Learnt |
| ------ | --- |--- | ----------- | ---------------------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set if_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 3 -%}
            {% set _=table.__setitem__("bd", object.name) %}

        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}

        {%- elif object.object_types[0].code == 327 -%}
            {% set _=table.__setitem__("ep_ip", object.name) %}

        {%- elif object.object_types[0].code == 1 or object.object_types[0].code == 384 -%}
            {% set if_components = object.identifier.split("/") %}
            {% set if_node = if_components[2][5:] %}
            {% set if_entry = object.name ~ " (node " ~ if_node ~ ")" %}
            {% set _=if_list.append(if_entry) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.bd}} | {{table.ep_ip}} | {% if if_list|length > 1 %}{{if_list|join(", ")}}{% else %}{{if_list[0]}}{% endif %} |
{% endfor %}

Suggested next steps:

1. Login into the APIC UI and verify the presence of the endpoint(s)
2. Identify the endpoint(s) that actual own the IP address and change the IP address on the host/device that has the incorrect IP address
3. Clear the endpoint on the leaf by opening an SSH session to each leaf and by entering the following command: leaf# clear system internal epm endpoint command

More information about Endpoint learning can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html) available on cisco.com.
