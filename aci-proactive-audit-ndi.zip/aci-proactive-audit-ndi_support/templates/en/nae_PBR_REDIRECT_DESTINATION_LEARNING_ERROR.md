<!--
category:
  - Healthcheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### PBR Redirect Destination Learning Error

The PBR redirect destination(s) listed in the table below has not been learned by the fabric, which means that traffic to this destination will be dropped.

Table: PBR Redirect Destination Learning Error
{% if data_source == "ndi" %}
| MAC Address | Bridge Domain | Logical Interface Context |
| ----------- | ------------- | ------------------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "logicalInterfaceContext" -%}
            {%- set _=table.__setitem__("logicalInterfaceContext", object.objectValue) -%}
        {%- elif object.objectType == "macs" -%}
                {% set _=table.__setitem__("macs", object.objectValue) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bds", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.macs|join(", ")}} | {{table.bds|join(", ")}} | {{table.logicalInterfaceContext|join(", ")}} |
{% endfor %}
{% else %}
| MAC Address | Tenant | Bridge Domain | Logical Interface Context | Device Selection Policy |
| ----------- | ------ | ------------- | ------------------------- | ----------------------- |
{% for entry in event_list %}
| {{entry.3.name}} | {{entry.2.name}} | {{entry.4.name}} | {{entry.0.name}} | {{entry.1.name}} |
{% endfor %}
{% endif %}

It is recommended to review the configuration of the PBR service graph configuration to find the reason why the PBR redirect destination has not been learnt by the fabric.

More information about PBR service graph can be found in the [Cisco ACI Policy-Based Redirect Service Graph Design White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739971.html)
