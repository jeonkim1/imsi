<!--
category:
  - Best_Practice
severity: notice
affected_count: "{{egressVRFs|length}}"
-->

### VRF Policy Enforcement Direction

The Policy Control Enforcement Direction option was introduced in APIC Release 1.2(1) and is a feature to save TCAM resources for contracts on boarder leaf switches. Thus, it affects only traffic to or from the L3Out. There are no behavior changes in EPG-to-EPG traffic based on this option.

With Policy Control Enforcement Direction can be set to either *Egress* or *Ingress*. When direction is set to *Egress*, the contract rules for an L3Out are deployed on both border-leaf and non–border-leaf switches. In this situation, when there are many EPGs that need to talk to the L3Out, the TCAM resources for contracts on border leaf switches could be a bottle neck because a border leaf deploys all contracts while contracts on non–border leaf switches are typically distributed to multiple leaf switches. However, when set to *Ingress*, the contract rules are deployed only on non-border leaf switches; hence, this resolves the concern about TCAM resources for contracts on border leaf switches.

The table below lists the VRFs in the fabric that are configured with *egress* policy enforcement direction.

Table: VRFs with Egress Policy Enforcement Direction

| Tenant | VRF |
| ------ | --- |
{% for entry in egressVRFs %}
| {{entry.tenant}} | {{entry.name}}
{% endfor %}

It is recommended to review the configuration of the VRFs to verify if they require *egress* policy enforcement or this is a configuration mistake or due to the VRFs being configured prior to the fabric running ACI 1.2(1) or later. Where possible is it recommended to change the enforcement direction to *ingress* in order to avoid running into potential TCAM bottle neck issues on the border leafs.

More information about Policy Control Enforcement Direction can be found in the [Cisco ACI L3Out Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) and the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html), both available on cisco.com.
