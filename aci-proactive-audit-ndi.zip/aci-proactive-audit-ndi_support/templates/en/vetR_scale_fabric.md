<!--
category:
  - Best_Practice
  - Upgradecheck
capacity: Limit
severity: warning
affected_count: 1
-->

### Fabric Wide Scalability

One or more of the fabric wide scale metrics are exceeding the supported scalability limits.

Table: Fabric Wide Scalability

|   | Endpoints | Tenants | VRFs | BDs | EPGs | Contracts | Filters |
| - | --------- | ------- | ---- | --- | ---- | --------- | ------- |
| Count | {{endpoints.count}} | {{tenants.count}} | {{vrfs.count}} | {{bds.count}} | {{epgs.count}} | {{contracts.count}} | {{filters.count}} |
| Limit | {{endpoints.limit}} | {{tenants.limit}} | {{vrfs.limit}} | {{bds.limit}} | {{epgs.limit}} | {{contracts.limit}} | {{filters.limit}} |

More information about ACI scalability can be found in the section "Verified Scalability Guide" on the [Cisco ACI Support Page](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/tsd-products-support-series-home.html) on cisco.com.
