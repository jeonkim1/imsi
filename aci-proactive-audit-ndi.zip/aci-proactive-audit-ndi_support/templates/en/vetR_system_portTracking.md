<!--
category:
  - Best_Practice
severity: notice
affected_count: 1
-->

### Port Tracking

The Port Tracking feature addresses a scenario where a leaf node may lose connectivity to the spine node and where hosts connected to the affected leaf node in an active/standby manner may not be aware of the failure.

It is recommended to enable the Port Tracking feature - especially if hosts using active/standby NIC teaming are connected to the fabric. Additionally, a port tracking setting of 0 uplinks is recommended as a general best practice. This will keep front-facing interfaces in a down state while there are no uplinks from a leaf, preventing some hosts from forwarding on an inactive interface.

Please note that the preferred host connectivity to the ACI fabric is vPC wherever possible.

More information about Port Tracking can be found in the [Cisco ACI Design Guide](https://www.cisco.com/c/en/us/td/docs/dcn/whitepapers/cisco-application-centric-infrastructure-design-guide.html#Porttracking) available on cisco.com.
