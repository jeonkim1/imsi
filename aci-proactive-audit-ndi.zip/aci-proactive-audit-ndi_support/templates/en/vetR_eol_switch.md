<!--
category:
  - Best_Practice
  - Upgradecheck
severity: notice
{% set count = namespace(value = 0) %}
{% for hw_model in eolDetails %}
{% set count.value = count.value + eolDetails[hw_model].devices | length %}
{% endfor %}
affected_count: {{count.value}}
-->

### Switch Refresh

One or more of the switches used in the fabric are affected by an End of Life announce (EoL).

Table: Switch End-of-Life

| Switch Model | Device Count | EoL Date | EoL URL |
| ------------ | ------------ | -------- | ------- |
{% for hw_model in eolDetails %}
| {{ hw_model }} | {{ eolDetails[hw_model].devices | length }} | {{ eolDetails[hw_model].announcementDate }} | [{{ eolDetails[hw_model].url }}]({{ eolDetails[hw_model].url }}) |
{% endfor %}

It is recommended to include the switches in upcoming life cycle management activities.
