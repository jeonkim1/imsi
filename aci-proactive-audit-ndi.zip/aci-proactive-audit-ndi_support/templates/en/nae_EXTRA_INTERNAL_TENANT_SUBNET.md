<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
affected_count: "{{event_list|length}}"
-->

#### Stale subnet in VRF routing table

The leaf routing table for following VRFs contains one or more subnets which should no longer be present.

Table: Stale subnets present in VRF routing table

| Tenant | VRF | Subnet | Leaf switches affected |
| ------ | --- |--------| ---------------------- |
{% for event in event_list %}
{% set leaf_list = [] %}
{% set table = dict() %}
    {%- for object in event -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
               {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object_type.code == 253 -%}
                {% set _=table.__setitem__("subnet", object.name) %}

            {%- elif object_type.code == 384 -%}
                {% set _=leaf_list.append(object.name) %}

            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{ table.tenant }} | {{ table.vrf }} | {{ table.subnet }} | {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}

It is recommended to collect a techsupport from leaf switches and contact Cisco TAC for assistance with Root Cause Analysis (RCA) and for a workaround. Do not proceed with reloading a leaf switch unless there is current, sever impact on connectivity caused by this issue. 

More information on IP learning can be found in [ACI Fabric Endpoint Learning](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html) on cisco.com.