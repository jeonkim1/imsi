<!--
category:
  - Optimization
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Redundant Permit Policies between EPGs

The following EPGs have been configured with redundant permit policies.

Table: Redundant Permit Policies between EPGs

{% if data_source == "ndi" %}
| Provider EPG(s) | Consumer EPG(s) | Contract | Filter |
| --------------- |---------------- | -------- | ------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "providerEpgs" -%}
            {%- set _=table.__setitem__("providerEpgs", object.objectValue) -%}
        {%- elif object.objectType == "consumerEpgs" -%}
                {% set _=table.__setitem__("consumerEpgs", object.objectValue) %}
        {%- elif object.objectType == "contracts" -%}
            {% set _=table.__setitem__("contracts", object.objectValue) %}
        {%- elif object.objectType == "filters" -%}
            {% set _=table.__setitem__("filters", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.providerEpgs|join(", ")}} | {{table.consumerEpgs|join(", ")}} | {{table.contracts|join(", ")}} | {{table.filters|join(", ")}} |
{% endfor %}
{% else %}
| Provider EPG(s) | Consumer EPG(s) | Tenant (Contract)| Contract | Subject | Filter |
| --------------- |---------------- | ---------------- | -------- | ------- | ------ |
{% for item in event_list %}
{% set table = dict() %}
{% set consumer_epg_list = [] %}
{% set provider_epg_list = [] %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 20 -%}
                {% set subject_components = object.identifier.split("/") %}
                {% set _=table.__setitem__("subject", object.name) %}
                {%- if subject_components[1][0:3] == "tn-" -%}
                    {% set _=table.__setitem__("tenant", subject_components[1][3:]) %}
                {%- else -%}
                    {% set _=table.__setitem__("tenant", "") %}
                {%- endif -%}

            {%- elif object_type.code == 19 -%}
                {% set _=table.__setitem__("contract", object.name) %}

            {%- elif object_type.code == 21 -%}
                {% set _=table.__setitem__("filter", object.name) %}

            {%- endif -%}
            {%- if object_type.code == 11 -%}
                {% set provider_entry = dict() %}
                {% set provider_components = object.identifier.split("/") %}
                {% set _=provider_entry.__setitem__("epg_name", object.name) %}
                {%- if provider_components[1][0:3] == "tn-" -%}
                    {% set _=provider_entry.__setitem__("epg_tenant", provider_components[1][3:]) %}
                {%- else -%}
                    {% set _=provider_entry.__setitem__("epg_tenant", "") %}
                {%- endif -%}
                {% set _=provider_epg_list.append(provider_entry) %}
            {%- endif -%}
            {%- if object_type.code == 16 -%}
                {% set consumer_entry = dict() %}
                {% set consumer_components = object.identifier.split("/") %}
                {% set _=consumer_entry.__setitem__("epg_name", object.name) %}
                {%- if consumer_components[1][0:3] == "tn-" -%}
                    {% set _=consumer_entry.__setitem__("epg_tenant", consumer_components[1][3:]) %}
                {%- else -%}
                    {% set _=consumer_entry.__setitem__("epg_tenant", "") %}
                {%- endif -%}
                {% set _=consumer_epg_list.append(consumer_entry) %}
            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}

| {% if provider_epg_list|length > 1 %} {% for entry in provider_epg_list %} {{entry.epg_name}} (tenant: {{entry.epg_tenant}}), {% endfor %} {% else %} {{provider_epg_list[0].epg_name}} (tenant: {{provider_epg_list[0].epg_tenant}}) {% endif %} |  {% if consumer_epg_list|length > 1 %} {% for entry in consumer_epg_list %} {{entry.epg_name}} (tenant: {{entry.epg_tenant}}), {% endfor %} {% else %} {{consumer_epg_list[0].epg_name}} (tenant: {{consumer_epg_list[0].epg_tenant}}) {% endif %} | {{table.tenant}} | {{table.contract}} | {{table.subject}} | {{table.filter}} |
{% endfor %}
{% endif %}

In order to reduce Policy TCAM consumption and to simplify the configuration is it recommended to take the following steps.

1. Determine which services are required for the Provider and Consumer EPGs
   * Determine which permit policy, of those identified, best matches the communication requirements for the identified EPGs
2. Remove the permit policy that is no longer required, ensuring that it is either a duplicate or subset of the policy identified as the correct policy

More information about Contract configuration can be found in the [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) Whitepaper on cisco.com
