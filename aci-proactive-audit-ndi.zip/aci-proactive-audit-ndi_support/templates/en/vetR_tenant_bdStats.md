<!--
category:
  - Best_Practice
severity: warning
{% set count = namespace(value = 0) %}
{% set count.value = count.value + noARPGlean.count %}
{% set count.value = count.value + floodInEncap.count %}
{% set count.value = count.value + floodInEncapProxy.count %}
{% set count.value = count.value + ipLearnFlood.count %}
{% set count.value = count.value + ipLearnFlood.count %}
{% if cscvh17285 and cscvh17285.count > 0 %}
{% set count.value = count.value + cscvh17285.count %}
{% endif %}
affected_count: {{count.value}}
-->

### Bridge Domain Configuration

Bridge Domains in ACI have a number of configuration options to allow the administrator to tune the operation in various ways.

Please reference the [ACI Endpoint Learning Whitepaper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html) for detailed information about the available configuration options and how to use them in the most optimal way.

{% if noARPGlean.count > 0 %}

#### No ARP Glean

Bridge domains configured with the following configuration has ARP glean operations disabled, and therefore, will not learn silent hosts.

- L3 / Hardware Proxy
- No subnet configured on BD
- ARP Flooding is disabled

The table below lists bridge domains where ARP glean are disabled.

Table: BDs with no ARP Glean

| Bridge Domain Name |
| ------------------ |
{% for entry in noARPGlean.name %}
| {{entry}}          |
{% endfor %}

It is recommended to review the configuration of these bridge domains. If a subnet cannot be configured on these BDs, ARP flooding should be enabled to ensure EP discovery will function properly.
{% endif %}

{% if floodInEncap.count > 0 %}

#### Flood in Encapsulation

Flood in Encapsulation (FIE) is one of the configuration options for multi-destination flooding, under the bridge domain. The default configuration is Flood in BD. The functionality of FIE has changed significantly from 2.x to 3.x. The original function of this configuration was to constrain a small subset of protocols to a specific 802.1q encapsulation; the new functionality constrains all broadcasts to their specific 802.1q encapsulation.

Please note that this change in behavior does not impact a design with a single encapsulation per BD, but has a significant impact on designs with more than one encapsulation in a BD. This feature solves very specific problems and introduces some specific caveats and should only be enabled as part of an overall design strategy that requires flood in encapsulation functionality.

The table below lists the bridge domains configured with Flood in Encapsulation.

Table: BDs with Flood in Encapsulation

| Bridge Domain Name |
| ------------------ |
{% for entry in floodInEncap.name %}
| {{entry}}          |
{% endfor %}

It is recommended to review the design of these bridge domains and assess if the use of Flood in Encapsulation is the right design choice.
{% endif %}

{% if floodInEncapProxy.count > 0 %}

#### Flood in Encapsulation together with Hardware Proxy

The table below lists the bridge domains configured with both Flood in Encapsulation and Hardware Proxy, which are not a supported configuration.

Table: BDs with Flood in Encapsulation and Hardware Proxy

| Bridge Domain Name |
| ------------------ |
{% for entry in floodInEncapProxy.name %}
| {{entry}}          |
{% endfor %}

It is recommended to review the design of these bridge domains and modify the configuration depending on the desired behavior.
{% endif %}

{% if ipLearnFlood.count > 0 %}

#### IP Data Plane Learning and Unknown Unicast Flooding

Configuring a bridge domain with IP Data Plane Learning disable and Unknown Unicast to Flood is an invalid configuration. If flooding is required, then disable data plane learning at the VRF level instead.

The following bridge domains are configured with an invalid configuration with regards to IP Data Plane Learning and forwarding of Unknown Unicast.

Table: BDs with disabled Data Plane Learning and Unknown Unicast Flooding

| Bridge Domain Name |
| ------------------ |
{% for entry in ipLearnFlood.name %}
| {{entry}}          |
{% endfor %}

It is recommended to review the design of these bridge domains and modify the configuration depending on the desired behavior.
{% endif %}

{% if cscvh17285 and cscvh17285.count > 0 %}

#### L2 Bridge Domain and Enforce Subnet Check

Due to bug id CSCvh17285 will ACI Leaf switches will not learn MAC addresses of endpoints connected to the fabric through ARP/GARP packets arriving on Layer-2 only bridge domains (Unicast Routing disabled) when the global "Enforce Subnet Check" option is enabled.

The following bridge domains are affected by this issue.

Table: BDs affected by CSCvh17285

| Bridge Domain Name |
| ------------------ |
{% for entry in cscvh17285.name %}
| {{entry}}          |
{% endfor %}

The following workarounds are available for the bug:

1. Disable the global Enforce Subnet Check
2. Configure L2 Unknown Unicast Flood option under the bridge domain so that ACI leaf switch can flood traffic when the MAC address is not learned as an endpoint due to this defect and the date-plane forwarding on the BD will not be affected by this software defect. If L2 Unknown Unicast is set to Hardware-Proxy, ACI will drop the packet in case the destination MAC address is not learned anywhere in ACI Fabric, which could be a problem when ACI cannot learn the MAC address from ARP/GARP.

Please not that Configuring the L2 Unknown Unicast Flood option is recommended as a best practice for Layer 2-only bridge domains
{% endif %}
