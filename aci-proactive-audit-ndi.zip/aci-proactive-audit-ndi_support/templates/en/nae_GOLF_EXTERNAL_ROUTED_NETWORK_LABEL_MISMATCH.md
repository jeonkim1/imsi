<!--
category:
  - Healthcheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Consumer Label of GOLF Enabled L3Out Not Matching Infrastructure L3Out

The following GOLF enabled L3Outs have been configured with a consumer label matching the ones provided by the Infrastructure L3Out(s). This mans that no GOLF routes will be imported into the user tenant VRF.

Table: GOLF Enabled L3Out with Unmatched Consumer Label

{% if data_source == "ndi" %}
| Tenant | VRF | L3Out |
| ------ | --- | ----- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "l3Outs" -%}
            {%- set _=table.__setitem__("l3Outs", object.objectValue) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.vrfs}} | {{table.l3Outs}} |
{% endfor %}
{% else %}
| Tenant | VRF | L3Out |
| ------ | --- | ----- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 28 -%}
            {% set _=table.__setitem__("l3out", object.name) %}

        {%- elif object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}

        {%- endif -%}

    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.l3out}} |
{% endfor %}
{% endif %}

It is recommended to review the configuration of these GOLF L3Outs and the Infrastructure L3Out to check if they are configured with the right labels.

More information about GOLF configuration can be found in the [Cisco ACI Layer 3 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L3_config/b_Cisco_APIC_Layer_3_Configuration_Guide/b_Cisco_APIC_Layer_3_Configuration_Guide_chapter_010010.html)
