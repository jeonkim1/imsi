<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Bridge Domain Subnet missing on Border Leaf

Bridge domain subnets in a VRF should be present on both the border leaf(s) and the remaining switches on which the bridge domain is deployed. The bridge domain subnets listed below are not deployed on the border leafs.

Table: Bridge Domain Subnet missing on Border Leaf

{% if data_source == "ndi" %}
| Subnet | Tenant | Bridge Domain | Leaf | Associated VRF | Associated EPG |
| ------ | ------ | ------------- | ---- | -------------- | -------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- elif object.objectType == "subnet" -%}
                {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bd", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- elif object.objectType == "leafs" -%}
                {% set _=table.__setitem__("leaf", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {% if table.subnet|length > 1 %} {{table.subnet|join(", ")}} {% else %} {{table.subnet[0]}} {% endif %} | {{table.tenant}} | {{table.bd}} | {% if table.leaf|length > 1 %} {{table.leaf|join(", ")}} {% else %} {{table.leaf[0]}} {% endif %} | {{table.vrf}} | {{table.epg}} |
{% endfor %}
{% else %}
| Subnet | Tenant | Bridge Domain | L3Out | Leaf | Associated VRF | Associated EPG |
| ------ | ------ | ------------- | ----- | ---- | -------------- | -------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set epg_list = []%}
{% set leaf_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 3 -%}
            {% set _=table.__setitem__("bd", object.name) %}

        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}

        {%- elif object.object_types[0].code == 7 -%}
            {% set _=epg_list.append(object.name) %}

        {%- elif object.object_types[0].code == 28 -%}
            {% set _=table.__setitem__("l3out", object.name) %}

        {%- elif object.object_types[0].code == 1 or object.object_types[0].code == 384 -%}
            {% set _=leaf_list.append(object.name) %}

        {%- elif object.object_types[0].code == 253 -%}
            {% set _=table.__setitem__("subnet", object.name) %}

        {%- endif -%}
    {%- endfor -%}
| {{table.subnet}} | {{table.tenant}} | {{table.bd}} | {{table.l3out}} | {% if leaf_list|length > 1 %}{{leaf_list|join(", ")}}{% elif leaf_list|length > 0%}{{leaf_list[0]}}{% else %}-{% endif %} | {{table.vrf}} | {% if epg_list|length > 1 %}{{epg_list|join(", ")}}{% elif epg_list|length > 0%}{{epg_list[0]}}{% else %}-{% endif %} |
{% endfor %}
{% endif %}

It is recommended to open a TAC case in order to investigate why the bridge domain subnet(s) are not deployed on the border leaf(s).
