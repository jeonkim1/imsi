<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Configured Leaf PC Interface with all member links having Link Down

The following leaf PC interfaces has been configured for consumption by the Fabric Access Policy, but have link down on all member links.

Table: Configured Leaf PC Interface with all member links having Link Down

{% if data_source == "ndi" %}
| Interface Policy Group | Leaf |
| ---------------------- | -----|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "interfacePolicyGroups" -%}
            {%- set _=table.__setitem__("interfacePolicyGroup", object.objectValue[0]) -%}
        {%- elif object.objectType == "leafs" -%}
                {% set _=table.__setitem__("leaf", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.interfacePolicyGroup}} | {{table.leaf}} |
{% endfor %}
{% else %}
| Interface Policy Group | Interface Profile | Leaf | Associated AAEP |
| ---------------------- | ----------------- | ---- | --------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 244 -%}
                {% set _=table.__setitem__("interface_policy_group", object.name) %}

            {%- elif object_type.code == 384 -%}
                {% set _=table.__setitem__("leaf", object.name) %}

            {%- elif object_type.code == 234 -%}
                {% set _=table.__setitem__("interface_profile", object.name) %}

            {%- elif object_type.code == 237 -%}
                {% set _=table.__setitem__("aaep", object.name) %}

            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{table.interface_policy_group}} | {{table.interface_profile}} | {{table.leaf}} | {{table.aaep}} |
{% endfor %}
{% endif %}

If these interfaces are supposed to be in used, then it is recommended investigate why all member links have link down.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)
