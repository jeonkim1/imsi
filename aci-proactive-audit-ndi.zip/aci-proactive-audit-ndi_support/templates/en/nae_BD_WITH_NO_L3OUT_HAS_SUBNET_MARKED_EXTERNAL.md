<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Bridge Domain or EPG with no L3Out association has subnet marked external

The following EPG(s) or BD(s) Subnet configured is marked as \"Advertised Externally\", however BD is missing a L3Out association.

Table: Bridge Domain or EPG with no L3Out association has subnet marked external are present

{% if data_source == "ndi" %}
| Tenant | VRF | BD | Subnet |
| ------ | --- | -- | ------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "subnet" -%}
            {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bds", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.subnet|join(", ")}} | {{table.bds|join(", ")}} | {{table.vrfs|join(", ")}} |
{% endfor %}
{% else %}
| Tenant | VRF | BD | Subnet | L3Out |
| ------ | --- | -- | ------ | ----- |
{% for item in event_list %}
{% set table = dict() %}
{% set l3out_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}
        {%- elif object.object_types[0].code == 3 -%}
            {% set _=table.__setitem__("bd", object.name) %}
        {%- elif object.object_types[0].code == 253 -%}
            {% set _=table.__setitem__("subnet", object.name) %}
        {%- elif object.object_types[0].code == 28 -%}
            {% set _=l3out_list.append(object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{ table.tenant }} | {{ table.vrf }} | {{table.bd}} | {{table.subnet}} | {% for l3out in l3out_list %} {{l3out}} {% endfor %} |
{% endfor %}
{% endif %}

It is recommended to verify the configuration of these bridge domains, as the current forwarding behavior may not match the intended behavior.

More information about Bridge Domain configuration can be found in the [Cisco API Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_010.html)
