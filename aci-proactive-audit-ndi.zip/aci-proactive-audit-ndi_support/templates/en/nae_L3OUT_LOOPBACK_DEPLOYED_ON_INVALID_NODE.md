<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### L3OUT Loopback is Deployed on Invalid Node


L3OUT Loopback is deployed on a Node that does not exist.

Table: L3OUT Loopback is Deployed on Invalid Node

{% if data_source == "ndi" %}
| Tenant | VRF | Subnet |
| ------ | --- | -------|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- elif object.objectType == "subnet" -%}
                {% set _=table.__setitem__("subnet", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.subnet}} |
{% endfor %}
{% else %}
| Tenant | VRF | Subnet |
| ------ | --- | -------|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object.object_types[0].code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}
            {%- elif object.object_types[0].code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}
            {%- elif object_type.code == 253 -%}
                {% set _=table.__setitem__("subnet", object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.subnet}} |
{% endfor %}
{% endif %}

L3OUT deployment examples can be found at [Cisco ACI L3Out Configuration Examples](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/example-files/l3out-configuration-examples/l3out-configuration-examples.html).

More information about L3OUTs can be found in [Cisco APIC Layer 3 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/l3-configuration/cisco-apic-layer-3-networking-configuration-guide-52x.html)