<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Overlapping Subnets Across Static Routes and BD in VRF


The list of subnets configured on BDs/EPGs in a given VRF overlap with static routes configured on the L3Out.
Sub-optimal routing may result due to overlapping IP addresses, and next-hop resolution for one or more routes may fail.

Table: Overlapping Subnets and Static Routes in VRF

{% if data_source == "ndi" %}
| Subnet | Tenant | VRF | BD  | EPG |
| ------ | ------ |---- | --- | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "subnet" -%}
            {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bds ", object.objectValue) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epgs", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.subnet|join(", ")}} | {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.bds|join(", ")}} | {{table.epgs|join(", ")}} |
{% endfor %}
{% else %}
| Subnet | Tenant | VRF | BD  | EPG | L3Outs | Static Route | Nodes |
| ------ | ------ |---- | --- | --- | ------ |------------- | ----- |
{% for item in event_list %}
{% set table = dict() %}
{% set epg_list = []%}
{% set l3out_list = []%}
{% set contract_list = []%}
{% set leaf_list = []%}
{% set vrf_list = []%}
{% set bd_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 7 -%}
                {% set _=epg_list.append(object.name) %}
            {%- elif object_type.code == 3 -%}
                {% set _=bd_list.append(object.name) %}
            {%- elif object_type.code == 253 -%}
                {% set _=table.__setitem__("subnet", object.name) %}
            {%- elif object_type.code == 254 -%}
                {% set _=table.__setitem__("route", object.name) %}
            {%- elif object_type.code == 28 -%}
                {% set _=l3out_list.append(object.name) %}
            {%- elif object_type.code == 19 -%}
                {% set _=contract_list.append(object.name) %}
            {%- elif object_type.code == 384 or object_type.code == 385 -%}
                {% set _=leaf_list.append(object.name) %}
            {%- elif object_type.code == 4 -%}
                 {% set _=table.__setitem__("vrf", object.name) %}
            {%- elif object_type.code == 2 -%}
                 {% set _=table.__setitem__("tenant", object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}

| {{table.subnet}} | {{table.tenant}} | {{table.vrf}} | {% if bd_list|length > 1 %}{{bd_list|join(", ")}}{% elif bd_list|length == 1 %} {{bd_list[0]}} {% else %} - {% endif %} | {% if epg_list|length > 1 %} {{epg_list|join(", ")}} {% elif epg_list|length == 1 %} {{epg_list[0]}} {% else %} - {% endif %}| {% if l3out_list|length > 1 %} {{l3out_list|join(", ")}} {% else %} {{l3out_list[0]}} {% endif %} | {{table.route}} | {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

Suggested next steps:

Determine the right sized subnet for the interfaces or BD in question.
Correct the overlap condition by deleting one or more subnets from the respective L3out + Node Profile combinations, or BD, that are shown in the additional information area for this event.


More information about L3Out configuration can be found in the [ACI L3 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/l3-configuration/cisco-apic-layer-3-networking-configuration-guide-52x.html) and in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com

More information about BD subnet configuration can be found in the [Cisco ACI Layer-3 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/L3-configuration/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401_chapter_01001.html) on cisco.com

