<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### External routed network (L3out) has no EPG


The L3Out is defined, but it does not have any External EPGs defined underneath.
Impact is that transit routing and/or connectivity to routes learned from this L3Out will not be complete.

Table: L3out(s) with missing ExternalEPG

{% if data_source == "ndi" %}
| Tenant | L3out |
| ------ | ----- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue[0]) -%}
        {%- elif object.objectType == "l3Outs" -%}
                {% set _=table.__setitem__("l3Outs", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants}} | {{table.l3Outs}} |
{% endfor %}
{% else %}
| Tenant | L3out |
| ------ | ----- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 28 -%}
            {% set _=table.__setitem__("l3out", object.name) %}
        {%- endif -%}

    {%- endfor -%}
| {{table.tenant}} | {{table.l3out}} |
{% endfor %}
{% endif %}

It is recommended to determine if the L3out is required and in case, configure the External EPG with the external subnet required.

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
