<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### EPG static path binding encapsulation conflict error

More than one EPG static paths configured for same Node and Vlan
One or more EPG paths connected to this leaf and matching Vlan encap may have a deployment error.

Table: Node and Vlan with more than one EPG static path configured.

{% if data_source == "ndi" %}
| Leaf | encap VLAN |
| ---- |------------|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "leafs" -%}
            {%- set _=table.__setitem__("leaf", object.objectValue[0]) -%}
        {%- elif object.objectType == "encaps" -%}
            {%- set _=table.__setitem__("vlan", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.leaf}} | {{table.vlan}} |
{% endfor %}
{% else %}
| Leaf | encap VLAN |
| ---- |------------|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 384 -%}
            {% set _=table.__setitem__("leaf", object.name) %}
        {%- elif object.object_types[0].code == 3001 -%}
            {% set _=table.__setitem__("vlan", object.identifier) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leaf}} | {{table.vlan}} |
{% endfor %}
{% endif %}

Please not that this finding may contain false positives if the fabric are using port-local VLAN scope.

For every Leaf and encap VLAN combination in the table, verify if there are more than one EPG static paths configured.
The following moquery issued on APIC, may help to correlate EPG, static path, nodes and VLAN: moquery -c fvRsPathAtt | grep dn
Reconfigure to have only one path for each Leaf and Vlan combination

More information about statically deploying an EPG on a specific Port can be found in the [Cisco APIC Basic Configuration Guide - Basic User Tenant Configuration](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/basic-configuration/cisco-apic-basic-configuration-guide-52x/m_tenants.html)