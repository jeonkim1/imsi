<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Consumer EPG has invalid Contract

The following EPGs are consuming an invalid or non-existing contract.

Table: Consumer EPG has invalid Contract

{% if data_source == "ndi" %}
| Tenant | Application Profile | EPG | Contract |
| ------ | ------------------- |---- | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- elif object.objectType == "contracts" -%}
            {% set _=table.__setitem__("contracts", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants}} | {{table.ap}} | {{table.epg}} | {{table.contracts}} |
{% endfor %}
{% else %}

| Tenant | Application Profile |EPG | Contract |
| ------ | ------------------- | --- | -------- |
{% for epg in event_list %}
| {{epg.2.name}} | {{epg.1.name}} | {{epg.0.name}} | {{epg.3.name}} |
{% endfor %}
{%- endif -%}

If the contract(s) are supposed to be in use, then the contracts should be configured. If they the contract(s) are not supposed to be used, then it is recommended to remove them from the EPGs consuming them.

More information about Contract configuration can be found in the [Cisco API Security Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/security/Cisco-APIC-Security-Configuration-Guide-401/b_Cisco_APIC_Security_Guide_chapter_01010.html)
