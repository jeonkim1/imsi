<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### External EPG not associated with Contract in Enforced VRF

The following External EPGs are not associated with a contract in an enforced VRF. This may result in transit routing and/or connectivity to routes learned from the associated L3Out to fail.

Table: External EPG not associated with Contract in Enforced VRF

{% if data_source == "ndi" %}

| Tenant | VRF | L3Out | External EPG |
| ------ | --- | ----- | ------------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3out", object.objectValue[0]) %}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.l3out}} | {{table.epg}}
{% endfor %}
{% else %}

| Tenant | VRF | L3Out | External EPG |
| ------ | --- | ----- | ------------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object_type.code == 7 -%}
                {% set _=table.__setitem__("epg", object.name) %}

            {%- elif object_type.code == 28 -%}
                {% set _=table.__setitem__("l3out", object.name) %}

            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.l3out}} | {{table.epg}} |
{% endfor %}
{%- endif -%}

It is recommended to use the following steps to investigate the issue:

1. Determine if the L3Out is required and its purpose. If the L3Out is not required, determine if the L3Out can be deleted
2. If the L3Out is required, determine its purpose and create a new, or associate an existing contract as needed, to meet the requirements

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com.
