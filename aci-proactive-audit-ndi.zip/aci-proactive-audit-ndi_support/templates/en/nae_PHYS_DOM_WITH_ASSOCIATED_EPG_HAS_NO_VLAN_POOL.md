<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Physical Domain associated with EPG has not VLAN Pool associated

The following domain(s) are not associated with a VLAN pool although they are used by an EPG.

Table: Physical Domain associated with EPG has not VLAN Pool associated

| Domain Name |
| ------ |
{% if data_source == "ndi" %}
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "physicalDomains" -%}
            {%- set _=table.__setitem__("domain", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.domain}} |
{% endfor %}
{% else %}
{% for domain in event_list %}
{% if domain.0.name != "default" %}
| {{domain.0.name}} |
{% endif %}
{% endfor %}
{% endif %}

If these domain(s) are in use, then they should be associated with a VLAN pool. If they are not in use, then it is recommended to remove them in order to simplify the configuration.

More information about domain configuration can be found in the [Cisco APIC Layer 2 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_011.html) on cisco.com.
