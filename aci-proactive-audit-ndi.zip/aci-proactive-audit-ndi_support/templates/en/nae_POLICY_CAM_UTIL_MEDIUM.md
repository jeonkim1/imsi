<!--
category:
  - Healthcheck
severity: warning
affected_count: "{{event_list|length}}"
-->

#### Policy TCAM Utilization Medium


The following leaf switches have Policy CAM between 60% and 75% utilized.

Table: Leaf Switches with Policy CAM utilization between 60% and 75%

| Leaf |
| ---- |
{% for item in event_list %}
|{{item[0].name}}|
{% endfor %}

In order to reduce Policy TCAM consumption and to simplify the configuration is it recommended to take the following steps.

1. Determine which services are required for the Provider and Consumer EPGs
   * Determine which permit policy, of those identified, best matches the communication requirements for the identified EPGs
2. Remove the permit policy that is no longer required, ensuring that it is either a duplicate or subset of the policy identified as the correct policy
3. Evaluate the use of vzAny or Preferred Group
4. Evaluate the use of policy compression

More information about Contract configuration can be found in the [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) Whitepaper on cisco.com