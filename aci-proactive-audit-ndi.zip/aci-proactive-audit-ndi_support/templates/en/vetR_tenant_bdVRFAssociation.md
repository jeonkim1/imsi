<!--
category:
  - Healthcheck
severity: warning
affected_count: "{{invalidAssociations|length}}"
-->

### BDs with Invalid VRF Association

The following bridge domains are configured with an invalid VRF association (empty, non-existent, or invalid VRF).

Table: BDs with Invalid VRF Association

| Tenant | BD |
| ------ | --- |
{% for entry in invalidAssociations %}
{% set entry_components = entry.bd.split("/") %}
{% set tenant = entry_components[1] %}
{% set tenant_components = tenant.split("-") %}
{% set name = entry_components[2] %}
{% set name_components = name.split("-") %}
| {{tenant_components[1:]|join("-")}} |{{name_components[1:]|join("-")}} |
{% endfor %}

It is recommended to review the configuration of these bridge domains.

More information about bridge domain configuration can be found in the [Cisco ACI Layer 2 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_010.html) on cisco.com.
