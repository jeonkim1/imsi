<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
affected_count: "{{rrsPerPod|length}}"
-->

### Fabric Route Reflector

Within the Cisco ACI fabric are BGP route reflectors used to distribute external routes within the fabric. To enable route reflectors in the ACI fabric should two spines in each POD be configured as a route reflector.

The table below lists the nodes that has been configured as route reflector in each pod.

Table: Fabric Route Reflectors

| Pod | Number of Route Reflectors | Route Reflector Nodes |
| --- | -------------------------- | --------------------- |
{% for entry in rrsPerPod %}
| {{entry}} | {{rrsPerPod[entry]|length}} | {% if rrsPerPod[entry]|length > 1 %}{% for node in rrsPerPod[entry] %}{{node}},{% endfor %}{% else %}{{rrsPerPod[entry][0]}}{% endif %} |
{% endfor %}

It is recommended to have at least two route reflectors defined in each pod for redundancy reasons.

More information about BGP route reflectors can be found in the [Cisco ACI Layer 3 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/L3-configuration/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401_chapter_01011.html) available on cisco.com.
