<p align="center">
<img src="assets/logo.png" width="299" height="84" border="0" alt="ACI vetR">
<br/>
ACI health check tool
<p>
<hr/>

# Quick Start

ACI vetR performs a health check against an ACI fabric. The following steps will
get you started:

1. Run the [collector tool](https://github.com/aci-vetr/collector#readme)
   against the customer fabric. The customer can download and run this tool or
   if you have access to the customer network, you can run it directly.
2. Upload the customer collection data to the
   [ACI vetR website](https://dc-code.cisco.com) to create a new deliverable
   document.
3. Download and edit the final Word Document to make any changes to tailor it to
   your customer environment.

# Overview

The goal of this tool is to provide automated, high-quality Health Check
deliverable for ACI.

It consists of two components:

1. A collection tool, to run API queries against the APIC.
2. The internal analysis tool that runs against the collected data, checks for
   best practices, and produces a deliverable document.

The collector tool is available as a binary download under the
[releases tab](https://github.com/aci-vetr/collector/releases/latest).

The analysis tool can be run from the following website:

https://dc-code.cisco.com

# Usage

## Collector

The collector is a downloadable tool. Pre-compiled binary releases are provided
for Windows, MacOS, and Linux. Note, that you do not need to install any
dependencies to use this tool--simply download, open a terminal, and run. The
tool can be downloaded from
[here](https://github.com/aci-vetr/collector/releases/latest). You can
collaborate with the customer to collect data over WebEx, or provide the link to
the customer to download and run directly.

Detailed documentation on the collector is available in the
[collector README](https://github.com/aci-vetr/collector#readme).

**Note** that the collector is open source. Source code for the collector
including specific managed object queries can be provided to he customer for
review, e.g. to address security concerns. The specific queries the tool
performs are liste

The collector is functionally similar to a binary moquery script--it collects a
variety of managed object classes from API endpoints. The specifics of which MOs
it queries are documented in the repository and the source code is available. If
your customer has specific security requirements that precludes running the
tool, a shell script is also bundled in the release zip files called
`vetr-collector.sh`. This shell script can be uploaded to the APIC and run
locally and will collect the same data as the binary tool.

The collection runs API queries in parallel and should be fairly quick to
complete--in smaller labs, the collection typically takes less than a minute; in
a large fabric with a heavily loaded APIC, it can take over a minute to
complete; however, is still fairly quick. The collection tool also throttles and
batches queries to avoid any notable impact on the API.

## Analysis Tool

The analysis engine is hosted at https://dc-code.cisco.com. Note that this site
is hosted internal to Cisco and is not accessible to customers. Additionally,
customer data is protected while running the analysis and purged from this
server on a regular interval.

## Workflow

Ease of use and time to delivery are top priorities of this tool. If you have
suggestions for improving the workflow, feedback is welcome.

### Step 1 - collect data

Run the collection utility against the customer network. This tool is hosted
externally so customers can download the tool directly.

Once complete, the customer provides the `aci-vetr-data.zip` file to Services.
This file is the _input_ for the analysis.

### Step 2 - run the analysis

Navigate to https://dc-code.cisco.com, upload your collection file, and fill in
the required details. The requested information is used for a combination of
populating the final deliverable document and for gathering statistics on where
and how this tool is used.

**Note** that running the job throught the web portal will run the job in real
time. In most cases, the report should be available in less than a minute.

### Step 3 - edit and deliver

The second page of the deliverable document contains instructions on delivery.
Review these instructions and edit the document as required to tailor it to your
customer environment.

# Issues and Enhancements

Issues have been moved to Trello to streamline triaging new issues and the
ongoing development of the tool. Issue tracking is available here:

https://trello.com/invite/b/hmSQPyLt/6195e9646b2baaa52f185ff52656707d/aci-vetr-develop

"Issues" include enhancements and new health checks. The board allows voting, so
please vote on any issues or new checks that are valuable to you. Votes are
given high weight in prioritizing development.

**NOTE** that this board is available to anybody with this link. Sharing links
to techzone, CDETS, or similar information is fine, but do not share confidental
information, e.g. customer details, unreleased PSIRT inforomation, etc. It's
possible vetR may be shared with customers to run internally as a service, in
which case customer engineers may be included on this board.

Additionally, there's a WebEx chat room for discussion of the tool. This room is
internal-only. You can join this room using the following eURL link:

https://eurl.io/#yuspm_H_X

# Feedback

Feedback is welcome. If you have suggestions or feature requests either create
an issue on Trello or contact me (nhemingw) via email or WebEx Teams to discuss.

Please check the existing issues for ideas for contributing, and/or before
creating a new issue, but also accidentally creating a duplicate or putting the
issue in the wrong part of Trello is not a huge concern. Automation rules are
configured in Trello to flag new issues, and they will be triaged into the
correct spot.

If this tool is valuable to you, please star the GitHub repos, vote on issues,
and spread the word.

# Contributing

This is a community-owned tool. Contribution is welcome. Please see the
[contribution guidelines](https://wwwin-github.cisco.com/aci-vetr/vetr/blob/master/docs/CONTRIBUTING.md)
for more details.
