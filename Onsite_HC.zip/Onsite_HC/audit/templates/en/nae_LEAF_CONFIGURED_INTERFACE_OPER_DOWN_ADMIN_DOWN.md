<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Leaf interface configured ready to be consumed by EPG is in admin down

Interface configured for consumption by the Fabric Access Policy but not yet consumed by any EPG is administratively down.

Table: Configured Leaf Interface in Admin Down and ready for Use by EPG.

{% if data_source == "ndi" %}
| Leaf | Interface |
| ---- | --------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leaf", object.objectValue[0]) %}
        {%- elif object.objectType == "interfaces" -%}
            {% set _=table.__setitem__("interface", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leaf}} | {{table.interface}} |
{% endfor %}
{% else %}
| Leaf | Interface |Associated Interface Policy Group | Associated Interface Profile | Associated AAEP |
| ---- | --------- | -------------------------------- | ---------------------------- | --------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set consumer_epg_list = [] %}
{% set provider_epg_list = [] %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 233 -%}
                {% set _=table.__setitem__("interface", object.name) %}
            {%- elif object_type.code == 234 -%}
                {% set _=table.__setitem__("interface_profile", object.name) %}
            {%- elif object_type.code == 237 -%}
                {% set _=table.__setitem__("aaep", object.name) %}
            {%- elif object_type.code == 244 -%}
                {% set _=table.__setitem__("interface_policy_group", object.name) %}
            {%- elif object_type.code == 384 -%}
                {% set _=table.__setitem__("leaf", object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{table.leaf}} | {{table.interface}} | {{table.interface_policy_group}} | {{table.interface_profile}} | {{table.aaep}} |
{% endfor %}
{% endif %}

Determine if the interface(s) in question are configured with the right set of fabric access policies.
If not, delete the interface(s) from the access-policies to clear the condition.
If yes, unshut the interface(s) from the APIC gui using Fabric > Inventory > Pod-X > Leaf > Physical interfaces.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-2-configuration/cisco-apic-layer-2-networking-configuration-guide-52x/access-interfaces-52x.html)
