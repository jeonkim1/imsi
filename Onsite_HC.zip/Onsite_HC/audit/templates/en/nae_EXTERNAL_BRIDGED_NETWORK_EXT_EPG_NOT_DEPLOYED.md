<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### L2Out External EPG Will Not be Deployed on a Leaf

L2Out is configured with an External EPG, but the EPG will not be deployed on a leaf switch. Bridging to an external network from this L2Out will not be successful.

Table: L2Outs and ExtEPGs Impacted by this Issue

{% if data_source == "ndi" %}

| Tenant | VRF |
| ------ | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} |
{% endfor %}
{% else %}

| Tenant | VRF | External EPG |
| ------ | ----| ------------ |
{% for event in event_list %}
{% set table = dict() %}
    {%- for object in event -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
               {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 27 -%}
                {% set _=table.__setitem__("l2out", object.name) %}

            {%- elif object_type.code == 7 -%}
                {% set _=table.__setitem__("ext_epg", object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{ table.tenant }} | {{ table.l2out }} | {{ table.ext_epg}} |
{% endfor %}
{%- endif -%}


It is recommended to investigate L2Out configuration. Common problems are missing L2 Domain assignment or misconfiguration in Fabric Access Policies.

More information about L2Out configuration can be found in the [L2Out Configuration using the Routed Bridged Network Method](https://www.cisco.com/c/en/us/support/docs/cloud-systems-management/application-policy-infrastructure-controller-apic/200964-Configure-Access-Polices-Static-Binding.html#anc12) on cisco.com.

