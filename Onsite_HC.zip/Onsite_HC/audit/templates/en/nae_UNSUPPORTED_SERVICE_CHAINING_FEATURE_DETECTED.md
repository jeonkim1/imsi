<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Service Chaining is detected. Unsupported Feature for NAE

APIC policy configuration includes configuration of service graphs that is not supported in this release of CNAE.
Analysis with this unsupported feature may lead to false positive or false negative results.

Table: Contracts with associated Service Graphs.

{% if data_source == "ndi" %}
| Tenant | Contract |
| ------ | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "contracts" -%}
            {%- set _=table.__setitem__("contract", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| | {{table.contract}} |
{% endfor %}
{% else %}
| Tenant | Contract |
| ------ | -------- |
{% for item in event_list %}
{% set contract_list =[] %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 19 -%}
            {% set ctr = dict() %}
            {% set ctr_components = object.identifier.split("/") %}
            {% set _=ctr.__setitem__("tenant", ctr_components[1][3:]) %}
            {% set _=ctr.__setitem__("contract", ctr_components[2][4:]) %}
            {% set _=contract_list.append(ctr) %}
        {%- endif -%}
    {%- endfor -%}
    {% for ctr in contract_list %}
| {{ctr.tenant}} | {{ctr.contract}} |
    {% endfor %}
{% endfor %}
{% endif %}

This event is informational. No actions need to be taken on ACI.