<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### External Static Route is Unreachable from Leaf

An external route that is configured on the APIC is not present on the border leaf switch.
The impact is that IP addresses reachable via this route are not accessible by endpoints in the fabric.

Table: Static Routes Impacted

{% if data_source == "ndi" %}
| Route | Tenant | VRF | L3Out |
| ----- | ------ |---- | ----- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "route" -%}
            {% set _=table.__setitem__("route", object.objectValue) %}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3Outs", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.route|join(", ")}} | {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.l3Outs|join(", ")}} |
{% endfor %}
{% else %}
| Route | Tenant | VRF | L3Out | Node(s) |
| ----- | ------ |---- | ----- | ------- |
{% for item in event_list %}
    {% set table =dict() %}
    {% set node_list = []%}
    {% for object in item %}
        {% if object.object_types[0].code == 254 %}
            {% set _=table.__setitem__("route", object.name) %}
        {% elif object.object_types[0].code == 384 or object.object_types[0].code == 1%}
            {% set _=node_list.append(object.name) %}
        {% elif object.object_types[0].code == 2 %}
            {% set _=table.__setitem__("tenant", object.name) %}
        {% elif object.object_types[0].code == 4 %}
            {% set _=table.__setitem__("vrf", object.name) %}
        {% elif object.object_types[0].code == 28 %}
            {% set _=table.__setitem__("l3out", object.name) %}
        {% endif %}
    {% endfor %}
|{{ table.route }}| {{table.tenant}} | {{table.vrf}} | {{table.l3out}} | {% if node_list|length > 1 %} {{node_list|join(", ")}} {% else %} {{node_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

It is recommended to collect a techsupport from the affected leaf switch and contact Cisco TAC for assistance with root causing the issue.

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com.


