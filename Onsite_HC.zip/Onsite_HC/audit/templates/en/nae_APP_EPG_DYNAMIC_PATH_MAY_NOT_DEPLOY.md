<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Application EPG Dynamic Path may not deploy

The following EPGs have dynamic paths that may fail deployment due to an error in fabric access policy or EPG port path binding.

Table: EPG Dynamic Path may not deploy

{% if data_source == "ndi" %}
| Tenant | Application Profile | EPG Name |
| ------ | ------------------- | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.ap}} | {{table.epg}} |
{% endfor %}
{% else %}
| Tenant | Application Profile | EPG Name |
| ------ | ------------------- | -------- |
{% for epg in event_list %}
| {{epg.2.name}} | {{epg.4.name}} | {{epg.0.name}} |
{% endfor %}
{% endif %}

It is recommended to verify the configuration of the fabric access policies and EPG port bindings used by these EPGs.

More information about EPG configuration and design can be found in the [Endpoint Group (EPG) Usage and Design Whitepaper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-731630.html) on cisco.com.
