<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Endpoint with Self-Assigned IP Address

A number of endpoints have a self-assigned IP address (RFC 3927), which usually occurs on DHCP failures. This may lead to the Endpoint(s) being unable to communicate outside the Layer-2 domain.
{% if data_source == "ndi" %}

| Leaf(s) | EP MAC | Tenant | VRF | BD | EPG | Interface |
| ------------- | ------ | ------ | --- | -- | --- | --------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "macs" -%}
            {%- set _=table.__setitem__("macs", object.objectValue[0]) -%}
        {%- elif object.objectType == "bds" -%}
                {% set _=table.__setitem__("bds", object.objectValue[0]) %}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epgs", object.objectValue[0]) %}
        {%- elif object.objectType == "tenants" -%}
            {% set _=table.__setitem__("tenants", object.objectValue) %}
        {%- elif object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leafs", object.objectValue) %}
        {%- elif object.objectType == "interfaces" -%}
            {% set _=table.__setitem__("interfaces", object.objectValue[0]) %}
        {%- elif object.objectType == "encaps" -%}
            {% set _=table.__setitem__("encaps", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leafs|join(", ")}} | {{table.macs}} | {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.bds}} | {{table.epgs}} | {{table.interfaces}} |
{% endfor %}

{%else%}

Table: Endpoint with Self-Assigned IP Address

| Leaf(s) | EP MAC | Tenant | VRF | BD | EPG | Interface |
| ------- | ------ | ------ | --- | -- | --- | --------- |
{% for item in event_list %}
{% set table = dict() %}
{% set ip_list = [] %}
{% set leaf_list = [] %}
{% set interface_list = [] %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}

        {%- elif object.object_types[0].code == 3 -%}
            {% set _=table.__setitem__("bd", object.name) %}

        {%- elif object.object_types[0].code == 304 -%}
            {% set _=table.__setitem__("ep_mac", object.name) %}

        {%- elif object.object_types[0].code == 327 -%}
            {% set _=ip_list.append(object.name) %}

        {%- elif object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}

        {%- elif object.object_types[0].code == 1 or object.object_types[0].code == 384 -%}
            {% set _=leaf_list.append(object.name) %}

        {%- elif object.object_types[0].code == 233 -%}
            {% set interface_components = object.identifier.split("/") %}
            {% set interface_node = " (" ~ interface_components[2] ~ ")" %}
            {% set _=interface_list.append(object.name ~ interface_node) %}

        {%- endif -%}

    {%- endfor -%}
| {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} | {% if table.ep_mac != "" %}{{ table.ep_mac }}{% else %} - {% endif %} | {% if ip_list|length > 1 %} {{ip_list|join(", ")}} {% else %} {{ip_list[0]}} {% endif %} | {{table.tenant}} | {{table.vrf}} | {{table.bd}} | {{table.epg}} | {% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %} |
{% endfor %}
{%endif%}

If DHCP are intended to be used to assign IP addresses to endpoints, then it is recommended to use the following steps to investigate the issue:

1. Verify that Bridge Domain is configured for Layer-3 Unicast Routing and has the right subnet configured
2. Verify that DHCP relay has been configured correctly
3. Troubleshoot DHCP Server reachability, IP address availability, and assignment. Please note that ACI requires the DHCP server to support Option-82

If DHCP are not intended to be used, then it is recommended to check if subnet check needs to be enforced in the Bridge Domain configuration.

More information about DHCP relay can be found in the [Cisco ACI Basic Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/basic-configuration/Cisco-APIC-Basic-Configuration-Guide-401/Cisco-APIC-Basic-Configuration-Guide-401_chapter_0101.html) available on cisco.com.
