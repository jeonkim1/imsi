<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Used Leaf PC Interface in Admin UP State is Operationally Down

The following leaf PC interface is in use by EPG and Admin Up, but all member links are operationally down.

Table: Configured Leaf PC Interface in use by EPG with all member links operationally down.

{% if data_source == "ndi" %}
| Interface Policy Group | Leaf |
| ---------------------- | -----|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "interfacePolicyGroups" -%}
            {%- set _=table.__setitem__("interfacePolicyGroup", object.objectValue[0]) -%}
        {%- elif object.objectType == "leafs" -%}
                {% set _=table.__setitem__("leaf", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.interfacePolicyGroup}} | {{table.leaf}} |
{% endfor %}
{% else %}
| Leaf | PC Interface Policy Group | Associated LAP | Member Interface |
| ---- | --------------------------| ---------------| ---------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 384 -%}
            {% set _=table.__setitem__("leaf", object.name) %}
        {%- elif object.object_types[0].code == 244 -%}
            {% set _=table.__setitem__("pc_ipg", object.name) %}
        {%- elif object.object_types[0].code == 237 -%}
            {% set _=table.__setitem__("aap", object.name) %}
        {%- elif object.object_types[0].code == 233 -%}
            {% set _=interface_list.append(object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leaf}} | {{table.pc_ipg}} | {{table.aap}} |{% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

If these port-channels are supposed to be in use, then it is recommended to investigate why all member links are operationally down.
If the port-channels are not supposed to be use, please detach the EPG static binding.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)