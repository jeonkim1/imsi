<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Application EPG Static Leaf Path may not deploy

The following EPGs have static paths that may fail deployment due to an error in fabric access policy or EPG port path binding.

Table: EPG Static Leaf Path may not deploy

{% if data_source == "ndi" %}
| Tenant | Application Profile | EPG Name | AAEP | Physical Domain | Encap VLAN |
| ------ | ------------------- | -------- | -----| --------------- | ---------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- elif object.objectType == "encaps" -%}
            {% set _=table.__setitem__("encap", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.ap}} | {{table.epg}} | | | {{table.encap}} |
{% endfor %}
{% else %}
| Tenant | Application Profile | EPG Name | AAEP | Physical Domain | Encap VLAN |
| ------ | ------------------- | -------- | -----| --------------- | ---------- |
{% for item in event_list %}
{% set table = dict() %}
{% set phydom_list = [] %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 3001 -%}
            {% set _=table.__setitem__("vlan", object.identifier) %}
        {%- elif object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 8 -%}
            {% set _=table.__setitem__("app_profile", object.name) %}
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}
        {%- elif object.object_types[0].code == 237 -%}
            {% set _=table.__setitem__("aaep", object.name) %}
        {%- elif object.object_types[0].code == 35 -%}
            {% set _=phydom_list.append(object.name) %}
        {%- endif -%}

    {%- endfor -%}
| {{table.tenant}} | {{table.app_profile}} | {{table.epg}} | {{table.aaep}} |{% if phydom_list|length > 1 %} {{phydom_list|join(", ")}} {% else %} {{phydom_list[0]}} {% endif %} |{{table.vlan}} |
{% endfor %}
{% endif %}

This event can be due to several conditions:

* None of the Switch Profiles that contain the EPG Path Binding Leaf have an Interface Profile.
* EPG has no PhysDom configured.
* The Leaf Interface Profile bound to the Switch Profile that contain the EPG Leaf Binding does not have an Interface Selector
* The Interface Policy Group associated with the Interface Selector, contained in the Leaf Interface Profile that is bound to the Switch Profiles in which the EPG Leaf Binding is present, does not have an AAEPs.
* The EPG Path Binding Leaf is not present in any Switch Profile.
* The Interface Selector that belongs to the Leaf Interface Profile, bound to the Switch Profiles that contain the EPG Leaf Binding, does not have an Interface Policy Group.
* The EPG PhysDom does not have an AAEP.
* The Static Leaf Binding Node leads to an AAEP that is present in one or more EPG PhysDom but none of those PhysDoms have a VLAN pool that contains the Static Leaf Binding Encap VLAN.
* The AAEPs associated with the Interface Policy Group, that is part of the Interface Profile belonging to the Switch Profile in which the EPG Leaf binding is present, is not associated with the AAEP configured for the PhysDom of this EPG.
* None of the AAEPs associated with the Interface Policy Group, that are part of the Interface Profile belonging to the Switch Profile in which the EPG Path binding Leaf is present, are associated with the AAEPs configured for the PhysDom of this EPG.

It is recommended to verify the configuration of the fabric access policies and EPG port path bindings used by these EPGs.

More information about EPG configuration and design can be found in the [Endpoint Group (EPG) Usage and Design Whitepaper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-731630.html) on cisco.com.
