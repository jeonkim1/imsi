<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### External EPG will not be deployed on a leaf

L3Out is configured with an External EPG, but the EPG will not be deployed on a leaf switch. Transit routing and/or connectivity to routes learnt from this L3Out will not be successful.

Table: L3Outs and ExtEPGs impacted by this issue

{% if data_source == "ndi" %}

| Tenant | VRF | L3out | EPG |
| ------ | --- | ----- | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3out", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.l3out}} | {{table.epg}} |
{% endfor %}
{% else %}

| Tenant | VRF | L3Out Name | External EPG |
| ------ | --- |------------| ------------ |
{% for event in event_list %}
{% set table = dict() %}
    {%- for object in event -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
               {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object_type.code == 28 -%}
                {% set _=table.__setitem__("l3out", object.name) %}

            {%- elif object_type.code == 7 -%}
                {% set _=table.__setitem__("ext_epg", object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{ table.tenant }} | {{ table.vrf }} | {{ table.l3out }} | {{ table.ext_epg}} |
{% endfor %}

{%- endif -%}
It is recommended to investigate L3Out configuration. Common problems are missing L3 Domain assignment or misconfiguration in Fabric Access Policies.

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com.