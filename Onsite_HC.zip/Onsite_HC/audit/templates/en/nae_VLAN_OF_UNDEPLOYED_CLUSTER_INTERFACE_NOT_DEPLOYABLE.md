<!--
category:
  - Optimization
severity: notice
affected_count: "{{event_list|length}}"
-->

#### VLAN of Undeployed Device Cluster Interface not Deployable


The VLAN of an undeployed cluster interface cannot be deployed, because it is already used by a different EPG.
Attempts to deploy the service chain will fail.

Table: Undeployable Device Clusters VLANs

| Tenant | Device Cluster | Device Cluster Interface | Leaf | Interface | VLAN | Conflicting EPG |
| ------ | -------------- | ------------------------ | ---- | --------- | ---- | --------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 486 -%}
            {% set _=table.__setitem__("device_cluster", object.name) %}
        {%- elif object.object_types[0].code == 490 -%}
            {% set _=table.__setitem__("device_cluster_intf", object.name) %}
        {%- elif object.object_types[0].code == 384 -%}
            {% set _=table.__setitem__("leaf", object.name) %}    
        {%- elif object.object_types[0].code == 233 -%}
            {% set _=table.__setitem__("interface", object.name) %}  
        {%- elif object.object_types[0].code == 310 -%}
            {% set _=table.__setitem__("vlan", object.name) %}  
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}  


        {%- endif -%}            
    {%- endfor -%}
| {{table.tenant}} | {{table.device_cluster}} | {{table.device_cluster_intf}} | {{table.leaf}} | {{table.interface}} | {{table.vlan}} | {{table.epg}} |
{% endfor %}


Suggested Next steps:

* Check whether another VLAN can be used.
* Navigate to the Device Cluster Interface and select a different encapsulation.

More information about service graphs configuration can be found in the [Cisco APIC Layer 4 to Layer 7 Services Deployment Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-4-to-layer-7-services-configuration/cisco-apic-layer-4-to-layer-7-services-deployment-guide-52x.html)