<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Incorrect contract scope for EPG

An incorrect contract scope configuration is preventing communication between Provider EPG and Consumer EPG.

Table: Contract list

{% if data_source == "ndi" %}
| List of EPGs | Contracts |
| ------------ | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "epgs" -%}
            {%- set _=table.__setitem__("epgs", object.objectValue) -%}
        {%- elif object.objectType == "contracts" -%}
            {%- set _=table.__setitem__("contracts", object.objectValue) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.epgs | join(",")}} | {{table.contracts | join(",")}} |
{% endfor %}
{% else %}
| Tenant | Contract | Provider EPG | List of Consumer EPGs |
|--------| -------- | ------------ | --------------------- |
{% for array in event_list %}
{% set table = dict() %}
{% set tenant_list = [] %}
{% set epg_list = [] %}
    {% for object in array %}
        {%- if object.object_types[0].code == 19 -%}
            {% set _=table.__setitem__("contract", object.name) %}
        {%- elif object.object_types[0].code == 16 and object.object_types[1].code == 7 -%}
            {% set _=epg_list.append(object.name) %}
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("prov_epg", object.name) %}
        {%- elif object.object_types[0].code == 2 -%}
            {% set _=tenant_list.append(object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {% if tenant_list|length > 1 %} {{tenant_list|join(", ")}} {% else %} {{tenant_list[0]}} {% endif %} | {{table.contract}} | {{table.prov_epg}} | {% if epg_list|length > 1 %} {{epg_list|join(", ")}} {% else %} {{epg_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

It is recommended to evaluate if this contract is required. If yes, contract scope should be changed to reach Consumer EPGs to which this contract is associated.

More information about Contract configuration and design can be found in the [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) on cisco.com.