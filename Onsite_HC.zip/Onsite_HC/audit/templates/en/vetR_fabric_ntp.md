<!--
category:
  - Best_Practice
  - Upgradecheck
severity: notice
affected_count: 1
-->

### Time Synchronization and NTP

Within the Cisco ACI fabric, time synchronization is a crucial capability upon which many of the monitoring, operational, and troubleshooting tasks depend. Clock synchronization is important for proper analysis of traffic flows as well as for correlating debug and fault time stamps across multiple fabric nodes.

The fabric are at the moment configured to use {{state.neighborCount}} NTP servers for time synchronization. It is recommended to use at least 2 for redundancy reasons.

More information about time synchronization and NTP can be found in the [Cisco ACI Basic Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/3-x/basic_config/b_APIC_Basic_Config_Guide_3_x/b_APIC_Basic_Config_Guide_3_x_chapter_0111.html) available on cisco.com.
