<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### L3out will not deploy for node profile due to incomplete configuration


Subnet is added to an L3Out that has incomplete configuration for the configuration checks performed.
L3Out will not deploy for the node profile. All static routes, router IDs and L3Out interface addresses associated with the node profile will not deploy.

Table: L3out that will not deploy due to incomplete configuration

{% if data_source == "ndi" %}
| Tenant | VRF | L3out | List of Nodes | Subnets |
| ------ | --- | ----- | ------------- | ------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3Outs", object.objectValue) %}
        {%- elif object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leafs", object.objectValue) %}
        {%- elif object.objectType == "subnet" -%}
            {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- elif object.objectType == "route" -%}
            {% set _=table.__setitem__("route", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.l3Outs|join(", ")}} | {{ (table.subnet+table.route) | list | reject("==","-") | list | join(", ")}} |
{% endfor %}
{% else %}
| Tenant | VRF | L3out | ExtEPG | List of Nodes | Router IDs |
| ------ | --- | ----- |------- | ------------- | ---------- |
{% for item in event_list %}
{% set table = dict() %}
{% set node_list = [] %}
{% set subnet_rid_list = [] %}
{% set instp_list = [] %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}
        {%- elif object.object_types[0].code == 28 -%}
            {% set _=table.__setitem__("l3out", object.name) %}
        {%- elif object.object_types[0].code == 384 or object.object_types[0].code == 1 -%}
            {% set _=node_list.append(object.name) %}
        {%- elif object.object_types[0].code == 253 -%}
            {% set _=subnet_rid_list.append(object.name) %}
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=instp_list.append(object.name) %}
        {%- endif -%}

    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.l3out}} | {% if instp_list|length > 1 %} {{instp_list|join(", ")}} {% else %} {{instp_list[0]}} {% endif %} | {% if node_list|length > 1 %} {{node_list|join(", ")}} {% else %} {{node_list[0]}} {% endif %} |{% if subnet_rid_list|length > 1 %} {{subnet_rid_list|join(", ")}} {% else %} {{subnet_rid_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

Suggested next steps:

* Determine if the L3Out still needs to be attached to the VRF.
* If yes determine the right router-ID, interfaces (physical, routed sub-interfaces or SVI) to be used for this L3out, the correct IP address configurations and the right set of subnets to be used on the external EPG for this L3out.
* Add the appropriate values for the above variables under the node-profile, interface profile and the networks folder under the L3out.
* Validate that there are no other faults in the L3out.

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
