<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Consumer EPG has no scope matching providers


An incorrect contract scope configuration is preventing communication between the Provider and the Consumer EPGs.
The configured contract scope is not sufficient to allow communication between the Provider and the Consumer EPGs.

Table: Consumer EPG with a contract scope not matching provider EPGs

{% if data_source == "ndi" %}
| Tenant | Application Profile | EPG | Contract |
| ------ | ------------------- |---- | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- elif object.objectType == "contracts" -%}
            {% set _=table.__setitem__("contracts", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants}} | {{table.ap}} | {{table.epg}} | {{table.contracts}} |
{% endfor %}
{% else %}
| Consumer Tenant | Consumer EPG | Provider Tenant | Provider EPG | Contract |
| --------------- | ------------ | --------------- | ------------ |----------|
{% for item in event_list %}
{% set provider_epg_list = [] %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 19 -%}
                {% set _=table.__setitem__("contract", object.name) %}
            {%- elif object_type.code == 7 -%}
                {% set epg_dict = dict() %}
                {% set epg_components = object.identifier.split("/") %}
                {% set _=epg_dict.__setitem__("epg_tenant", epg_components[1][3:]) %}
                {%- if epg_components[2][0:3] == "out" -%}
                    {% set _=epg_dict.__setitem__("epg_type", "extepg") %}
                    {% set _=epg_dict.__setitem__("l3out", epg_components[2][4:]) %}
                    {% set _=epg_dict.__setitem__("extepg", epg_components[3][6:]) %}
                {%- elif epg_components[2][0:2] == "ap" -%}
                    {% set _=epg_dict.__setitem__("epg_type", "epg") %}
                    {% set _=epg_dict.__setitem__("app_profile", epg_components[2][3:]) %}
                    {% set _=epg_dict.__setitem__("epg", epg_components[3][4:]) %}
                {%- elif epg_components[2][0:3] == "ctx" -%}
                    {% set _=epg_dict.__setitem__("epg_type", "ctx") %}
                    {% set _=epg_dict.__setitem__("vrf", epg_components[2][4:]) %}
                {%- endif -%}
                {%- for codes in object.object_types -%}
                    {%- if codes.code == 11 -%}
                        {% set _=provider_epg_list.append(epg_dict) %}
                    {%- else -%}
                        {% set _=table.__setitem__("epg_dict", epg_dict) %}
                    {%- endif -%}
                {%- endfor -%}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
    {%- for provider_epg in provider_epg_list -%}
        | {{ table.epg_dict.epg_tenant }} | {% if table.epg_dict.epg_type == "epg" %}ap:{{ table.epg_dict.app_profile }}, epg:{{ table.epg_dict.epg}}{% elif table.epg_dict.epg_type == "extepg" %}l3out:{{ table.epg_dict.l3out }}, extepg:{{ table.epg_dict.extepg}}{% elif  table.epg_dict.epg_type == "ctx" %}vrf/vzany:{{ table.epg_dict.vrf }}{% endif %}| {{ provider_epg.epg_tenant }} | {% if provider_epg.epg_type == "epg" %}ap:{{ provider_epg.app_profile }}, epg:{{ provider_epg.epg}}{% elif provider_epg.epg_type == "extepg" %}l3out:{{ provider_epg.l3out }}, extepg:{{ provider_epg.extepg}}{% elif  provider_epg.epg_type == "ctx" %}vrf/vzany:{{ provider_epg.vrf }} {% endif %} | {{ table.contract }} |
    {% endfor %}
{% endfor %}
{% endif %}

It is recommended to assess if communication between Consumer and Provider EPG is desired and configure the right contract scope.

More information about Contract configuration can be found in the [Cisco API Security Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/security/Cisco-APIC-Security-Configuration-Guide-401/b_Cisco_APIC_Security_Guide_chapter_01010.html)
