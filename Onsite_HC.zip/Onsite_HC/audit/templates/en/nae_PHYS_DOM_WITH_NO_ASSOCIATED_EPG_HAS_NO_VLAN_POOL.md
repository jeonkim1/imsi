<!--
category:
  - Best_Practice
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Physical Domain not associated with a VLAN Pool

The following domain(s) are not associated with a VLAN pool, which could indicate that they are not in used.

Table: Physical Domains not associated with a VLAN Pool

{% if data_source == "ndi" %}
| Domain Name |
| ----------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "physicalDomains" -%}
            {%- set _=table.__setitem__("physicalDomain", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.physicalDomain}} |
{% endfor %}
{% else %}
| Domain Name |
| ------ |
{% for domain in event_list %}
{% if domain.0.name != "default" %}
| {{domain.0.name}} |
{% endif %}
{% endfor %}
{% endif %}

If these domain(s) are not in use, then it is recommended to remove them in order to simplify the configuration.

More information about domain configuration can be found in the [Cisco APIC Layer 2 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-2-configuration/cisco-apic-layer-2-networking-configuration-guide-52x/epgs-52x.html) on cisco.com.
