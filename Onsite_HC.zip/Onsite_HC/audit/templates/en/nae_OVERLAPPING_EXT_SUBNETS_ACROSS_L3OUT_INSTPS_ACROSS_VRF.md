<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Overlapping external subnets configured across L3Out External EPGs belonging to different VRF

Communication between EPGs across VRFs is failing due to overlapping ext instp subnet address.
Overlapping subnet configuration is causing intermittent connectivity problem between Provider and Consumer EPGs.

Table: External EPG (InstP) with Overlapping External Subnets across VRFs

{% if data_source == "ndi" %}
| Tenant | VRF | BD | App Profile | EPG | L3Out | Contract |
| ------ | --- | -- | ----------- | --- | ----- | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "vrfs" -%}
            {%- set _=table.__setitem__("vrfs", object.objectValue) -%}
        {%- elif object.objectType == "contracts" -%}
            {%- set _=table.__setitem__("contracts", object.objectValue) -%}
        {%- elif object.objectType == "l3Outs" -%}
            {%- set _=table.__setitem__("l3Outs", object.objectValue) -%}
        {%- elif object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "epgs" -%}
            {%- set _=table.__setitem__("epgs", object.objectValue) -%}
        {%- elif object.objectType == "bds" -%}
            {%- set _=table.__setitem__("bds", object.objectValue) -%}
        {%- elif object.objectType == "appProfiles" -%}
            {%- set _=table.__setitem__("appProfiles", object.objectValue) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.bds|join(", ")}} | {{table.appProfiles|join(", ")}} | {{table.epgs|join(", ")}} | {{table.l3Outs|join(", ")}} | {{table.contracts|join(", ")}} |
| a | b | c | d | e | f | g |
{% endfor %}
{% else %}
| Tenant | VRF | L3Out List | Ext EPG List | Contract |
| ------ | --- | -----------| ------------ | -------- |
{% for item in event_list %}
{% set l3out_list = [] %}
{% set instp_list = [] %}
{% set vrf_list = [] %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 4 -%}
            {% set _=vrf_list.append(object.name) %}
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=instp_list.append(object.name) %}
        {%- elif object.object_types[0].code == 28 -%}
            {% set _=l3out_list.append(object.name) %}
        {%- elif object.object_types[0].code == 19 -%}
            {% set _=table.__setitem__("contract", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{ table.tenant }} | {% if vrf_list|length > 1 %} {{vrf_list|join(", ")}} {% else %} {{vrf_list[0]}} {% endif %} | {% if l3out_list|length > 1 %} {{l3out_list|join(", ")}} {% else %} {{l3out_list[0]}} {% endif %} | {% if instp_list|length > 1 %} {{instp_list|join(", ")}} {% else %} {{instp_list[0]}} {% endif %} | {{table.contract}} |
{% endfor %}
{% endif %}

* Check if the L3out's EPG are required to communicate to each other using the listed contract.
* If connectivity is required, ensure that the L3out's external subnets are unique across VRFs.
* If connectivity is not required determine if you can remove the consumer from the contract association.

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
