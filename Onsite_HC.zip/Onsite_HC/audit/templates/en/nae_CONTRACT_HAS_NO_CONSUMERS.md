<!--
category:
  - Best_Practice
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Contract has no consumer EPG

The following contract(s) does not have any consumer EPG(s) defined and are therefore not being used to filter any traffic.

Table: Contract has no consumer EPG

{% if data_source == "ndi" %}

| Tenant | Contract |
| ------ | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "contracts" -%}
                {% set _=table.__setitem__("contract", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.contract}} |
{% endfor %}
{% else %}

| Tenant | Contract |
| ------ | -------- |
{% for contract in event_list %}
| {{contract.1.name}} | {{contract.0.name}} |
{% endfor %}

{%- endif -%}

If these contract(s) are not supposed to be in use, then it is recommended to remove them in order to simplify the configuration.

More information about Contract configuration can be found in the [Cisco API Security Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/security/Cisco-APIC-Security-Configuration-Guide-401/b_Cisco_APIC_Security_Guide_chapter_01010.html)