<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Endpoint IP learned Outside Bridge Domain Subnet (with Enforce Subnet Check for IP Learning enabled)

A number of endpoints has been learned with an IP address that falls outside the Bridge Domain Subnet(s) although the Bridge Domain has been configured with "Enforce Subnet Check for IP Learning". This may lead to undesired Layer-2 communication being permitted, while layer-3 communication will not be permitted for Endpoints learned on subnets not matching Bridge Domain subnets.

Table: Endpoint IP learned Outside Bridge Domain Subnet (with Enforce Subnet Check for IP Learning enabled)
{% if data_source == "ndi" %}

| Leaf(s) | EP MAC | EP IP | Tenant | VRF | BD | EPG | Interface |
| ------------- | ------ | ----- | ------ | --- | -- | --- | --------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "macs" -%}
            {%- set _=table.__setitem__("macs", object.objectValue[0]) -%}
        {%- elif object.objectType == "bds" -%}
                {% set _=table.__setitem__("bds", object.objectValue[0]) %}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epgs", object.objectValue[0]) %}
        {%- elif object.objectType == "tenants" -%}
            {% set _=table.__setitem__("tenants", object.objectValue) %}
        {%- elif object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leafs", object.objectValue) %}
        {%- elif object.objectType == "interfaces" -%}
            {% set _=table.__setitem__("interfaces", object.objectValue[0]) %}
        {%- elif object.objectType == "encaps" -%}
            {% set _=table.__setitem__("encaps", object.objectValue[0]) %}
        {%- elif object.objectType == "ips" -%}
            {% set _=table.__setitem__("ips", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leafs|join(", ")}} | {{table.macs}} | {{table.ips}} | {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.bds}} | {{table.epgs}} | {{table.interfaces}} |
{% endfor %}

{%else%}

| Leaf(s) | EP MAC | EP IP | Tenant | VRF | BD | EPG | Interface |
| ------------- | ------ | ----- | ------ | --- | -- | --- | --------- |
{% for item in event_list %}
{% set table = dict() %}
{% set leaf_list = []%}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}

        {%- elif object.object_types[0].code == 3 -%}
            {% set _=table.__setitem__("bd", object.name) %}

        {%- elif object.object_types[0].code == 304 -%}
            {% set _=table.__setitem__("ep_mac", object.name) %}

        {%- elif object.object_types[0].code == 327 -%}
            {% set _=table.__setitem__("ep_ip", object.name) %}

        {%- elif object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}

        {%- elif object.object_types[0].code == 1 or object.object_types[0].code == 384 -%}
            {% set _=leaf_list.append(object.name) %}

        {%- elif object.object_types[0].code == 233 -%}
            {% set interface_components = object.identifier.split("/") %}
            {% set interface_node = " (" ~ interface_components[2] ~ ")" %}
            {% set _=interface_list.append(object.name ~ interface_node) %}

        {%- endif -%}

    {%- endfor -%}
| {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} | {% if table.ep_mac != "" %}{{ table.ep_mac }}{% else %} - {% endif %} | {% if table.ep_ip != "" %}{{ table.ep_ip }} {% else %} - {% endif %} | {{table.tenant}} | {{table.vrf}} | {{table.bd}} | {{table.epg}} | {% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %} |
{% endfor %}
{%endif%}

It is recommended to use the following steps to investigate the Endpoint learning issue:

1. Check the Endpoints listed above to be sure they are configured with correct IP, network mask, and default gateway
2. Check the Endpoints listed above to be sure they have been learned with the right encapsulation (VLAN ID), EPG, and BD assignment.
3. If the Endpoint was learned locally before enabling the "Enforce subnet check" option, then the Endpoint would need to be cleared manually
4. If none of the previous steps solves the problem, then it is recommended to open a TAC case in order to investigate the issue further

More information about Endpoint learning can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html) available on cisco.com.
