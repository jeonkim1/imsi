<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Application EPG in Unenforced VRF has a Contract.

The application EPG is attached to a bound contract and the VRF is not in enforced mode.
Any EPG using the contract and in this VRF will continue to pass traffic that may be unintended.

Table: EPGs with Contract in Unenforced VRF.

{% if data_source == "ndi" %}
| Tenant | Application Profile | VRF | EPG Name |
| ------ | ------------------- | --- | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.ap}} | {{table.vrf}} | {{table.epg}} |
{% endfor %}
{% else %}
| EPG |  Application Profile | VRF | Contract | Tenant |
| --- |  ------------------- | --- | -------- | ------ |
{% for item in event_list %}
{% set table = dict() %}
{% set tenant_list = [] %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}
        {%- elif object.object_types[0].code == 8 -%}
            {% set _=table.__setitem__("app_profile", object.name) %}
        {%- elif object.object_types[0].code == 2 -%}
            {% set _=tenant_list.append(object.name) %}
        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}
        {%- elif object.object_types[0].code == 19 -%}
            {% set _=table.__setitem__("contract", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{ table.epg }} | {{ table.app_profile }} | {{ table.vrf }} | {{ table.contract }} | {% if tenant_list|length > 1 %} {{tenant_list|join(", ")}} {% else %} {{tenant_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

If it is intended to have VRF in unenforced mode, please disassociate the contract from the EPGs, as it is uneffective.
Any EPG in VRF in Unenforced mode will pass traffic.


More information on Contracts and VRF in unenforced mode can be found in [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) Whitepaper on cisco.com