<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Leaf interface consumed by EPG has link down

The following leaf interfaces are configured by Fabric Access Policies and are consumed by an EPG but has link down.

Table: Leaf interface consumed by EPG has link down

{% if data_source == "ndi" %}
| Leaf | Interface |
| ---- | --------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "leafs" -%}
            {%- set _=table.__setitem__("leafs", object.objectValue[0]) -%}
        {%- elif object.objectType == "interfaces" -%}
                {% set _=table.__setitem__("interfaces", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leafs}} | {{table.interfaces}} |
{% endfor %}
{% else %}
| Leaf | Interface |Associated Interface Policy Group | Associated Interface Profile | Associated AAEP |
| ---- | --------- | --------------------------------- | ---------------------------- | --------------- |
{% for interface in event_list %}
| {{interface.1.name}} | {{interface.0.name}} | {{interface.3.name}} | {{interface.2.name}} | {{interface.4.name}} |
{% endfor %}
{% endif %}

It is recommended to investigate why these interfaces have link down and resolve the issue.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)
