<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
affected_count: 1
-->

### BFD for Fabric Facing Interfaces

It is recommended as a best practice to have Bidirectional Forwarding Detection (BFD) **disabled** on fabric facing interfaces, as it may in some scenarios cause undesired outages.

More information about BFD for Fabric Facing Interface can be found in the [ACI Design Guide](https://www.cisco.com/c/en/us/td/docs/dcn/whitepapers/cisco-application-centric-infrastructure-design-guide.html#BidirectionalForwardingDetectionBFDforfabriclinks) available on cisco.com.
