<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### EPG has no Bridge Domain

The following EPG(s) are not associated with a Bridge Domain and will not be deployed, which results in endpoints associated with these EPGs having no connectivity.

Table: EPG has no Bridge Domain
{% if data_source == "ndi" %}

| Tenant | Application Profile | EPG |
| ------ | ------------------- |---- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants}} | {{table.ap}} | {{table.epg}} |
{% endfor %}
{% else %}

| Tenant | Application Profile | EPG |
| ------ |-------------------- | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 7 -%}
                {% set _=table.__setitem__("epg", object.name) %}

            {%- elif object_type.code == 8 -%}
                {% set _=table.__setitem__("app_profile", object.name) %}

            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}
| {{table.tenant}} | {{table.app_profile}} | {{table.epg}} |
{% endfor %}
{%- endif -%}

If these EPG(s) are supposed to be used, then it is recommended to associate them with the correct Bridge Domain. If they are not supposed to be used, then it is recommended to remove the EPG(s) to simplify the configuration.

More information about EPG configuration can be found in the [Cisco ACI Endpoint Groups (EPG) Usage and Design](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-731630.html) Whitepaper on cisco.com
