<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Preferred group APIC Policy and Switch Hardware mismatch

For given VRFs that are in enforced mode and enabled Preferred Group feature, permit rule for EPG traffic in a Group is not programmed correctly on the leaf.

Table: Leaf switches where policy is violated

| Tenant | VRF | Leaf switches affected |
| ------ | --- | ---------------------- |
{% if data_source == "ndi" %}
{% set leaf_list = [] %}
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "vrfs" -%}
            {%- set _=table.__setitem__("vrf", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "leafs" -%}
            {% for if in object.objectValue %}
                {% set _=leaf_list.append(if) %}
            {% endfor %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{leaf_list|join(", ")}} |
{% endfor %}
{% else %}
{% for event in event_list %}
{% set leaf_list = [] %}
{% set table = dict() %}
    {%- for object in event -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
               {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object_type.code == 384 -%}
                {% set _=leaf_list.append(object.name) %}

            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{ table.tenant }} | {{ table.vrf }} | {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}
{%- endif -%}

It is likely a programming issue within switch Hardware Abstraction Layer (HAL). It is recommended to collect a techsupport from leaf switches and contact Cisco TAC for assistance with Root Cause Analysis (RCA) and providing a workaround.

