<!--
category:
  - Best_Practice
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### VRF has no Bridge Domain

The following VRF(s) do not have any Bridge Domains associated.

Table: VRF has no Bridge Domain

{% if data_source == "ndi" %}
| Tenant | VRF |
| ------ | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} |
{% endfor %}
{% else %}
| Tenant | VRF |
| ------ | --- |
{% for vrf in event_list %}
| {{vrf.1.name}} | {{vrf.0.name}} |
{% endfor %}
{% endif %}

If these VRFs(s) are not in use, then it is recommended to remove them in order to simplify the configuration.

More information about VRF configuration can be found in the [Cisco API Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_010.html)
