<!--
category:
  - Best_Practice
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Tenant has not Application Profile

The following tenants has no application profile configured which may indicate a misconfiguration.

Table: Tenant with no Application Profile

| Tenant |
| ------ |
{% if data_source == "ndi" %}
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} |
{% endfor %}
{% else %}
{% for tenant in event_list %}
| {{tenant.0.name}} |
{% endfor %}
{% endif %}

It is recommended to review the configuration of these tenants to check if the configuration of one or more application profiles has been omitted by mistake.

More information about tenant configuration can be found in the [Cisco APIC Basic Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/3-x/basic_config/b_APIC_Basic_Config_Guide_3_x/b_APIC_Basic_Config_Guide_3_x_chapter_0101.html)
