<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Overlapping Subnets between Bridge Domain and External Learned Routes in same VRF

The following Bridge Domains has been configured with a subnet that are overlapping with routes learned through a L3Out within the same VRF. This may lead to sub-optimal routing due to the overlapping IP addresses, and next-hop resolution for one or more routes may fail.

Table: Bridge Domains Configured Subnets that Overlap with External Learnt Routes

{% if data_source == "ndi" %}
| Tenant | VRF | BD | EPG | Subnet |
| ------ |---- | -- | --- | ------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "subnet" -%}
            {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bds", object.objectValue) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epgs", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.bds|join(", ")}} | {{table.epgs|join(", ")}} | {{table.subnet|join(", ")}} |
{% endfor %}
{% else %}
| Tenant | VRF | BD | Subnet | Route | L3Out with Overlapping Route | Leaf(s) with Overlapping Route |
| ------ |---- | -- | ------ | ----- | ---------------------------- | ------------------------------ |
{% for item in event_list %}
{% set table = dict() %}
{% set l3out_list = []%}
{% set leaf_list = []%}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object.object_types[0].code == 3 -%}
                {% set _=table.__setitem__("bd", object.name) %}

            {%- elif object_type.code == 253 -%}
                {% set _=table.__setitem__("subnet", object.name) %}

            {%- elif object_type.code == 254 -%}
                {% set _=table.__setitem__("route", object.name) %}

            {%- elif object_type.code == 28 -%}
                {% set _=l3out_list.append(object.name) %}

            {%- elif object_type.code == 384 or object_type.code == 385 -%}
                {% set _=leaf_list.append(object.name) %}

            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}

| {{table.tenant}} | {{table.vrf}} | {{table.bd}} | {{table.subnet}} | {{table.route}} | {% if l3out_list|length > 1 %} {{l3out_list|join(", ")}} {% else %} {{l3out_list[0]}} {% endif %} | {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

It is recommended to determine the right location of the subnet. If the correct location is internal to ACI, resolve the conflict by making changes in the external network devices so that the subnet is only advertised out from ACI. If the correct location is external to ACI, remove overlapping subnet from within the ACI configuration of the mentioned Bridge Domain.

More information about BD subnet configuration can be found in the [Cisco ACI Layer-3 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/L3-configuration/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401_chapter_01001.html) on cisco.com
