<!--
category:
  - Best_Practice
severity: warning
affected_count: 1
-->

### Enforce Subnet Check

The Enforce Subnet Check option was first introduced in APIC Releases 2.2(2q)
In APIC Release 2.2(2q), the option is located at Fabric > Access Policies > Global Policies > Fabric Wide Setting
In APIC Release 3.0(2h) and later, it is located at System > System Settings > Fabric Wide Setting

More information about Enforce Subnet Check can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html#EnforceSubnetCheck) available on cisco.com.
