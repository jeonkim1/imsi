<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Contract has invalid filters

The following Contract is using a filter that does not exist or was deleted.

Table: Contract with invalid filters

{% if data_source == "ndi" %}
| Tenant | Contract |
| ------ | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "contracts" -%}
                {% set _=table.__setitem__("contract", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.contract}} |
{% endfor %}
{% else %}
| Tenant | Contract | Subject | Filter |
| ------ | -------- | ------- |------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 20 -%}
            {% set _=table.__setitem__("subject", object.name) %}
        {%- elif object.object_types[0].code == 19 -%}
             {% set _=table.__setitem__("contract", object.name) %}
        {%- elif object.object_types[0].code == 2 -%}
             {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 21 -%}
             {% set _=table.__setitem__("filter", object.name) %}
        {%- endif -%}
    {%- endfor -%}
{{ table.tenant }} | {{ table.contract }} | {{ table.subject }} | {{ table.filter }}
{% endfor %}
{% endif %}

Determine if the subjects/filters identified are required. If the subjects are required, then assign existing filters, or recreate any filters that were accidentally deleted, that meet your requirements.
Delete the subjects that are no longer required.
If the contract(s) is no longer required, determine if the contract can be deleted.
If the contract(s) are supposed to be in use, then the contracts should be configured. If they the contract(s) are not supposed to be used, then it is recommended to remove them from the EPGs consuming them.

More information about Contract configuration can be found in the [Cisco API Security Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/security/Cisco-APIC-Security-Configuration-Guide-401/b_Cisco_APIC_Security_Guide_chapter_01010.html)
