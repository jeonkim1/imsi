<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Bridge Domain deployment error

The deployment of the following bridge domain(s) have failed on one or more leafs.

Table: Bridge Domain deployment error

{% if data_source == "ndi" %}
| Tenant | VRF | Affected EPG(s) | Subnet |
| ------ | --- | --- | ------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- elif object.objectType == "subnet" -%}
                {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- elif object.objectType == "epgs" -%}
                {% set _=table.__setitem__("epg", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {% if table.epg|length > 1 %} {{table.epg|join(", ")}} {% else %} {{table.epg[0]}} {% endif %} | {% if table.subnet|length > 1 %} {{table.subnet|join(", ")}} {% else %} {{table.subnet[0]}} {% endif %} |
{% endfor %}
{% else %}
| Tenant | Bridge Domain |
| ------ | ------------- |
{% for bd in event_list %}
| {{bd.2.name}} | {{bd.1.name}} |
{% endfor %}
{% endif %}

It is recommended to verify the configuration and faults related to these bridge domains in order to identify the root cause of why the deployment failed.

More information about Bridge Domain configuration can be found in the [Cisco API Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_010.html)
