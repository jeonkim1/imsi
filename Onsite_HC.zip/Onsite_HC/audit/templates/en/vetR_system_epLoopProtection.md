<!--
category:
  - Best_Practice
severity: warning
affected_count: 1
-->

### Endpoint Loop Protection

Ep Loop Protection is disabled by default.

**Prior to APIC Release 3.0**, this option is located at System > System Settings > Endpoint Controls > Ep Loop Protection.

**For APIC Release 3.0 and later**, this option is located at System > System Settings > Endpoint Controls > Ep Loop Protection.

The hold interval is the one defined in the BD level End Point Retention Policy.

More information about Endpoint Loop Protection can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html#EpLoopProtection) available on cisco.com.
