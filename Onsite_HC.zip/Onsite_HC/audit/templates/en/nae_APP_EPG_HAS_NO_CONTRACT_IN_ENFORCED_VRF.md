<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Application EPG has no contracts in enforced VRF

The following EPGs are not providing or consuming any contracts although they belong a VRF that operates in enforced mode. This means that no traffic is allowed to or from these EPGs.

Table: EPG with no contracts in enforced VRF

{% if data_source == "ndi" %}
| Tenant | Application Profile | EPG Name |
| ------ | ------------------- | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.ap}} | {{table.epg}} |
{% endfor %}
{% else %}
| Tenant | Application Profile | EPG Name |
| ------ | ------------------- | -------- |
{% for epg in event_list %}
{% if epg.0.name != "ave-ctrl" %}
| {{epg.2.name}} | {{epg.1.name}} | {{epg.0.name}} |
{% endif %}
{% endfor %}
{% endif %}

If these EPGs should not be isolated from a policy point of view, then it is recommended to verify the configuration of these EPGs.

More information about EPG configuration and design can be found in the [Endpoint Group (EPG) Usage and Design Whitepaper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-731630.html)
