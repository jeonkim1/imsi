<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Overlapping external subnets configured across L3Out External EPGs belonging to the same VRF


Overlapping ext subnets have been configured under L3Out EPGs belonging to the same VRF.
The impact is that incoming packet from external network will potentially experience intermittent or complete loss of connectivity.

Table: External EPG (InstP) with Overlapping External Subnets.
{% if data_source == "ndi" %}
| Tenant | VRF | L3Out List | Ext EPG List |
| ------ | --- | -----------| ------------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "l3Outs" -%}
                {% set _=table.__setitem__("l3Outs", object.objectValue) %}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epgs", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.l3Outs|join(", ")}} | {{table.epgs|join(", ")}} |
{% endfor %}

{% else %}
| Tenant | VRF | L3Out List | Ext EPG List |
| ------ | --- | -----------| ------------ |
{% for item in event_list %}
{% set l3out_list = [] %}
{% set instp_list = [] %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=instp_list.append(object.name) %}
        {%- elif object.object_types[0].code == 28 -%}
            {% set _=l3out_list.append(object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{ table.tenant }} | {{ table.vrf }} | {% if l3out_list|length > 1 %} {{l3out_list|join(", ")}} {% else %} {{l3out_list[0]}} {% endif %} | {% if instp_list|length > 1 %} {{instp_list|join(", ")}} {% else %} {{instp_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

It is recommended to configure unique external subnets across L3outs in the VRF.

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
