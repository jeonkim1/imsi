<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Overlapping subnets have been configured under BDs/EPGs belonging to the same VRF

Overlapping subnets have been configured under BDs/EPGs belonging to the same VRF.

Table: Overlapping Subnets.

{% if data_source == "ndi" %}
| Subnet | VRF | Tenant | BD with overlapping subnets | EPG with overlapping subnets |
| ------ | --- | ------ | --------------------------- | ---------------------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epgs", object.objectValue) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bds", object.objectValue) %}
        {%- elif object.objectType == "subnet" -%}
                {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.subnet|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.tenants|join(", ")}} | {{table.bds|join(", ")}} | {{table.epgs|join(", ")}} |
{% endfor %}
{% else %}
| Subnet | VRF | Tenant | BD with overlapping subnets | EPG with overlapping subnets |
| ------ | --- | ------ | --------------------------- | ---------------------------- |
{% for item in event_list %}
{% set bdsub_list = [] %}
{% set epgsub_list = [] %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 253 -%}
            {% set _=table.__setitem__("subnet", object.name) %}
        {%- elif object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}
        {%- elif object.object_types[0].code == 3 -%}
            {% set _=bdsub_list.append(object.name) %}
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=epgsub_list.append(object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{ table.subnet }} | {{ table.vrf }} | {{ table.tenant }} | {% if bdsub_list|length==0 %} none {% elif bdsub_list|length > 1 %} {{bdsub_list|join(", ")}} {% else %} {{bdsub_list[0]}} {% endif %} | {% if epgsub_list|length==0 %} none {% elif epgsub_list|length > 1 %} {{epgsub_list|join(", ")}} {% else %} {{epgsub_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

Devices that are assigned IPs from the overlapping IP subnet ranges will potentially experience intermittent or complete loss of connectivity.
Overlapping subnets in the same VRF must be avoided.

For all the BDs/EPGs listed, determine the correct BD/EPG association for the subnet.
Configure unique subnets across BDs/EPGs in a VRF.

More information about BD subnet configuration can be found in the [Cisco ACI Layer-3 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/L3-configuration/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401_chapter_01001.html) on cisco.com
