<!--
category:
  - Best_Practice
  - Upgradecheck
severity: warning
affected_count: 1
-->

### Encrypted Backups

ACI backups are **unencrypted** by default. In an unencrypted backup, only non-sensitive configuration data is backed up. In an encrypted backup, passwords are encrypted, and backed up in addition to the standard, unencrypted configuration.

Without encrypted backups, all passwords and sensitive data would have to be manually configured on restore. This can break logins and integration with external systems, such as AAA, SNMP, and VMM integration, significantly increasing MTTR. Because of this, it's recommended to run encrypted backups at regular scheduled intervals.

Note: Encrypted backups do not encrypt the full backup, but only sensitive data non-sensitive data remains unencrypted.

It is recommended to encrypted backups, as backup are currently unencrypted.

Please reference the [Cisco ACI Configuration Files: Import and Export TechNote](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/kb/b_KB_Using_Import_Export_to_Recover_Config_States.html#concept_15E2D7F6CCF24A98A40CBCB9A8302B81) for information about how to enable encrypted backups.
