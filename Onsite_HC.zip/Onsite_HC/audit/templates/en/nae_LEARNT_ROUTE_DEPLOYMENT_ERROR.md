<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Learnt route deployment error

A learnt route belonging to an L3Out is not deployed on the leaf switch(es) where it is expected to be deployed.
External connectivity to this learned prefix is lost.

Table: Learnt routes with deployment error

{% if data_source == "ndi" %}
| Route | L3Out |
| ----- | ----- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "l3Outs" -%}
            {%- set _=table.__setitem__("l3Outs", object.objectValue) -%}
        {%- elif object.objectType == "route" -%}
            {% set _=table.__setitem__("route", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.route|join(", ")}} |{{table.l3Outs|join(", ")}} |
{% endfor %}
{% else %}
| Tenant | Route | L3Out | VRF | Node(s) with missing learnt route |
| ------ |------ | ----- | --- | --------------------------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set leaf_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object_type.code == 254 -%}
                {% set _=table.__setitem__("route", object.name) %}

            {%- elif object_type.code == 28 -%}
                {% set _=table.__setitem__("l3out", object.name) %}

            {%- elif object_type.code == 384 -%}
                {% set _=leaf_list.append(object.name) %}

            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}

| {{table.tenant}} | {{table.route}} | {{table.l3out}} | {{table.vrf}} |  {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

Failing conditions that bring up this event are as follow:

* Learned route or golf route not deployed on remote leafs where it should be deployed due to contracts across VRFs.
* Learned route or golf route not deployed on remotes leafs.
* Learned route or golf route not deployed on remote leafs where it should be deployed due to contracts across VRFs.


It is recommended to collect a techsupport from the affected leaf switch and contact Cisco TAC for assistance with root causing the issue.


More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
