<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### The device cluster of device type "VIRTUAL" has no VMM domain association

The device cluster of device type "VIRTUAL" has no VMM domain association.

Table: Device Clusters missing VMM domain associateion.
{% if data_source == "ndi" %}
| Device Cluster |
| -------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "deviceCluster" -%}
            {%- set _=table.__setitem__("deviceCluster", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.deviceCluster}} |
{% endfor %}
{% else %}
| Device Cluster |
| -------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 486 -%}
            {% set _=table.__setitem__("deviceCluster", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.deviceCluster}} |
{% endfor %}
{%endif%}

More information about how to deploy L4L7 can be found in [Cisco APIC Layer 4 to Layer 7 Services Deployment Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-4-to-layer-7-services-configuration/cisco-apic-layer-4-to-layer-7-services-deployment-guide-52x.html).

More information about VMM integration can be found in [Cisco ACI Virtualization Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/virtualization-guide/cisco-aci-virtualization-guide-52x.html)