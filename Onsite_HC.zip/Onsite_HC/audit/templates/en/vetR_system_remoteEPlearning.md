<!--
category:
  - Best_Practice
severity: notice
affected_count: 1
-->

### Remote Endpoint Learning

Cisco ACI learns a MAC or IP address as a remote endpoint when a packet comes into a Cisco ACI leaf switch from another leaf switch through a spine switch.

When a packet is sent from one leaf to another leaf, Cisco ACI encapsulates the original packet with an outer header representing the source and destination leaf Tunnel Endpoint (TEP) and the Virtual Extensible LAN (VXLAN) header, which contains the bridge domain or VRF information of the original packet

In most ACI environments, it is recommended to activate the fabric-wide feature “Disable Remote EP Learn”. In APIC Release 3.0(1k) and later, this option is located at System > System Settings > Fabric Wide Setting. This option is disabled by default.

When this feature is enabled, remote IP endpoint learning at the VRF instance is disabled on border leaf switches. However, border leaf may still learn remote IP endpoints from IP multicast routing packets, because of a limitation in the Cisco ACI IP multicast routing implementation. This exception applies only when a second-generation switch is used as the border leaf because Cisco ACI IP multicast routing is supported only starting with second-generation switches. This feature doesn’t disable remote MAC endpoint learning.

More information about Remote Endpoint Learning can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html#Remoteendpointlearning) available on cisco.com.
