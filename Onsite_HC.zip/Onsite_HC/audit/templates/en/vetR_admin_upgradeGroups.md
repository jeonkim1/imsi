<!--
category:
  - Best_Practice
  - Upgradecheck
severity: warning
{% set count = namespace(value = 0) %}
{% if state.hasNodesNotInGroup == true %}
{% set count.value = count.value + nodesNotInGroup|length %}
{% endif %}
{% if state.hasNonRedundantAPICs == true %}
{% set count.value = count.value + 1 %}
{% endif %}
{% if state.hasNonRedundantVPCs == true %}
{% set count.value = count.value + nonRedundantVPCNodes|length %}
{% endif %}
{% if state.hasNonRedundantSpines == true %}
{% set count.value = count.value + 1 %}
{% endif %}
{% if state.hasMalformedVersionString == true %}
{% set count.value = count.value + malformedVersions|length %}
{% endif %}
affected_count: {{count.value}}
-->

### Software Upgrade Groups

When upgrading software in ACI, maintenance groups are used to control the order in which nodes are upgraded as well as the number of nodes that are upgraded in parallel. In addition to this does the APIC controller automatically ensure that only one side of a vPC switch pair are upgraded at a time.

More information about how to upgrade an ACI fabric can be found in the [Operating Cisco ACI](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/1-x/Operating_ACI/guide/b_Cisco_Operating_ACI/b_Cisco_Operating_ACI_chapter_0101.html) as well as in the [Cisco ACI Upgrade Checklist](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/kb/Cisco-ACI-Upgrade-Checklist.html), both available on cisco.com.

{% if state.hasNodesNotInGroup == true %}

#### Nodes not in a Maintenance Group

The following nodes are not assigned to a maintenance group.

Table: Nodes not in a Maintenance Group

| Node ID |
| ------- |
{% for entry in nodesNotInGroup %}
{{ entry }} |
{% endfor %}

It is recommended to assign these nodes to a maintenance group prior to attempting any software upgrades
{% endif %}

{% if state.hasNonRedundantAPICs == true %}

#### Non-Redundant APICs

The following non-redundantly connected APICs are present in the fabric.

To avoid issues during the upgrade is it recommended to attache the APIC to two leafs and place these leafs in different maintenance groups.
{% endif %}

{% if state.hasNonRedundantVPCs == true %}

#### Non-Redundant vPC Switch Pairs

The following nodes are part of a vPC switch pair where both nodes being assigned to the same maintenance group.

Table: Non-Redundant vPC Switch Pair

| Node ID |
| ------- |
{% for entry in nonRedundantVPCNodes %}
{{ entry }} |
{% endfor %}

Please note that the list of nodes above may include nodes that are not explicitly assigned to a maintenance group.

It is recommended to distribute the nodes in a vPC switch pairs across maintenance groups and for all vPC interfaces have one or more member link to each leaf switch.

{% endif %}

{% if state.hasNonRedundantSpines == true %}

#### Non-Redundant Spine(s)

The spines in the fabric are all assigned to the same maintenance group. It is highly recommended to distribute the spines across maintenance groups so that only a single spine is upgraded at a time.
{% endif %}

{% if state.hasGracefulMaintSingleSpine == true %}

#### Graceful Maintenance enabled on Spine

The fabric (or one of the pods within the fabric) is equipped with a single spine and that spine has graceful maintenance enabled. This is not a supported configuration and may cause issues during a software upgrade.

It is recommended to either add one or more spines to the fabric or enable graceful maintenance.
{% endif %}

{% if state.hasMalformedVersionString == true %}

#### Malformed Version String

The target firmware policy are configured with a malformed version string which may cause issues during a software upgrade. The table below lists the version(s) that the policy are configured with.

Table: Malformed Version String

| Version |
| ------- |
{% for entry in malformedVersions %}
{{ entry }} |
{% endfor %}

It is recommended to verify the configuration of the firmware policy prior to attempting a software upgrade.
{% endif %}
