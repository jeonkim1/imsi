<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
affected_count: "{{event_list|length}}"
-->

#### Overlapping Subnets between Bridge Domain (Route Leaking) and Learned Routes across VRFs

Communication between the following EPGs below are failing due to overlapping subnets. This subnet overlap is caused by a route learned thorough a L3Out to overlap with a BD subnet that are leaked between VRFs.

Table: Overlapping Subnets between Bridge Domain (Route Leaking) and Learned Routes across VRFs

| Subnet | Route | BD (Subnet Owner ) | EPGs | Route Leak Contract(s) | L3Outs| Nodes |
| ------ |------ | -- | ---- | ---------------------- | ----- | ----- |
{% for item in event_list %}
{% set table = dict() %}
{% set epg_list = []%}
{% set l3out_list = []%}
{% set contract_list = []%}
{% set leaf_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 7 -%}
                {% set epg_entry = dict() %}
                {% set epg_components = object.identifier.split("/") %}
                {% set epg_tenant_name_components = epg_components[1].split("-") %}
                {% set epg_app_profile_name_components = epg_components[2].split("-") %}
                {% set epg_name_components = epg_components[3].split("-") %}
                {% set _=epg_entry.__setitem__("tenant", epg_tenant_name_components[1:]) %}
                {% set _=epg_entry.__setitem__("app_profile", epg_app_profile_name_components[1:]) %}
                {% set _=epg_entry.__setitem__("epg", object.name) %}
                {% set _=epg_entry.__setitem__("dn", object.identifier) %}
                {% set _=epg_list.append(epg_entry) %}
            {%- elif object_type.code == 3 -%}
                {% set bd_entry = dict() %}
                {% set bd_components = object.identifier.split("/") %}
                {% set bd_tenant_name_components = bd_components[1].split("-") %}
                {% set _=bd_entry.__setitem__("tenant", bd_tenant_name_components[1:]) %}
                {% set _=bd_entry.__setitem__("name", object.name) %}
                {% set _=bd_entry.__setitem__("dn", object.identifier) %}
                {% set _=table.__setitem__("bd", bd_entry) %}
            {%- elif object_type.code == 253 -%}
                {% set _=table.__setitem__("subnet", object.name) %}
            {%- elif object_type.code == 254 -%}
                {% set _=table.__setitem__("route", object.name) %}
            {%- elif object_type.code == 28 -%}
                {% set l3out_entry = dict() %}
                {% set l3out_components = object.identifier.split("/") %}
                {% set l3out_tenant_name_components = l3out_components[1].split("-") %}
                {% set _=l3out_entry.__setitem__("tenant", l3out_tenant_name_components[1:]) %}
                {% set _=l3out_entry.__setitem__("l3out", object.name) %}
                {% set _=l3out_entry.__setitem__("dn", object.identifier) %}
                {% set _=l3out_list.append(l3out_entry) %}
            {%- elif object_type.code == 19 -%}
                {% set _=contract_list.append(object.name) %}
            {%- elif object_type.code == 384 or object_type.code == 385 -%}
                {% set _=leaf_list.append(object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}

| {{table.subnet}} | {{table.route}} | {{table.bd.name}} (tenant: {{table.bd.tenant|join("-")}}) | {% if epg_list|length > 1 %} {% for entry in epg_list %} {{entry.epg}} (tenant: {{entry.tenant|join("-")}}), {% endfor %} {% else %} {{epg_list[0].epg}} (tenant: {{epg_list[0].tenant|join("-")}}) {% endif %} | {% if contract_list|length > 1 %} {{contract_list|join(", ")}} {% else %} {{contract_list[0]}} {% endif %} | {% if l3out_list|length > 1 %} {% for entry in l3out_list %} {{entry.l3out}} (tenant: {{entry.tenant|join("-")}}), {% endfor %} {% else %} {{l3out_list[0].l3out}} (tenant: {{l3out_list[0].tenant|join("-")}}) {% endif %} | {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}

The following next steps are suggested for troubleshooting this issue.

1. Check if EPGs are required to communicate with each other using the listed contract(s)
2. If connectivity is required, ensure that the internal EPGs BD subnet are unique across the VRFs
3. If connectivity is not required, determine if you can remove the consumer (not the provider) side of the imported contract relationship

More information about route leaking can be found in the [Troubleshooting Unexpected Route Leaking in ACI](https://www.cisco.com/c/en/us/support/docs/software/aci-data-center/215128-troubleshooting-unexpected-route-leaking.html) TechNote on cisco.com
