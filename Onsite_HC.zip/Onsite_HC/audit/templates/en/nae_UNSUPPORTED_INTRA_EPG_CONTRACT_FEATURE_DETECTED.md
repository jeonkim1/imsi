<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Intra EPG Contract is detected. Unsupported Feature for NAE

APIC policy configuration includes intra-EPG contract that is not supported in this release of CNAE.
Analysis with this unsupported feature may lead to false positive or false negative results.

Table: EPGs with Intra EPG Contract.

{% if data_source == "ndi" %}
| Tenant | Application Profile | EPG |
| ------ | ------------------- |---- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.ap}} | {{table.epg}} |
{% endfor %}
{% else %}
| Tenant | Application Profile | EPG |
| ------ | ------------------- |---- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 7 -%}
            {% set epg_components = object.identifier.split("/") %}
            {% set _=table.__setitem__("tenant", epg_components[1]) %}
            {% set _=table.__setitem__("app_profile", epg_components[2]) %}
            {% set _=table.__setitem__("epg", epg_components[3]) %}
        {%- endif -%}
    {%- endfor -%}
 {{ table.tenant[3:] }} | {{ table.app_profile[3:] }} | {{ table.epg[4:] }} |
{% endfor %}
{% endif %}

No actions are required on ACI. Be aware that this release of NAE/NDI does not support intra EPG contracts.
