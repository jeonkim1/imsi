<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### VRF has Overlapping Subnets

The subnet configured in Bridge Domains or Application EPGs in a given VRF are overlapping with the subnet configured as External Subnets for the External EPG.
Sub-optimal routing may result due to overlapping IP addresses, and next-hop resolution for one or more routes may fail.

Table: Overlapping Subnets.

{% if data_source == "ndi" %}
| Subnet | VRF |
| ------ | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "subnet" -%}
            {%- set _=table.__setitem__("subnet", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {%- set _=table.__setitem__("vrfs", object.objectValue) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.subnet|join(", ")}} | {{table.vrfs|join(", ")}} |
{% endfor %}
{% else %}
| Ext Subnet | Tenant | L3out | External EPG |  VRF | BD/EPG subnet | BD/EPG |
| ---------- | ------ | ----- | ------------ | ---- |---------------| ------ |
{% for item in event_list %}
{% set subnet_list = [] %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 253 -%}
            {% set subnet_components = object.identifier.split("/") %}
            {%- if subnet_components[2][0:3] == "out" -%}
                 {% set _=table.__setitem__("tenant", subnet_components[1]) %}
                 {% set _=table.__setitem__("l3out", subnet_components[2]) %}
                 {% set _=table.__setitem__("extepg", subnet_components[3]) %}
                 {% set _=table.__setitem__("extsubnet", object.name) %}

            {%- elif subnet_components[2][0:2] == "ap" -%}
                 {% set _=table.__setitem__("subnet", object.name) %}
                 {% set _=subnet_list.append({"type": "epg", "app_profile": subnet_components[2], "epg": subnet_components[3]}) %}

            {%- elif subnet_components[2][0:2] == "BD" -%}
                 {% set _=table.__setitem__("subnet", object.name) %}
                 {% set _=subnet_list.append({"type": "bd", "bd": subnet_components[2]}) %}
            {%- endif -%}

        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}
        {%- endif -%}
    {%- endfor -%}
    {% for subnet in subnet_list %}
| {{ table.extsubnet[1:-1] }} | {{ table.tenant[3:] }} | {{ table.l3out[4:] }} | {{ table.extepg[6:] }} | {{table.vrf}} | {{ table.subnet[1:-1] }} | {% if subnet.type == "epg" %} epg: {{ subnet.epg[4:] }} {% else %} bd: {{ subnet.bd[3:] }} {% endif %} |
    {% endfor %}
{% endfor %}
{% endif %}

It is recommended to determine the right location of the subnet. If the correct location is internal to ACI, resolve the conflict by making changes in External Subnets for the External EPG configuration.
If the correct location is external to ACI, remove overlapping subnet from within the ACI configuration of the mentioned Bridge Domain or EPG.

More information about BD subnet configuration can be found in the [Cisco ACI Layer-3 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/L3-configuration/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401_chapter_01001.html) on cisco.com
