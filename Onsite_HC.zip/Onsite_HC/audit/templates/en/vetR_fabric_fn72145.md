<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
affected_count: {{impactedDevices|length}}
-->

### FN72145 - Nexus ACI 9000 Will Fail With SSD Read-Only Filesystem

One of more nodes in the fabric are affected by FN72145. The field notice has been issued due to a flaw in the Solid State Drive (SSD) firmware causing the SSD will no longer respond after approximately 3.2 years of cumulative operation. A system restart allows the drive to operate for another 1008 hours (approximately six weeks) before it will no longer respond again.

The following nodes are affected by the field notice.

Table: Nodes affected by FN72145

| POD | Node | Name |
| --- | ---- | ---- |
{% for entry in impactedDevices %}
| {{entry.pod}} | {{entry.node}} | {{entry.name}} |
{% endfor %}

It is recommended to upgrade the firmware of the SSD proactively before the uptime reaches 28,224 hours. If the system is already impacted, the SSD firmware upgrade will permanently resolve this defect. Please note that it is **strongly** recommended to upgrade the firmware in a Maintenance Window.

If the node(s) cannot be upgraded prior to the uptime reaching 28,224 hours, then a restart of the system can temporarily recover from this problem. However, this failure will reappear after 1008 hours of operation

The SSD firmware can be upgraded one of the two methods below:

1. Upgrade to an ACI version that contains a new SSD firmware with the fix for this issue. The fix are available in ACI version 3.2(10), 4.2(7), 5.1(4), 5.2(1), and later.
2. Use the SSDUpgrader app from the Cisco DC App Center to upgrade the SSD firmware

Detailed information about how to perform the SSD firmware upgrade as well as more information about issue can be found in [Field Notice - 72145](https://www.cisco.com/c/en/us/support/docs/field-notices/721/fn72145.html) available on cisco.com.
