<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### External EPG in Unenforced VRF has a Contract


The External Routed Network EPG has a contract, but the VRF is in unenforced mode.
When the VRF is in unenforced mode, Contracts, subjects, and filters are ignored, and unintended traffic may be passed. Unintended BD subnets may be advertised via the L3 external connection.

Table: EPGs with Contract in Unenforced VRF.

{% if data_source == "ndi" %}

| Tenant | VRF | L3Out | External EPG | Contract |
| ------ | --- | ----- | ------------ | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "contracts" -%}
            {% set _=table.__setitem__("contracts", object.objectValue) %}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3Outs", object.objectValue) %}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epgs", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.l3Outs|join(", ")}} | {{table.epgs|join(", ")}} | {{table.contracts|join(", ")}} |
{% endfor %}
{% else %}

| EPG |  L3out | VRF | Contract | Tenant |
| --- |  ----- | --- | -------- | ------ |
{% for item in event_list %}
{% set table = dict() %}
{% set tenant_list = [] %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}
        {%- elif object.object_types[0].code == 2 -%}
            {% set _=tenant_list.append(object.name) %}
        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}
        {%- elif object.object_types[0].code == 19 -%}
            {% set _=table.__setitem__("contract", object.name) %}
        {%- elif object.object_types[0].code == 28 -%}
            {% set _=table.__setitem__("l3out", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{ table.epg }} | {{ table.l3out }} | {{ table.vrf }} | {{ table.contract }} | {% if tenant_list|length > 1 %} {{tenant_list|join(", ")}} {% else %} {{tenant_list[0]}} {% endif %} |
{% endfor %}
{%- endif -%}

If it is intended to have VRF in unenforced mode, please disassociate the contract from the external EPGs.

More information about L3Out configuration can be found in the [ACI L3 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/l3-configuration/cisco-apic-layer-3-networking-configuration-guide-52x.html) and in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com

More information on Contracts and VRF in unenforced mode can be found in [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) Whitepaper on cisco.com
