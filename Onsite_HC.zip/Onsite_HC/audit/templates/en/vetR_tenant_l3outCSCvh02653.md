<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
affected_count: "{{state.overlappingSubnets|length}}"
-->

### Configuration accepted with IP address mismatch for a given VLAN on the same node

An invalid configugration with IP address mismatch has been accpted for the following L3Outs. These L3Outs are configued with two or more IP addresses for a given VLAN on the same node, which results in the last IP address being programmed to be the active one while the the other IP address no longer being present on the node.

This invalid configuration was accpeted by the APIC due to bug id [CSCvh02653](https://bst.cloudapps.cisco.com/bugsearch/bug/CSCvh02653) which are fixed in ACI 3.2(1l) and later.

Table: Configuration accepted with IP address mismatch

| Tenant | L3Out | POD | Node(s) | VLAN |
| ------ | ----- | --- | ---- | ---- |
{% for item in state.overlappingSubnets %}
{% set table = dict() %}
{%- set node_components = item.node.split("/") -%}
{%- set node_list = node_components[2].split("-") -%}
{%- set _=table.__setitem__("pod", node_components[1][4:]) -%}
{%- set _=table.__setitem__("node", node_list[1:]) -%}
{%- set l3out_components = item.l3out.split("/") -%}
{%- set _=table.__setitem__("tenant", l3out_components[1][3:]) -%}
{%- set _=table.__setitem__("l3out", l3out_components[2][4:]) -%}
{%- set _=table.__setitem__("vlan", item.vlan) -%}
| {{table.tenant}} | {{table.l3out}} | {{table.pod}} | {{table.node|join(", ")}} | {{table.vlan}} |
{% endfor %}

It is recommended to review the configuration of these L3Outs and ensure that the correct IP address are configured on VLANs.

Please reference the [ACI Fabric L3Out Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) for information about how to configure L3Outs.
