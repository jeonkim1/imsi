<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Leaf interface selector has missing policy group


The leaf interface profile interface selector is missing a leaf port policy group (Access, vPC, or PC).
Impact is that any EPG that is bound to this fabric access policy will not be deployed.

Table: Interface profiles with interface selectors missing policy group

{% if data_source == "ndi"%}
| Leaf Interface Profile |
| ---------------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "leafInterfaceProfiles" -%}
            {% set _=table.__setitem__("leafInterfaceProfile", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{ table.leafInterfaceProfile }} |
{%- endfor -%}
{% else %}
Table: Impacted interface selector and Tenant/ANP/EPG using the selector path binding
| Interface Selector | Tenant | App Profile | EPG |
| -------------------| ------ | ----------- | --- |
{% for item in event_list %}
{% set epg_list = [] %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 234 -%}
                {% set _=table.__setitem__("intf_prof", object.name) %}
            {%- elif object_type.code == 7 -%}
                {% set epg_dict = dict() %}
                {% set epg_components = object.identifier.split("/") %}
                {% set _=epg_dict.__setitem__("tenant", epg_components[1][3:]) %}
                {% set _=epg_dict.__setitem__("app_profile", epg_components[2][3:]) %}
                {% set _=epg_dict.__setitem__("epg", epg_components[3][4:]) %}
                {% set _=epg_list.append(epg_dict) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
    {%- for epg in epg_list -%}
        | {{ table.intf_prof }} | {{epg.tenant}} | {{epg.app_profile}} | {{epg.epg}} |
    {% endfor %}
{% endfor %}
{% endif %}

Recommended next steps:

* Determine if the leaf interface profile is needed in Fabric > Access Policies > Interface Policies > Leaf Profiles > (Leaf interface profile name).
* If the leaf interface profile is needed, determine the correct set of interface selector and leaf access port policy group associations that should be bound to this leaf interface profile and make the association.
* If needed, create a new port policy access group (Access, vPC, or PC) with the correct set of interface selectors.
* If it is not needed, determine if you can delete the leaf interface profile.


More information about interface profile configuration can be found in the [Cisco API Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-2-configuration/cisco-apic-layer-2-networking-configuration-guide-52x/access-interfaces-52x.html)
