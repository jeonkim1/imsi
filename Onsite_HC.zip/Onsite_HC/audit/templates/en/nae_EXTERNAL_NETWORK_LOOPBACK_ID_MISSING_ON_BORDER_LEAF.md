<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### External network loopback id is missing on border leaf

An L3Out loopback interface IP address that should be deployed by APIC onto a leaf switch is not present.
Impact is that this interface will not be accessible to Routing protocols and IP addresses attempting reach the loopback address.

Table: Leaf switch(es) with missing loopback

{% if data_source == "ndi" %}
| Tenant | VRF | L3Out | Loopback | Impacted Leaf |
| ------ |---- | ----- | -------- | ------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3out", object.objectValue[0]) %}
        {%- elif object.objectType == "subnet" -%}
                {% set _=table.__setitem__("subnet", object.objectValue[0]) %}
        {%- elif object.objectType == "leafs" -%}
                {% set _=table.__setitem__("leaf", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.l3out}} | {{table.subnet}} | {% if table.leaf|length > 1 %} {{table.leaf|join(", ")}} {% elif table.leaf|length == 1 %} {{table.leaf[0]}} {% else %} n/a {% endif %} |
{% endfor %}
{% else %}

| Tenant | VRF | L3Out | Loopback | Impacted Leaf |
| ------ |---- | ----- | -------- | ------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set leaf_list = []%}
{% set vrf_list = []%}
{% set l3out_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                 {% set _=vrf_list.append(object.name) %}

            {%- elif object_type.code == 253 -%}
                {% set _=table.__setitem__("loopback", object.name) %}

            {%- elif object_type.code == 28 -%}
                 {% set _=l3out_list.append(object.name) %}

            {%- elif object_type.code == 384 -%}
                {% set _=leaf_list.append(object.name) %}

            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}

| {{table.tenant}} | {% if vrf_list|length > 1 %} {{vrf_list|join(", ")}} {% else %} {{vrf_list[0]}} {% endif %}  | {% if l3out_list|length > 1 %} {{l3out_list|join(", ")}} {% else %} {{l3out_list[0]}} {% endif %}  | {{table.loopback}} |  {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}
{%- endif -%}
It is recommended to collect a techsupport from the affected leaf switch and contact Cisco TAC for assistance with root causing the issue.

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com.