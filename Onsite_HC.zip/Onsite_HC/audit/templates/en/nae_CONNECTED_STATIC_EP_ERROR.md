<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Connected Static End Point Error
Static Endpoint mismatch between APIC and Leaf. Endpoint is not present in all location, or its properties do not match on all locations.


Table: Endpoint information not consistent between APIC and leaf
{% if data_source == "ndi" %}

| Leaf(s) | Interface | EP MAC | EP IP | Tenant | EPG |
| ------- | --------- | ------ | ----- | ------ | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "macs" -%}
            {%- set _=table.__setitem__("macs", object.objectValue[0]) -%}
        {%- elif object.objectType == "bds" -%}
                {% set _=table.__setitem__("bds", object.objectValue[0]) %}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epgs", object.objectValue[0]) %}
        {%- elif object.objectType == "tenants" -%}
            {% set _=table.__setitem__("tenants", object.objectValue) %}
        {%- elif object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leafs", object.objectValue) %}
        {%- elif object.objectType == "interfaces" -%}
            {% set _=table.__setitem__("interfaces", object.objectValue[0]) %}
        {%- elif object.objectType == "encaps" -%}
            {% set _=table.__setitem__("encaps", object.objectValue[0]) %}
        {%- elif object.objectType == "ips" -%}
            {% set _=table.__setitem__("ips", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leafs|join(", ")}} | {{table.interfaces}} | {{table.macs}} | {{table.ips}} | {{table.tenants|join(", ")}} | {{table.epgs}} |
{% endfor %}

{%else%}

| Leaf | Interface | EP MAC | EP IP | Tenant | EPG |
| ---- | --------- | ------ | ----- | ------ | --- |
{% for item in event_list %}
{% set table = dict() %}
{% set ep_ip_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 7 -%}
            {% set epg_components = object.identifier.split("/") %}
            {% set _=table.__setitem__("tenant", epg_components[1][3:]) %}
                {%- if epg_components[2][0:2] == "ap" -%}
                    {% set _=table.__setitem__("epg_type", "epg") %}
                    {% set _=table.__setitem__("epg_app_profile", epg_components[2][3:]) %}
                    {% set _=table.__setitem__("epg_name", epg_components[3][4:]) %}
                {%- elif epg_components[2][0:8] == "LDevInst" -%}
                    {% set _=table.__setitem__("epg_type", "shadow") %}
                    {% set _=table.__setitem__("epg_shadow", object.name) %}
                {%- endif -%}
        {%- elif object.object_types[0].code == 304 -%}
            {% set _=table.__setitem__("ep_mac", object.name) %}
        {%- elif object.object_types[0].code == 327 -%}
            {% set _=ep_ip_list.append(object.name) %}
        {%- elif object.object_types[0].code == 1 or object.object_types[0].code == 384 -%}
            {% set _=table.__setitem__("leaf", object.name) %}
        {%- elif object.object_types[0].code == 233 -%}
            {% set _=table.__setitem__("interface", object.name) %}

        {%- endif -%}

    {%- endfor -%}
| {{table.leaf}} | {{table.interface}} | {% if table.ep_mac != "" %}{{ table.ep_mac }}{% else %} - {% endif %} | {% if ep_ip_list|length > 1 %} {{ep_ip_list|join(", ")}} {% elif ep_ip_list|length == 1 %} {{ep_ip_list[0]}} {% else %} - {% endif %} | {{table.tenant}} | {% if table.epg_type == "epg" %} ap: {{table.epg_app_profile}}, epg: {{table.epg_name}} {%elif table.epg_type == "shadow"%}shadow epg: {{table.epg_shadow}} {%endif%} |
{% endfor %}
{%endif%}

Note: If shadow EPGs appear in the table, please verify if UNSUPPORTED_SERVICE_CHAINING_FEATURE_DETECTED event is seen.

Inconsistent endpoint information can be due to several conditions:

* Static EP is deployed on extra leaf than the one in the APIC configuration.
* Static EP is not marked as a static EP on the leaf.
* EPG and MAC are identical between APIC and Leaf, but:
    a) MAC in APIC and Leaf is identical but IP is not
    b) Interface on APIC and Leaf do not match (IP or MAC is matching)
    c) Encap on APIC and Leaf do not match (IP or MAC is matching)
    d)  EPG on APIC and Leaf do not match
* Static EP is expected to be deployed on a leaf as per APIC configuration. It is missing from that leaf.
* Static EP found on leaf is not defined in APIC.
* Static EP defined on APIC is not present on any leaf.

It is recommended to check EPG Configuration for Static IP, MAC, Leaf, Path binding and appropriate domain association. If no obvious reason and can be found, then it is recommended to open a TAC case in order to investigate the issue further.

More information about Endpoint learning can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html) available on cisco.com.
