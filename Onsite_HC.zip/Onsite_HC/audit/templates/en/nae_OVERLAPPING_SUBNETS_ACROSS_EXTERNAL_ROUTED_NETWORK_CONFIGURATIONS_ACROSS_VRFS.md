<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Overlapping Subnets between L3Out Interfaces across VRFs



Communication across VRFs are failling due to overlapping subnets. This subnet overlap is caused by a route learned through a L3Out to overlap with a route learned through a L3Out in another VRF.

Table: Overlapping Subnets between Learned Routes across VRFs

{% if data_source == "ndi" %}
| Subnet | Tenant | VRF |
| ------ |------- | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "subnet" -%}
            {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.subnet|join(", ")}} | {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} |{% endfor %}
{% else %}
| Subnet | Tenant | VRF | L3out(s) | Nodes |
| ------ |------- | --- | -------- | ----- |
{% for item in event_list %}
{% set table = dict() %}
{% set l3out_list = []%}
{% set leaf_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}
            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}
            {%- elif object_type.code == 28 -%}
                {% set _=l3out_list.append(object.name) %}
            {%- elif object_type.code == 253 -%}
                {% set _=table.__setitem__("subnet", object.name) %}
            {%- elif object_type.code == 384 -%}
                {% set _=leaf_list.append(object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}

| {{table.subnet}} | {{table.tenant}} | {{table.vrf}} | {{l3out_list|join(", ")}} | {{leaf_list|join(", ")}} |
{% endfor %}
{% endif %}

The following next steps are suggested in order to resolve this issue.

1. Check if the two L3Out EPGs are required to communicate with each other
2. Ensure that IP addresses across all loopbacks, routed interfaces, routed sub-interfaces and/or SVIs within one or more L3Outs, attached to the relevant VRFs are unique
3. If connectivity is not required, determine if you can remove the consumer (not the provider) side of the imported contract relationship

More information about L3Out Configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
