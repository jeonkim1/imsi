<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### L2Out External EPG not Associated with Contract in Enforced VRF

The following L2Out External EPGs are not associated with a contract in an enforced VRF. Without a contract there is no communication to the external bridged network.

Table: External EPG not Associated with Contract in Enforced VRF

{% if data_source == "ndi" %}

| Tenant | L2Out | VRF | BD | EPG |
| ------ | ----- | --- | -- | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "l2Outs" -%}
                {% set _=table.__setitem__("l2out", object.objectValue[0]) %}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- elif object.objectType == "bds" -%}
                {% set _=table.__setitem__("bd", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
                {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.l2out}} | {{table.vrf}} | {{table.bd}} | {{table.epg}} |
{% endfor %}
{% else %}

| Tenant | L2Out | External EPG |
| ------ | ----- | ------------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}


            {%- elif object_type.code == 7 -%}
                {% set _=table.__setitem__("epg", object.name) %}

            {%- elif object_type.code == 27 -%}
                {% set _=table.__setitem__("l2out", object.name) %}

            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}

| {{table.tenant}} | {{table.l2out}} | {{table.epg}} |
{% endfor %}

{%- endif -%}
It is recommended to use the following steps to investigate the issue:

1. Determine if the L2Out is required and its purpose. If the L2Out is not required, determine if the L2Out can be deleted
2. If the L2Out is required, determine its purpose and create a new, or associate an existing contract as needed, to meet the requirements

More information about L2Out configuration can be found in the [L2Out Configuration using the Routed Bridged Network Method](https://www.cisco.com/c/en/us/support/docs/cloud-systems-management/application-policy-infrastructure-controller-apic/200964-Configure-Access-Polices-Static-Binding.html#anc12) on cisco.com.
