<!--
category:
  - Healthcheck
severity: warning
affected_count: "{{event_list|length}}"
-->

#### Device Selection Policy has no Device

The following selection policies have no devices defined.

Table: Selection Policies with no Device

| Tenant | Selection Policy |
| ------ | ---------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 487 -%}
            {% set _=table.__setitem__("selection_policy", object.name) %}
        {%- endif -%}            
    {%- endfor -%}
| {{table.tenant}} | {{table.selection_policy}} |
{% endfor %}

It is recommended to assess why the selection policy does not have any devices defined.
If the selection policy is not needed, it is recommended to un-provision it.

More information about service graphs configuration can be found in the [Cisco APIC Layer 4 to Layer 7 Services Deployment Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-4-to-layer-7-services-configuration/cisco-apic-layer-4-to-layer-7-services-deployment-guide-52x.html)
