<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### A contract is associated to a service graph but no corresponding service graph instance is found

A contract is associated to a service graph template but no corresponding service graph instance was found.

Table: Contracts with associated service graph, with missing service graph instance.

{% if data_source == "ndi" %}
| Tenant | Contract with associated SG |
| ------ | ----------------------------|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "contracts" -%}
            {%- set _=table.__setitem__("contracts", object.objectValue[0]) -%}

        {%- endif -%}
    {%- endfor -%}
| | {{table.contracts}} |
{% endfor %}
{% else %}
| Tenant | Contract with associated SG |
| ------ | ----------------------------|
{% for item in event_list %}
{% set table = dict() %}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 19 -%}
            {% set _=table.__setitem__("contract", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.contract}} |
{% endfor %}
{% endif %}

It is recommended to assess why the service graph instance is missing.
With a missing instance, the service graph is not deployed. Traffic will not be redirected to the service node.

More information about service graphs configuration can be found in the [Cisco APIC Layer 4 to Layer 7 Services Deployment Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-4-to-layer-7-services-configuration/cisco-apic-layer-4-to-layer-7-services-deployment-guide-52x.html)