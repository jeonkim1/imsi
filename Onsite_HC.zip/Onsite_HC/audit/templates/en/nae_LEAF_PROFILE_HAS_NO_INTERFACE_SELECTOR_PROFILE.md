<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Leaf Interface Profile not configured with Interface Selector

The following leaf interface profile(s) are not configured with an interface selector which means that the fabric access policy will not be deployed onto leaf switches.

These interface profile(s) are in use by one or more EPGs, which as a result of the missing interface selector, may mean that not all expected endpoints are connected to these EPGs.

Table: Leaf Profile not configured with Interface Selector

| Interface Profile |
| ---------------------- |
{% if data_source == "ndi" %}
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "leafProfiles" -%}
            {%- set _=table.__setitem__("leafProfile", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.leafProfile}} |
{% endfor %}
{% else %}
{% for interface in event_list %}
| {{interface.0.name}} |
{% endfor %}
{%- endif -%}

It is recommended to configure these interface profile with one or more interface selector(s).

More information about interface profile configuration can be found in the [Cisco API Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)
