<!--
category:
  - Best_Practice
severity: notice
affected_count: 1
-->

### Digital Optical Monitoring (DOM)

Digital Optical Monitoring (DOM) is an industry standard that provides additional monitoring for optical connections beyond simple up/down. It monitors optic-specific state, e.g. send and receive power, which can protect against situations like impending failure and degraded connectivity.

It is recommended to enable Digital Optical Monitoring in the fabric.

More information about Digital Optical Monitoring can be found in the [ACI Troubleshooting Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/troubleshooting/Cisco-APIC-Troubleshooting-Guide-401/b_APIC_Troubleshooting_4x_chapter_0110.html#id_37684) available on cisco.com.
