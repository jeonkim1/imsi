<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Interface Policy Group not configured with AAEP

The following interface policy group(s) (access, port-channel, vPC) are not configured with an AAEP which means that the fabric access policy will not be deployed onto leaf switches.

Table: Interface Policy Group not configured with AAEP

{% if data_source == "ndi" %}
| Interface Policy Group |
| ---------------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "interfacePolicyGroups" -%}
            {% set _=table.__setitem__("interface", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.interface}} |
{% endfor %}
{% else %}
| Interface Policy Group |
| ---------------------- |
{% for interface in event_list %}
| {{interface.0.name}} |
{% endfor %}
{% endif %}

It is recommended to configure these interface policy groups with an AAEP.

More information about interface configuration can be found in the [Cisco API Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)
