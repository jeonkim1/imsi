<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Contract has no Subject

The following contract(s) are configured without a subject, which is an invalid configuration.

Table: Contract has no Subject

{% if data_source == "ndi" %}

| Tenant | Contract |
| ------ | -------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "contracts" -%}
                {% set _=table.__setitem__("contract", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.contract}} |
{% endfor %}
{% else %}

| Tenant | Contract |
| ------ | -------- |
{% for contract in event_list %}
| {{contract.1.name}} | {{contract.0.name}} |
{% endfor %}

{%- endif -%}

If these contract(s) are supposed to be in use, then it is recommended to configure them with one or more subjects.

More information about Contract configuration can be found in the [Cisco API Security Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/security/Cisco-APIC-Security-Configuration-Guide-401/b_Cisco_APIC_Security_Guide_chapter_01010.html)
