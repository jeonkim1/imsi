<!--
category:
  - Best_Practice
severity: notice
affected_count: 1
-->

### Domain Validation

It is recommended as a best practice to have Domain Validation enabled before static paths are added to an EPG in order to ensure the domain exists prior to adding the EPG static path.

More information about domain validation can be found in the [ACI Design Guide](https://www.cisco.com/c/en/us/td/docs/dcn/whitepapers/cisco-application-centric-infrastructure-design-guide.html#DomainandEPGVLANvalidations) available on cisco.com.
