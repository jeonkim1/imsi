<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Partial Configured Leaf vPC Interface are Operationally Up and Admin Up


The following leaf vPC interfaces have been partial configured for consumption by the Fabric Access Policy and they are Operationally Up and Admin Up.
Best practice is to keep an partially configured Virtual Port Channel administratively disabled.

Table: Partial Configured Leaf vPC Interface with all member links having Link Down

{% if data_source == "ndi" %}
| Interface Policy Group | Leaf |
| ---------------------- | -----|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "interfacePolicyGroups" -%}
            {%- set _=table.__setitem__("interfacePolicyGroup", object.objectValue[0]) -%}
        {%- elif object.objectType == "leafs" -%}
                {% set _=table.__setitem__("leaf", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.interfacePolicyGroup}} | {{table.leaf}} |
{% endfor %}
{% else %}
| Interface Policy Group | Leaf 1 | Leaf2 | Leaf Interface | Tenant | AP | EPG |
| ---------------------- | -------| ----- | -------------- | ------ | -- | --- |
{% for item in event_list %}
{% set table = dict() %}
{% set node_list = []%}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 384 -%}
            {% set _=node_list.append(object.name) %}
        {%- elif object.object_types[0].code == 244 -%}
            {% set _=table.__setitem__("pc_ipg", object.name) %}
        {%- elif object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 8 -%}
            {% set _=table.__setitem__("ap", object.name) %}
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}
        {%- elif object.object_types[0].code == 233 -%}
            {% set interface_components = object.identifier.split("/") %}
            {% set interface_node = " (" ~ interface_components[2] ~ ")" %}
            {% set _=interface_list.append(object.name ~ interface_node) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.pc_ipg}} | {{node_list[0]}} | {{node_list[1]}} |{% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %} | {{table.tenant}} | {{table.ap}} | {{table.epg}} |
{% endfor %}
{% endif %}

Determine if the interface needs to be admin up, operationally up.
If not, as a generic best practice, admin shut interfaces that are unused.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)
