<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Connected EP duplicated IP

IP addresses are in use by Multiple MAC addresses within the same VRF.
Multiple MACs sharing a single IP address will cause intermittent connectivity issues.

Table: Endpoint IP corresponding to multiple MAC endpoint

{% if data_source == "ndi" %}
| EP IP | EP MAC | Leaf Switch | Leaf interface | Tenant | VRF | BD | EPG |
| ----- | ------ | ----------- | -------------- | ------ | --- | -- | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "macs" -%}
            {%- set _=table.__setitem__("macs", object.objectValue) -%}
        {%- elif object.objectType == "ips" -%}
            {%- set _=table.__setitem__("ips", object.objectValue) -%}
        {%- elif object.objectType == "bds" -%}
            {%- set _=table.__setitem__("bds", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {%- set _=table.__setitem__("vrfs", object.objectValue) -%}
        {%- elif object.objectType == "epgs" -%}
            {%- set _=table.__setitem__("epgs", object.objectValue) -%}
        {%- elif object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "leafs" -%}
            {%- set _=table.__setitem__("leafs", object.objectValue) -%}
        {%- elif object.objectType == "interfaces" -%}
            {%- set _=table.__setitem__("interfaces", object.objectValue) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.macs|join(", ")}} | {{table.ips|join(", ")}} | {{table.leafs|join(", ")}} | {{table.interfaces|join(", ")}} | {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.bds|join(", ")}} | {{table.epgs|join(", ")}} |
{% endfor %}
{% else %}
| EP IP | EP MAC | Leaf Switch/interface  | Tenant | VRF | App_profile | EPG |
| ------|------- | ---------------------- | ------ | --- | ----------- | --- |
{% set allEPip_componenents_list = [] %}
{% set uniqueIP_list = [] %}
{% for item in event_list %}
    {% set leaf_dict = dict()%}
    {% set leaf_list = [] %}
    {% set macs_EPip_list = [] %}
    {% set table =dict() %}
    {% for object in item %}
        {% if object.object_types[0].code == 233 %}
            {% set node_components = object.identifier.split("/") %}
            {% set _=leaf_dict.__setitem__("node", node_components[2]) %}
            {% set _=leaf_dict.__setitem__("interface", object.name) %}
            {% set _=leaf_list.append(leaf_dict) %}
        {% elif object.object_types[0].code == 304 %}
            {% set _=table.__setitem__("mac", object.name) %}
        {% elif object.object_types[0].code == 327 %}
            {% set my_ip = object.name %}
            {% set _=macs_EPip_list.append(my_ip) %}
            {% if my_ip not in uniqueIP_list %}
                {% set _=uniqueIP_list.append(my_ip) %}
            {% endif %}
        {% elif object.object_types[0].code == 2 %}
            {% set _=table.__setitem__("tenant", object.name) %}
        {% elif object.object_types[0].code == 4 %}
            {% set _=table.__setitem__("vrf", object.name) %}
        {% elif object.object_types[0].code == 3 %}
            {% set _=table.__setitem__("bd", object.name) %}
        {% elif object.object_types[0].code == 8 %}
            {% set _=table.__setitem__("app_profile", object.name) %}
        {% elif object.object_types[0].code == 7 %}
            {% set _=table.__setitem__("epg", object.name) %}
        {% endif %}
    {% endfor %}
    {% set _=table.__setitem__("node", leaf_list) %}
    {% set _=table.__setitem__("EPip", macs_EPip_list) %}
    {% set _=allEPip_componenents_list.append(table) %}
{% endfor %}
{% for uniqueIP in uniqueIP_list %}
    {% for EP_component in allEPip_componenents_list %}
        {% if uniqueIP in EP_component.EPip %}
        |{{ uniqueIP }}| {{ EP_component.mac }} | {% for node in EP_component.node %} {{node.node}}/{{node.interface}} {% endfor %}| {{EP_component.tenant}} | {{EP_component.vrf}} | {{EP_component.app_profile}} | {{EP_component.epg}} |
        {% endif %}
    {% endfor %}
{% endfor %}
{% endif %}


It is recommended to use the following steps to clear this condition:

1. Login into the APIC UI and verify the presence of the endpoints in the operational tab of the EPGs. Tenant→Tenant Name→App Profiles→App Profile Name→App EPGs→EPG Name→Operational
2. Identify the EPs that actually own the IPs and change the IP address on the host/device that has the incorrect IP address.
3. Clear the endpoint on the leaf by opening an SSH session to each leaf and by entering the following command: leaf# clear system internal epm endpoint command

More information about Endpoint learning can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html) available on cisco.com.
