<!--
category:
  - Best_Practice
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Leaf port-channel interface not used by an EPG

The following leaf port-channel interfaces are active and has been configured for consumption by the Fabric Access Policy, but are not yet consumed by an EPG.

Table: Leaf PC interface not used by an EPG

{% if data_source == "ndi" %}
| Interface Policy Group | Leaf |
| ---------------------- | -----|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "interfacePolicyGroups" -%}
            {%- set _=table.__setitem__("interfacePolicyGroup", object.objectValue[0]) -%}
        {%- elif object.objectType == "leafs" -%}
                {% set _=table.__setitem__("leaf", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.interfacePolicyGroup}} | {{table.leaf}} |
{% endfor %}
{% else %}
| Leaf | Associated Interface Policy Group | Associated Interface Profile | Associated AAEP | Interface(s) |
| ---- | --------------------------------- | ---------------------------- | --------------- | ------------ |
{% for item in event_list %}
{% set table = dict() %}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 233 -%}
                {% set _=interface_list.append(object.name) %}
            {%- elif object_type.code == 234 -%}
                {% set _=table.__setitem__("interface_profile", object.name) %}
            {%- elif object_type.code == 237 -%}
                {% set _=table.__setitem__("aaep", object.name) %}
            {%- elif object_type.code == 244 -%}
                {% set _=table.__setitem__("interface_policy_group", object.name) %}
            {%- elif object_type.code == 384 -%}
                {% set _=table.__setitem__("leaf", object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{table.leaf}} | {{table.interface_policy_group}} | {{table.interface_profile}} | {{table.aaep}} |{% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %}|
{% endfor %}
{% endif %}

If the EPGs have been deployed directly under the AAEP, this event may be a false positive. Please verify if this is the case.
If not and if these interfaces are supposed to be in use, then it is recommended to review the configuration of the EPG(s) that should be in-use on these interfaces.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)

More information about EPG configuration and design can be found in the [Endpoint Group (EPG) Usage and Design Whitepaper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-731630.html)
