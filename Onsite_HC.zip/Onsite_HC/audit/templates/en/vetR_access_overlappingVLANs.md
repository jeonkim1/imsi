<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
{% set count = namespace(value = 0) %}
{% set count.value = count.value + overlappingVLANs|length %}
{% set count.value = count.value + overlappingVLANPathBindings|length %}
affected_count: "{{count.value}}"
-->

### Overlapping VLANs at Domain and/or EPG Level

Cisco ACI offers a lot of flexibility with regards to how VLAN IDs on the front facing ports can be used, it is however recommended that domains and VLANs should have a one-to-one mapping. This is recommended to avoid a misconfiguration where multiple domains with overlapping VLANs are associated to the same EPG. If different domains with the same VLAN are attached to the same EPG, BD-wide BPDU flooding will be nondeterministic, which can result in bridging loops, high CPU, and intermittent traffic.

{% if state.hasOverlappingVLANs == True %}
The following VLAN pools where found to have overlapping ranges.

Table: Overlapping VLAN Pools

| Domain 1 | Domain 2 | VLAN Pool 1 | VLAN Pool 2 | VLAN IDs |
| -------- | -------- | ----------- | ----------- | -------- |
{% for item in overlappingVLANs %}
{% set vlan_blocks = [] %}
{% set table = dict() %}
    {% set domA_components = item.domA.split('/') %}
    {% set domA_name_components = domA_components[1].split('-') %}
    {% set domA_name = domA_name_components[1:]|join('-') ~ ' (' ~ domA_name_components[0] ~ ' domain)' %}
    {% set _=table.__setitem__("domA", domA_name) %}
    {% set domB_components = item.domB.split('/') %}
    {% set domB_name_components = domB_components[1].split('-') %}
    {% set domB_name = domB_name_components[1:]|join('-') ~ ' (' ~ domB_name_components[0] ~ ' domain)' %}
    {% set _=table.__setitem__("domB", domB_name) %}
    {% set poolA_components = item.poolA.split('/') %}
    {% set poolA_name_components = poolA_components[2][8:] %}
    {% set poolA_name_components = poolA_name_components.split(']-') %}
    {% set poolA_name = poolA_name_components[0] ~ ' (' ~ poolA_name_components[1] ~ ' pool)' %}
    {% set _=table.__setitem__("poolA", poolA_name) %}
    {% set poolB_components = item.poolB.split('/') %}
    {% set poolB_name_components = poolB_components[2][8:] %}
    {% set poolB_name_components = poolB_name_components.split(']-') %}
    {% set poolB_name = poolB_name_components[0] ~ ' (' ~ poolB_name_components[1] ~ ' pool)' %}
    {% set _=table.__setitem__("poolB", poolB_name) %}
    {%- for block in item.blocks -%}
        {%- if block.from == block.to %}
            {%- set _= vlan_blocks.append('' ~ block.from) -%}
        {%- else -%}
            {%- set _= vlan_blocks.append(block.from ~ '-' ~ block.to) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.domA}} | {{table.domB}} | {{table.poolA}} | {{table.poolB}} | {{vlan_blocks|sort|join(', ')}} |
{% endfor %}

It is recommended to review the VLAN pools listed above and eliminate the VLAN overlap between them.

{% endif %}
{% if state.hasOverlappingVLANPathBindings == True %}
The following EPGs where found to have been configured with an overlapping VLAN.

Table: EPGs with Overlapping VLANs

| Tenant | Application Profile | EPG | Domain 1 | Domain 2 | VLAN Pool 1 | VLAN Pool 2 | VLAN ID |
| ------ | ------------------- | --- | -------- | -------- | ----------- | ----------- | ------- |
{% for item in overlappingVLANPathBindings %}
{% set table = dict() %}
    {% set epg_components = item.epg.split('/') %}
    {% set _=table.__setitem__("tenant", epg_components[1][3:]) %}
    {% set _=table.__setitem__("app_profile", epg_components[2][3:]) %}
    {% set _=table.__setitem__("epg", epg_components[3][4:]) %}
    {% set domA_components = item.domA.split('/') %}
    {% set domA_name_components = domA_components[1].split('-') %}
    {% set domA_name = domA_name_components[1:]|join('-') %}
    {% set _=table.__setitem__("domA", domA_name) %}
    {% set domB_components = item.domB.split('/') %}
    {% set domB_name_components = domB_components[1].split('-') %}
    {% set domB_name = domB_name_components[1:]|join('-') %}
    {% set _=table.__setitem__("domB", domB_name) %}
    {% set poolA_components = item.poolA.split('/') %}
    {% set poolA_name_components = poolA_components[2][8:] %}
    {% set poolA_name_components = poolA_name_components.split(']-') %}
    {% set poolA_name = poolA_name_components[0] %}
    {% set _=table.__setitem__("poolA", poolA_name) %}
    {% set poolB_components = item.poolB.split('/') %}
    {% set poolB_name_components = poolB_components[2][8:] %}
    {% set poolB_name_components = poolB_name_components.split(']-') %}
    {% set poolB_name = poolB_name_components[0] %}
    {% set _=table.__setitem__("poolB", poolB_name) %}
    {% set _=table.__setitem__("vlan", item.vlan) %}
| {{table.tenant}} | {{table.app_profile}} | {{table.epg}} | {{table.domA}} | {{table.domB}} | {{table.poolA}} | {{table.poolB}} | {{table.vlan}}
{% endfor %}

It is highly recommended to review the configuration of the EPGs listed above and remove the overlapping VLAN configuration as this is an invalid configuration that may lead to operational issues.
{% endif %}

More information about VLAN Pools and Domains can be found in [Cisco ACI Layer-2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/L2-configuration/Cisco-APIC-Layer-2-Configuration-Guide-411/Cisco-APIC-Layer-2-Configuration-Guide-411_chapter_0101.html) on cisco.com.
