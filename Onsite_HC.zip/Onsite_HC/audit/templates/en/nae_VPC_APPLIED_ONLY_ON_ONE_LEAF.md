<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
affected_count: "{{event_list|length}}"
-->

#### vPC applied only on one Leaf

The following vPC interface(s) are only applied to one leaf and not two as expected.

Table: vPC applied only on one Leaf

| Interface Policy Group |
| ---------------------- |
{% for interface in event_list %}
| {{interface.0.name}} |
{% endfor %}

It is recommended to apply these vPC interface(s) to both leafs in a vPC pair.

More information about vPC interface configuration can be found in the [Cisco API Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_010.html)
