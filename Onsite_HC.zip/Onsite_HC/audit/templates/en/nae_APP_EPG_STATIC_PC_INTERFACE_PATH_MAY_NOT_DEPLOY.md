<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Application EPG static port-channel interface path may not deploy

The following EPGs have static paths that may fail deployment due to an error in fabric access policy or EPG port path binding.
Information listed in the table below is depending on the failing condition. It is expected to see some empty cells.

Table: EPG Static Port-channel Interface Path may not deploy

{% if data_source == "ndi" %}
| Tenant | Application Profile | EPG Name | Encap VLAN | Switch Profile | Physical Domain | Interface Policy Group | AAEP |
| ------ | ------------------- | -------- | ---------- |--------------  | --------------- | ---------------------- |----- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- elif object.objectType == "encaps" -%}
            {% set _=table.__setitem__("encap", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.ap}} | {{table.epg}} | {{table.encap}} | | | | |
{% endfor %}
{% else %}
| Tenant | Application Profile | EPG Name | Encap VLAN | Switch Profile | Physical Domain | Interface Policy Group | AAEP |
| ------ | ------------------- | -------- | ---------- |--------------  | --------------- | ---------------------- |----- |
{% for item in event_list %}
{% set table = dict() %}
{% set phydom_list = [] %}
{% set swprof_list = [] %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 3001 -%}
            {% set _=table.__setitem__("vlan", object.identifier) %}
        {%- elif object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 8 -%}
            {% set _=table.__setitem__("app_profile", object.name) %}
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}
        {%- elif object.object_types[0].code == 237 -%}
            {% set _=table.__setitem__("aaep", object.name) %}
        {%- elif object.object_types[0].code == 35 -%}
            {% set _=phydom_list.append(object.name) %}
        {%- elif object.object_types[0].code == 243 -%}
            {% set _=swprof_list.append(object.name) %}
        {%- elif object.object_types[0].code == 244 -%}
            {% set _=table.__setitem__("ipg", object.name) %}
        {%- endif -%}

    {%- endfor -%}
| {{table.tenant}} | {{table.app_profile}} | {{table.epg}} | {{table.vlan}} | {% if swprof_list|length > 1 %} {{swprof_list|join(", ")}} {% else %} {{swprof_list[0]}} {% endif %} |{% if phydom_list|length > 1 %} {{phydom_list|join(", ")}} {% else %} {{phydom_list[0]}} {% endif %} |  {{table.ipg}} | {{table.aaep}} |
{% endfor %}
{% endif %}

This event can be due to several conditions:

* None of the Switch Profiles that contain the Path Binding Leaf have an Interface Profile.
* The EPG Path Binding Node is not present in any Switch Profile.
* The AAEPs in the Interface Policy Group associated with the Interface Selector Profile that contains the interface in the EPG path binding, is not present in any of the PhysDoms of the EPG.
* None of the EPG PhysDoms have an AAEP.
* The Static Path Binding Node and Interface lead to AAEPs that are present in one or more EPG PhysDom, but none of those PhysDoms have a VLAN pool that contains the Static Port Binding Encap VLAN.
* None of the Switch Profiles of the EPG’s Static Path Binding Leaf have the Leaf Interface Profiles of the EPG’s Static Binding Interface:
    a) The Leaf in the EPG Static Path Binding is present in one of the Switch Profiles.
    b) The Interface in the EPG Static Path Binding is present in one of the Interface Profiles.
    c) The Switch Profiles from a) are not carrying the Leaf Interface Profiles from b).
* Interface in EPG path binding is not in any Fabric Interface Selector.
* None of the Interface Policy Groups associated with Interface Selectors that contain the EPG path binding interface have any AAEPs.
* EPG has no PhysDom configured.

It is recommended to verify the configuration of the fabric access policies and EPG port path bindings used by these EPGs.

More information about EPG configuration and design can be found in the [Endpoint Group (EPG) Usage and Design Whitepaper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-731630.html) on cisco.com.
