<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Overlapping Subnets between External Interfaces and External Learned Routes in same VRF

The following L3Outs have subnet(s) overlapping between routes learnt from eternal neighbor and subnet(s) configured on external interfaces or loopbacks in the same VRF. This may lead to sub-optimal routing due to the overlapping IP addresses, and next-hop resolution for one or more routes may fail.

Table: L3Outs Configured Subnets that Overlap with External Learnt Routes

{% if data_source == "ndi" %}
| Tenant | VRF | L3Out | Subnet / Route | Nodes |
| ------ |---- | ----- | -------------- | ----- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "subnet" -%}
            {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3Outs", object.objectValue) %}
        {%- elif object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leafs", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.tenants|vrfs(", ")}} | {{table.l3Outs|join(", ")}} | {{table.subnet|join(", ")}} | {{table.leafs|join(", ")}} |
{% endfor %}
{% else %}
| Tenant | VRF | L3Out | Subnet | Route | Nodes |
| ------ |---- | ----- | ------ | ----- | ----- |
{% for item in event_list %}
{% set table = dict() %}
{% set l3out_list = []%}
{% set leaf_list = []%}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object_type.code == 253 -%}
                {% set _=table.__setitem__("subnet", object.name) %}

            {%- elif object_type.code == 254 -%}
                {% set _=table.__setitem__("route", object.name) %}

            {%- elif object_type.code == 28 -%}
                {% set _=l3out_list.append(object.name) %}

            {%- elif object_type.code == 384 -%}
                {% set _=leaf_list.append(object.name) %}

            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}

| {{table.tenant}} | {{table.vrf}} | {% if l3out_list|length > 1 %} {{l3out_list|join(", ")}} {% else %} {{l3out_list[0]}} {% endif %} | {{table.subnet}} | {{table.route}} |  {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

The following next steps are suggested for troubleshooting this issue.

1. Ensure that routes, and subnets across all loopbacks, routed interfaces, routed sub-interfaces and/or SVIs within one or more L3Outs attached to the same VRF are unique
2. Determine which one of the L3Out Interfaces should have the subnet and modify the respective l3Out + Node Profile + Interface Profile combinations to eliminate the overlap
3. For the external routes that are overlapping, determine which entry should own the subnet and correct as needed

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
