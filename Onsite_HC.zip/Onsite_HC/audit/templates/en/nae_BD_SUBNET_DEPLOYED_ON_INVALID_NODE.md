<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Bridge Domain Subnet is Deployed on Invalid Node



BD subnet or an EPG subnet is deployed on a Node that does not exist.

Table: Subnets Deployed on Invalid Node(s)

{% if data_source == "ndi" %}
| Subnet | Tenant | VRF |
| ------ | ------ | ----|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- elif object.objectType == "subnet" -%}
                {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bd", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {% if table.subnet|length > 1 %} {{table.subnet|join(", ")}} {% else %} {{table.subnet[0]}} {% endif %} | {{table.tenant}} | {{table.vrf}} |
{% endfor %}
{% else %}
| Subnet | Tenant | VRF | BD | APP Profile | EPG | List of Nodes |
| ------ | ------ | ----|--- |------------ | --- | ------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set node_list = [] %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 253 -%}
            {% set _=table.__setitem__("subnet", object.name) %}
         {%- elif object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}
        {%- elif object.object_types[0].code == 3 -%}
            {% set _=table.__setitem__("bd", object.name) %}
        {%- elif object.object_types[0].code == 8 -%}
            {% set _=table.__setitem__("app_profile", object.name) %}
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}
        {%- elif object.object_types[0].code == 384 or object.object_types[0].code == 1 -%}
            {% set _=node_list.append(object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{ table.subnet}} | {{table.tenant}} | {{table.vrf}} | {{table.bd}} | {{table.app_profile}} | {{table.epg}} |{% if node_list|length > 1 %} {{node_list|join(", ")}} {% else %} {{node_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

Suggested next steps:

* Determine if the node ID(s) in question are still valid.
* If not valid, change the node ID(s) to the right ones or delete the static path bindings from the EPG
* If valid, attempt to login to the console for this node to determine what the issue might be and attempt to recover connectivity from the node to the APICs.

More information about statically deploying an EPG on a specific Port can be found in the [Cisco APIC Basic Configuration Guide - Basic User Tenant Configuration](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/basic-configuration/cisco-apic-basic-configuration-guide-52x/m_tenants.html)
