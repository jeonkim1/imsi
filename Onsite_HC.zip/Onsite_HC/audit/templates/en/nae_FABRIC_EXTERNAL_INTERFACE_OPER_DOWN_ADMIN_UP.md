<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Fabric External Interface on Spine Down

The following external facing fabric interfaces on spine switches are down, which means that spine connectivity is either degraded or completely lost.

Table: Fabric External Interface on Spine Down

{% if data_source == "ndi" %}
| Spine | Interface |
| ----- | --------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "leafs" -%}
            {%- set _=table.__setitem__("spine", object.objectValue[0]) -%}
        {%- elif object.objectType == "interfaces" -%}
            {% set _=table.__setitem__("interface", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.spine}} | {{table.interface}} |
{% endfor %}
{% else %}
| Spine | Interface |
| ----- | --------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 233 -%}
            {% set _=table.__setitem__("interface", object.name) %}

        {%- elif object.object_types[0].code == 1 or object.object_types[0].code == 385 -%}
            {% set _=table.__setitem__("spine", object.name) %}

        {%- endif -%}

    {%- endfor -%}
| {{table.spine}} | {{table.interface}} |
{% endfor %}
{% endif %}

If these interfaces are supposed to be in use, then it is recommended to investigate why the links are down.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)
