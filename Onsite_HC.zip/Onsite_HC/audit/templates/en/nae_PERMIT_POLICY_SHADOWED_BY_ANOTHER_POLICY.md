<!--
category:
  - Optimization
severity: warning
affected_count: "{{event_list|length}}"
-->

#### Permit Policy is Shadowed by Another Policy


Some application ports on EPGs may not be able to communicate due to the permit rule getting over-ridden.
Communication loss will occur for traffic that match permit policies that have been overridden by a deny policy.
The failure condition is that there are one or more Deny and one or more Permit policies shadowing a Permit policy.

The following EPGs are impacted by this event. EPGs can be Application EPGs, External EPGs or all EPGs in a VRF (vzAny).

Table: EPGs With Permit Policy Shadowed by Another Policy

| Provider EPG(s) | Consumer EPG(s) | Contract(s) | Subject | Filter |
| --------------- |---------------- | ----------- | ------- | ------ |
{% for item in event_list %}
{% set table = dict() %}

{% set consumer_epg_list = [] %}
{% set provider_epg_list = [] %}
{% set contract_list = [] %}
{% set subj_list = [] %}
{% set filter_list = [] %}
    {%- for object in item -%}
    {% set consumer = dict() %}
    {% set provider = dict() %}
        {%- for codes in object.object_types -%}
            {%- if codes.code == 16 -%}
                {% set consumer_components = object.identifier.split("/") %}
                {% set _=consumer.__setitem__("cons_tenant", consumer_components[1][3:]) %}
                {%- if consumer_components[2][0:3] == "out" -%}
                    {% set _=consumer.__setitem__("cons_type", "extepg") %}
                    {% set _=consumer.__setitem__("cons_l3out", consumer_components[2][4:]) %}
                    {% set _=consumer.__setitem__("cons_extepg", consumer_components[3][6:]) %}
                {%- elif consumer_components[2][0:2] == "ap" -%}
                    {% set _=consumer.__setitem__("cons_type", "epg") %}
                    {% set _=consumer.__setitem__("cons_app_profile", consumer_components[2][3:]) %}
                    {% set _=consumer.__setitem__("cons_epg", consumer_components[3][4:]) %}
                {%- elif consumer_components[2][0:3] == "ctx" -%}
                    {% set _=consumer.__setitem__("cons_type", "ctx") %}
                    {% set _=consumer.__setitem__("cons_vrf", consumer_components[2][4:]) %}
                {%- endif -%}
                {% set _=consumer_epg_list.append(consumer) %}
            {%- elif codes.code == 11 -%}
                {% set provider_components = object.identifier.split("/") %}
                {% set _=provider.__setitem__("prov_tenant", provider_components[1][3:]) %}
                {%- if provider_components[2][0:3] == "out" -%}
                    {% set _=provider.__setitem__("prov_type", "extepg") %}
                    {% set _=provider.__setitem__("prov_l3out", provider_components[2][4:]) %}
                    {% set _=provider.__setitem__("prov_extepg", provider_components[3][6:]) %}
                {%- elif provider_components[2][0:2] == "ap" -%}
                    {% set _=provider.__setitem__("prov_type", "epg") %}
                    {% set _=provider.__setitem__("prov_app_profile", provider_components[2][3:]) %}
                    {% set _=provider.__setitem__("prov_epg", provider_components[3][4:]) %}
                {%- elif provider_components[2][0:3] == "ctx" -%}
                    {% set _=provider.__setitem__("prov_type", "ctx") %}
                    {% set _=provider.__setitem__("prov_vrf", provider_components[2][4:]) %}
                {%- endif -%}
                {% set _=provider_epg_list.append(provider) %}
            {%- elif codes.code == 21 -%}
                {% set _=filter_list.append(object.name) %}

            {%- elif codes.code == 19 -%}
                {% set _=contract_list.append(object.name) %}

            {%- elif codes.code == 20 -%}
                {% set _=subj_list.append(object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}    
        |{% if provider_epg_list|length > 0 %}{% for entry in provider_epg_list %} **tenant:**{{ entry.prov_tenant }}{% if entry.prov_type == "epg" %}, ap:{{ entry.prov_app_profile }}, epg:{{ entry.prov_epg}}{% elif entry.prov_type == "extepg" %}, l3out:{{ entry.prov_l3out }}, extepg:{{ entry.prov_extepg}}{% elif  entry.prov_type == "ctx" %}, vrf/vzany:{{ entry.prov_vrf }}{% endif %}   {% endfor %}{% else %} none {% endif %}|{% if consumer_epg_list|length > 0 %} {% for entry in consumer_epg_list %} **tenant:**{{ entry.cons_tenant }}{% if entry.cons_type == "epg" %}, ap:{{ entry.cons_app_profile }}, epg:{{ entry.cons_epg}}{% elif entry.cons_type == "extepg" %}, l3out:{{ entry.cons_l3out }}, extepg:{{ entry.cons_extepg}}{% elif entry.cons_type == "ctx" %}, vrf/vzany:{{ entry.cons_vrf }}{% endif %}     {% endfor %}{% else %} none {% endif %} | {% if contract_list|length > 1 %} {{contract_list|join(", ")}} {% else %} {{contract_list[0]}} {% endif %} | {% if subj_list|length > 1 %} {{subj_list|join(", ")}} {% else %} {{subj_list[0]}} {% endif %} | {% if filter_list|length > 1 %} {{filter_list|join(", ")}} {% else %} {{filter_list[0]}} {% endif %} |
{% endfor %}



Recommended Next Steps:
Check if the Provider and Consumer EPGs are required to communicate with each other using the identified permit policy.
If connectivity is required, ensure the identified other policy does not override the permit policy.
If connectivity is not required, consider modifying the existing contract or configure a new contract with non overriding policies.


More information about Contract configuration can be found in the [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) Whitepaper on cisco.com


