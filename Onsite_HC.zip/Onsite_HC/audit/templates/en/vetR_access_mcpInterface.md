<!--
category:
  - Best_Practice
severity: notice
affected_count: "{{disabledIntProfs|length}}"
-->

### Mis-cabling Protocol (MCP) - Interface

The mis-cabling protocol (MCP) was designed to handle misconfiguration not detected by Link Layer Discovery Protocol (LLDP) and Spanning Tree Protocol (STP). MCP sends out layer 2 hello packets. If these packets are received on another interface, the ports that form the loop will be disabled.

Faults and events are generated when a port is disabled by MCP. In order to effective must MCP be enabled both globally and on a per-interface basis. The following interfaces has MCP disabled.

Table: Interface Profiles with MCP disabled

| Interface Profiles |
| ---------------------- |
{% for entry in disabledIntProfs %}
| {{ entry }} |
{% endfor %}

Without MCP ACI is at risk of propagating bridging loop behavior due to STP failure or L1 problems. It's, therefore, recommended to configure MCP on all interfaces whenever feasible.

Please ensure your fabric is not running at scale exposed [CSCvx37709](https://bst.cloudapps.cisco.com/bugsearch/bug/CSCvx37709) before considering enabling MCP.

More information about MCP can be found in [ACI Infrastructure Design Guide](https://www.cisco.com/c/en/us/td/docs/dcn/whitepapers/cisco-application-centric-infrastructure-design-guide.html#MiscablingprotocolMCP) on cisco.com.
