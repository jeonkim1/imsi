<!--
category:
  - Best_Practice
severity: warning
affected_count: 1
-->

### IP Aging

IP Aging provides a mechanism to age the IP address of an endpoint separately from a MAC address. Prior to this configuration, if traffic continued to flow from an endpoint (MAC), all IP addresses would be retained indefinitely. With this feature enabled, IP addresses are aged and timed out independently of the parent MAC address. This is an important capability for certain designs, such as load-balancers, where a long-running MAC address may retain many hundreds or even thousands of IP addresses.

It is recommended to enabled IP aging in the ACI fabric.

More information about IP Aging can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html#IPAgingPolicy) available on cisco.com.
