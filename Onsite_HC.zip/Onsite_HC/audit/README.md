# ACI Proactive Audit

The ACI Proactive Audit script can be used to create a WORD document combining findings from ACI vetR and Cisco Network Assurance Engine (NAE).

The script uses a JSON output of ACI vetR and API access to NAE in order to extract the findings from the two tools, and then renderes the report using the text templates located in the `templates` directory.

## Installation

The Python script requires Python 3.x (tested with 3.9.4), and the module dependencies can be installed using pip

```bash
pip install -r requirements.txt
```

While the Python script is used to create the audit report itself, are [Pandoc](https://pandoc.org/) used to convert this document into PDF.

Please reference Pandoc's webpage for details on how to install it if you are using another operating system than MAC. On MAC are the easist way to install it using brew:

```bash
brew install pandoc
```

### Docker Image

In case you run into issues installing the required components on your laptop, then consider running the tool inside a Docker container. In order to do this do you first need to build a container image containing the tool using the `docker build` command.

```sh
docker build -t aci-proactive-audit .
```

Please note that inside the container image are the script, etc. stored in the `/data/aci-proactive-audit/`directory.

## Usage

As mentioned previously does the script generate a Word document combining findings from ACI vetR and Cisco Network Assurance Engine (NAE). At the moment does Word come with two warnings when opening the document, but please click `Yes` to both of them and the document will open successfully.

The script uses a number inputs which can either be provided as command line arguments or provided when the scripts prompts for them. Some of the command line arguments are optional and the script will not prompt for them - these are the ones listed with a default value below.

By default will the script generate reports in English, but if other languages are desired then the language can be controlled using the --language parameter. But in order to benefit from this is it also required to create correspondign templates in the desired language.

```bash
python aci_proactive_audit.py -h
usage: aci_proactive_audit.py [-h] [-e ENGINEER_NAME] [-c CUSTOMER_NAME] [-p PID] [-i VETR_INPUT] [-ssd SSD_INPUT] [-host NAE_HOSTNAME] [-user NAE_USERNAME] [-pass NAE_PASSWORD] [-a NAE_ASSURANCE_GROUP]
                              [--ignore-list AUDIT_IGNORE_LIST] [--warning-list AUDIT_WARNING_LIST] [-o AUDIT_OUTPUT] [--findings_input FINDINGS_INPUT] [--enable_vetr_analysis ENABLE_VETR]
                              [--enable_nae_analysis ENABLE_NAE] [--enable_ssd_analysis ENABLE_SSD] [--language LANGUAGE] [--incognito] [--enable_debug DEBUG] [--tasks TASKS]

This script generates an ACI Proactive Audit Report based on input from ACI vetR and Network Assurance Engine (NAE)

optional arguments:
  -h, --help            show this help message and exit
  -e ENGINEER_NAME, --engineer_name ENGINEER_NAME
                        Name of engineer using the tool
  -c CUSTOMER_NAME, --customer_name CUSTOMER_NAME
                        Name of the customer for which the report is generated
  -p PID, --pid PID     CX Project ID
  -i VETR_INPUT, --input VETR_INPUT
                        ACI vetR output file in JSON format (default: out.json)
  -ssd SSD_INPUT, --ssd_input SSD_INPUT
                        ACI SSD script report file in TXT format ('report-xxxxx.txt')
  -host NAE_HOSTNAME, --hostname NAE_HOSTNAME
                        NAE Hostname
  -user NAE_USERNAME, --username NAE_USERNAME
                        NAE Username
  -pass NAE_PASSWORD, --password NAE_PASSWORD
                        NAE Password
  -a NAE_ASSURANCE_GROUP, --assurance-group NAE_ASSURANCE_GROUP
                        NAE Assurance Group
  --ignore-list AUDIT_IGNORE_LIST
                        Audit Finding Ignore List (default: ignore_findings.yaml)
  --warning-list AUDIT_WARNING_LIST
                        Audit Finding Warning List (default: warning_findings.yaml)
  -o AUDIT_OUTPUT, --output AUDIT_OUTPUT
                        Output File Name (default: aci_audit_output.docx)
  --findings_input FINDINGS_INPUT
                        Input File Name for findings JSON file (default: aci_audit_output.json
  --enable_vetr_analysis ENABLE_VETR
                        Enable Analysis of ACI vetR Output (default: True)
  --enable_nae_analysis ENABLE_NAE
                        Enable Analysis of NAE Smart Events (default: True)
  --enable_ssd_analysis ENABLE_SSD
                        Enable Analysis of NAE Smart Events (default: True)
  --language LANGUAGE   Specify the language the generated report should use (default: en)
  --incognito           Disables submission of tool usage information (NOT RECOMMENDED
  --enable_debug DEBUG  Enable debug logging
  --tasks TASKS         Controls the tasks executed by the script. Supported options are 'get_findings', 'import_findings' 'export_findings' and 'render_report' (default:    ['get_findings',
                        'export_findings'])
```

To excelude findings from the audit report can the name of these be added to the file called `ignore_findings.yaml`, which has a section for each of the two tools. Findings that may indicate an issue during data collection for the tools are listed in the file called `warning_findings.yaml` and are used to print a warning to the user of the tool.

If the scripts finds an exception where there not yet exists a document template, then an error will be written to STDOUT with the name of the template. When adding any mising templates, then it is required to not only add the missing template to the `templates`directory. It is also required to update the template called `main_document` in order to specify where in the audit report the respective template should be added.

As the script runs are the execution log writting both to the console as well as to a file named `execution_log.txt`.

## Template Metadata

In preparation of a future integration into blowtorch are each issue/finding template assigned a classification and severity. This classification and severity are not yet exposed in the rendered document, but may be used in the future.

The classification is based on the one already used by the blowtorch tool:

* Health Check
* Best Practice
* Optimization Opportunities
* Diagnostics Checks
* Audit / FCAP Checks

More inforamtion about the classifications can be found [here](https://cisco.sharepoint.com/:p:/r/sites/Blowtorch/_layouts/15/Doc.aspx?sourcedoc=%7BBC4CD8D9-388C-47B7-80E8-28B2D8CA4C1A%7D&file=Blowtorch-CSS-healthcheck-PS-AuditReports.pptx&action=edit&mobileredirect=true)

The issue/finding severity follows the BORG definitions:

* emergency
* alert
* critical
* error
* warning
* notice
* info
* invisible
* ok

A detailed description of each severity level can be found [here](https://scripts.cisco.com/mamorten/borg_v3/borg_modules.html?highlight=severity#alerts-severity)

## Related Tools

**ACI vetR** (Requires 2.0.0 or later of both the collector AND backend)
Collector: [https://github.com/brightpuddle/vetr-collector/releases/](https://github.com/brightpuddle/vetr-collector/releases/)
Analysis Engine: [https://wwwin-github.cisco.com/AIDE/aci-vetr-healthcheck/releases/](https://wwwin-github.cisco.com/AIDE/aci-vetr-healthcheck/releases/)

Please note that ACI vetR version 2.0 or later are required as vetR did not support JSON output prior to this

## Contacts

If you have questions or comments to the tool, then please reach out to [Morten Skriver](mailto:moskrive@cisco.com)
