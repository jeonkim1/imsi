import pytest

# Added to be able to import files from top folder. Adding top folder to sys path
import sys
import os
from os.path import dirname, abspath

sys.path.append(dirname(dirname(abspath(__file__))))

# Import script being tested
from aci_proactive_audit import *


def test_read_json():
    # Check return of dictionary when provided valid JSON file
    test_file = os.path.join(os.path.dirname(__file__), "valid_json_file.json")
    test_data = read_json(test_file)
    assert type(test_data) == dict

    # Check exit code of 1 if file does not exist
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        read_json("NoneExistingFile.json")
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # Check exit code of 1 if file can not be decoded as JSON
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        test_file = os.path.join(os.path.dirname(__file__), "valid_xml_file.xml")
        read_json(test_file)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1


def test_read_yaml():
    # Check return of directory when provided valid YAML file
    test_file = os.path.join(os.path.dirname(__file__), "valid_yaml_file.yml")
    test_data = read_yaml(test_file)
    assert type(test_data) == dict

    # Check exit code of 1 if file does not exist
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        read_yaml("NoneExistingFile.yml")
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # Check exit code of 1 if file can not be decoded as YAML
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        test_file = os.path.join(os.path.dirname(__file__), "invalid_yaml_file.yml")
        read_yaml(test_file)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1


def test_read_txt():
    # Check return of directory when provided valid TXT file
    test_file = os.path.join(os.path.dirname(__file__), "valid_text_file.txt")
    test_data = read_txt(test_file)
    assert type(test_data) == list

    # Check exit code of 1 if file does not exist
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        read_txt("NoneExistingFile.txt")
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # Check expected content of txt file
    expected_data = [
        "This is a valid text file\n",
        "\n",
        "With three lines, one of them being empty",
    ]
    assert test_data == expected_data


def test_get_template_metadata():
    # Define valid and invalid templates to be used during test
    template_valid = """
    <!--
    category: Healthcheck
    severity: critical
    affected_count: 1
    -->

    ### Dummy Template

    This is a dummy template

    Table: Dummy Template

    | Node | Count |
    | ---- | ----- |
    | abc1 | 1     |
    | def2 | 123   |

    Dummy recommendation
    """

    template_missing_metadata = """
    ### Dummy Template

    This is a dummy template

    Table: Dummy Template

    | Node | Count |
    | ---- | ----- |
    | abc1 | 1     |
    | def2 | 123   |

    Dummy recommendation
    """

    template_malformed_metadata = """
    <!--
    { "category = "Healthcheck",
    severity = "critical",
    affected_count = 1}
    -->

    ### Dummy Template

    This is a dummy template

    Table: Dummy Template

    | Node | Count |
    | ---- | ----- |
    | abc1 | 1     |
    | def2 | 123   |

    Dummy recommendation
    """

    # Check Successful extration of template metadata
    expected_metadata = {
        "category": "Healthcheck",
        "severity": "critical",
        "affected_count": "1",
    }
    successful_metadata_extraction, extracted_metadata = get_template_metadata(
        template_valid, "dymmy_template.md"
    )
    assert successful_metadata_extraction
    assert extracted_metadata == expected_metadata

    # Check Unsuccessful extration of template metadata
    successful_metadata_extraction, extracted_metadata = get_template_metadata(
        template_missing_metadata, "dymmy_template.md"
    )
    assert not successful_metadata_extraction

    # Check extraction of malformed template metadata
    successful_metadata_extraction, extracted_metadata = get_template_metadata(
        template_malformed_metadata, "dymmy_template.md"
    )
    assert not successful_metadata_extraction


def test_vetr_check_dataformat():
    # Define variables to be used during test
    vetr_2_0_0_format = {
        "meta": {"foo": "bar"},
        "firmware": [],
        "admin": "foobar",
        "fabricStats": [1, 2, 3],
        "eol": "",
        "epLoopProtection": "",
        "rogueEPControl": [],
        "ipAging": [],
        "remoteEPlearning": [],
        "enforceSubnetCheck": "",
        "portTracking": {"foo": []},
        "coopStrict": [],
        "bfdFabricInt": [],
        "domainValidation": [],
        "mcp": [],
        "dom": [],
        "multipod": [],
        "isisMetric": "",
        "tenantStats": "",
        "bdStats": 2,
        "ingressPolicyEnforcement": [],
        "vzAny": [],
        "l3outRedundancy": [],
        "scale": [],
        "health": [],
        "ssd": [],
    }
    vetr_2_0_0_format_missing_key = {
        "meta": {"foo": "bar"},
        "firmware": [],
        "admin": "foobar",
        "fabricStats": [1, 2, 3],
        "eol": "",
        "epLoopProtection": "",
        "rogueEPControl": [],
        "invalid_key": [],
        "remoteEPlearning": [],
        "enforceSubnetCheck": "",
        "portTracking": {"foo": []},
        "coopStrict": [],
        "bfdFabricInt": [],
        "domainValidation": [],
        "mcp": [],
        "dom": [],
        "multipod": [],
        "isisMetric": "",
        "tenantStats": "",
        "bdStats": 2,
        "ingressPolicyEnforcement": [],
        "vzAny": [],
        "l3outRedundancy": [],
        "scale": [],
        "health": [],
        "ssd": [],
    }
    vetr_2_0_8_format = {
        "meta": {"foo": "bar"},
        "stats": [],
        "apic": "foobar",
        "system": {"foo": [1, 2, 3]},
        "faults": [],
        "tenant": [],
        "health": [],
        "fabric": [],
        "access": [],
        "admin": "foobar",
        "apps": [],
        "scale": [],
        "eol": [],
    }
    vetr_2_0_8_format_missing_key = {
        "meta": {"foo": "bar"},
        "stats": [],
        "apic": "foobar",
        "system": {"foo": [1, 2, 3]},
        "faults": [],
        "invalid_key": [],
        "health": [],
        "fabric": [],
        "access": [],
        "admin": "foobar",
        "apps": [],
        "scale": [],
        "eol": [],
    }
    vetr_unrecognized_format = {"foo": "foobar", "bar": [1, 2, 3, 4]}

    # Check valid vetR 2.0.0 format
    version = vetr_check_dataformat(vetr_2_0_0_format)
    assert version == "dataformat_2_0_0"

    # Check invalid vetR 2.0.0 format
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        version = vetr_check_dataformat(vetr_2_0_0_format_missing_key)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # Check valid vetR 2.0.8 format
    version = vetr_check_dataformat(vetr_2_0_8_format)
    assert version == "dataformat_2_0_8"

    # Check invalid vetR 2.0.8 format
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        version = vetr_check_dataformat(vetr_2_0_8_format_missing_key)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # Check invalid vetR 2.0.8 format
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        version = vetr_check_dataformat(vetr_2_0_8_format_missing_key)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # Check invalid vetR format
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        version = vetr_check_dataformat(vetr_unrecognized_format)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1


def test_vetr_analyse_output():
    # Check return of directory when provided valid vetR file
    test_file = os.path.join(os.path.dirname(__file__), "valid_vetR_output.json")
    test_data = vetr_analyse_output(test_file)
    assert type(test_data) == dict
