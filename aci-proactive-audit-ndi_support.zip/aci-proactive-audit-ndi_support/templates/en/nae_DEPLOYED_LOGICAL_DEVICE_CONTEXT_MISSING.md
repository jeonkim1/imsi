<!--
category:
  - Optimization
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Deployed Logical Device Context is Missing


A deployed graph instance was found but it has no device selection policy configured.
Traffic will not be redirected to the service node.

Table: Deployed Graph Instance(s) with Missing Device Context

{% if data_source == "ndi" %}
| Tenant | Service Graph |
| ------ | ----------------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "deviceSelectionPolicy" -%}
            {%- set _=table.__setitem__("tenant",object.objectValue[0].split("/")[1].replace("tn-","")) -%}
            {%- set _=table.__setitem__("service_graph", object.objectValue[0].split("-G-")[1].split("-S-")[0].split("/")[-1].replace("]","")) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.service_graph}} |
{% endfor %}
{% else %}
| Tenant | Device Selection Policy |
| ------ | ----------------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 487 -%}
            {% set _=table.__setitem__("device_selection_policy", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.device_selection_policy}} |
{% endfor %}
{% endif %}

Suggested Next steps:

If the Service Graph is intended to be used, the Device Selection Policy must be configured. Please refer to [ Selecting a L4-L7 Device to Render a Graph ](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-4-to-layer-7-services-configuration/cisco-apic-layer-4-to-layer-7-services-deployment-guide-52x/selecting-a-layer-4-to-layer-7-device-to-render-a-graph-52x.html) in the [Cisco APIC Layer 4 to Layer 7 Services Deployment Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-4-to-layer-7-services-configuration/cisco-apic-layer-4-to-layer-7-services-deployment-guide-52x.html)

