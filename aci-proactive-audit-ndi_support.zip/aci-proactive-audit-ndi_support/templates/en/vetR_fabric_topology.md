<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
{% set count = namespace(value = 0) %}
{% for leaf in leafLinks %}
    {% if leafLinks[leaf]|length < 2 %}
        {% set count.value = count.value + 1 %}
    {% endif %}
{% endfor %}
affected_count: {{count.value}}
-->

### Fabric Topology - No Uplink Redundancy

The following leaf(s) has are attached to a single spine and therefore does not have uplink redundancy.

Table: Leaf(s) without Uplink Redundancy

| Leaf Node ID | Attached Spine Node ID |
| ------------ | ---------------------- |
{% for leaf in leafLinks %}
{% if leafLinks[leaf]|length < 2 %}
| {{ leaf }} | {{leafLinks[leaf]|join(", ")}} |
{% endif %}
{% endfor %}

It is highly recommended to connect all leaf(s) to two or more spine switches.

More information about the supported physical topologies in Cisco ACI can be found in the [ACI Design Guide](https://www.cisco.com/c/en/us/td/docs/dcn/whitepapers/cisco-application-centric-infrastructure-design-guide.html) on cisco.com.
