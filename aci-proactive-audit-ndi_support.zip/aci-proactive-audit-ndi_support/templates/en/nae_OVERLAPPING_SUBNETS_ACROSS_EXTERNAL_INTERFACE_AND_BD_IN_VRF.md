<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->


#### Overlapping Subnets Across External Interfaces and Bridge Domain in same VRF

The aggregate list of subnets configured across bridge domains in a given VRF are overlapping with the IP address(es) configured on L3Out external interfaces such as Loopback, routed interface, routed sub-interface, or SVI.

The impact is that Sub-optimal routing may result due to overlapping IP addresses, and next-hop resolution for one or more routes may fail.

Table: BD Subnets that Overlap with External Interfaces

{% if data_source == "ndi" %}
| Tenant | VRF | BD | BD Subnet, Ext Interface Subnets | L3Out | Nodes |
| ------ |---- | -- | -------------------------------- | ----- | ----- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bds", object.objectValue) %}
        {%- elif object.objectType == "subnet" -%}
            {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3Outs", object.objectValue) %}
        {%- elif object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leafs", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.bds|join(", ")}} | {{table.subnet|join(", ")}} | {{table.l3Outs|join(", ")}} | {{table.leafs|join(", ")}} |
{% endfor %}
{% else %}
| Tenant | VRF | BD | BD Subnet, Ext Interface Subnets | L3Out | Nodes |
| ------ |---- | -- | -------------------------------- | ----- | ----- |
{% for item in event_list %}
{% set table = dict() %}
{% set subnet_list = []%}
{% set leaf_list = []%}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object_type.code == 253 -%}
                {% set _=subnet_list.append(object.name) %}

            {%- elif object_type.code == 3 -%}
                {% set _=table.__setitem__("bd", object.name) %}

            {%- elif object_type.code == 28 -%}
                {% set _=table.__setitem__("l3out", object.name) %}

            {%- elif object_type.code == 384 -%}
                {% set _=leaf_list.append(object.name) %}

            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}

| {{table.tenant}} | {{table.vrf}} | {{ table.bd }} | {% if subnet_list|length > 1 %} {{subnet_list|join(", ")}} {% else %} {{subnet_list[0]}} {% endif %} | {{table.l3out}} |  {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

Suggested Next Steps:
1. Ensure that IP addresses across all loopbacks, routed interfaces, routed sub-interfaces and/or SVIs within an L3Out, and the aggregate of all subnets across BDs/EPGs attached to the same VRF are unique.
2. Determine which one of the BDs/EPGs/L3Outs should have the subnet and modify the other BDs/EPGs/L3Out Interfaces to eliminate the overlap.


More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
