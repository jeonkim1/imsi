<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
affected_count: 1
-->

### APIC Cluster Health

The APIC cluster are not fully fit, which may indicate an issue with one or more APICs are an issue with the cluster synchronization.

It is recommended to investigate why the cluster is not fully fit and if an apparent reason can not be found, then it is recommended to open a TAC case.

More information about how to troubleshoot can be found in the [Cisco ACI Troubleshooting Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/troubleshooting/Cisco-APIC-Troubleshooting-Guide-42x.html) available on cisco.com.
