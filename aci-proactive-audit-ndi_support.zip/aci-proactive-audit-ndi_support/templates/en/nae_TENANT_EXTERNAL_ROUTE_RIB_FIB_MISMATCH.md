<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Tenant External Route RIB FIB Mismatch

The Routing Information Base (RIB) and Forwarding Information Base (FIB) should be in sync with respect to the contents of the routing table at any point in time. The routes identified below are inconsistently programmed on the leaf switch(s) referenced below.
End points may experience intermittent or complete loss of connectivity to the external routes in question on the switch(s) referenced.


Table: External Routes with RIB and FIB Mismatch and Impacted Node

{% if data_source == "ndi" %}
| Route | Tenant | VRF |
| ----- | ------ | --- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "route" -%}
            {%- set _=table.__setitem__("route", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "tenants" -%}
            {% set _=table.__setitem__("tenants", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.route|join(", ")}} | {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} |
{% endfor %}
{% else %}
| Route | Tenant | VRF | Node(s) |
| ----- | ------ | --- |-------- |
{% for item in event_list %}
{% set table = dict() %}
{% set leaf_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 254 -%}
                {% set _=table.__setitem__("route", object.name) %}
            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}
            {%- elif object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}
            {%- elif object_type.code == 384 -%}
                    {% set _=leaf_list.append(object.name) %}
            {%- elif object_type.code == 28 -%}
                {% set _=table.__setitem__("l3out", object.name) %}
           {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{table.route}} | {{table.tenant}} | {{table.vrf}} | {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

It is recommended to collect a techsupport from this leaf switch(s) and contact Cisco TAC for assistance with the root cause of the problem before any potential corrective action is performed.
If current impact on connectivity is severe, a clean reload of the switch in question may clear the issue. Use caution when performing this step as other EPGs may be affected. Ensure all documentation has been collected beforehand in order for Root Cause Analysis to be performed.

