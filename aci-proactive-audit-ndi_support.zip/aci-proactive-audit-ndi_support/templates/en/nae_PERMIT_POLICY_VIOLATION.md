<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Permit Policy Violation.

Permit action for a contract between EPG pairs has not been enforced on a leaf. This could be due to a rule not being present or a higher priority stale rule.
The impact is that permit traffic will be denied on the leaf in violation of policy.

Table: Leaf Switches with permit policy violation.

{% if data_source == "ndi" %}
| Provider Tenant | Provider EPG | Consumer Tenant | Consumer EPG | Contract | Subject | Filter | Leaf |
| --------------- | ------------ | --------------- | ------------ | -------- | ------- | ------ | ---- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "providerEpgs" -%}
            {%- set _=table.__setitem__("providerEpgs", object.objectValue) -%}
        {%- elif object.objectType == "consumerEpgs" -%}
            {% set _=table.__setitem__("consumerEpgs", object.objectValue) %}
        {%- elif object.objectType == "providerTenants" -%}
            {% set _=table.__setitem__("providerTenants", object.objectValue) %}
        {%- elif object.objectType == "consumerTenants" -%}
            {% set _=table.__setitem__("consumerTenants", object.objectValue) %}
        {%- elif object.objectType == "contracts" -%}
            {% set _=table.__setitem__("contracts", object.objectValue) %}
        {%- elif object.objectType == "subjects" -%}
            {% set _=table.__setitem__("subjects", object.objectValue) %}
        {%- elif object.objectType == "filters" -%}
            {% set _=table.__setitem__("filters", object.objectValue) %}
        {%- elif object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leafs", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.providerTenants|join(", ")}} |{{table.providerEpgs|join(", ")}} | {{table.consumerTenants|join(", ")}} | {{table.consumerEpgs|join(", ")}} | {{table.contracts|join(", ")}} | {{table.subjects|join(", ")}} | {{table.filters|join(", ")}} | {{table.leafs|join(", ")}} |
{% endfor %}
{% else %}
| Consumer | Provider | Contract | Subject | Filter | Leaf |
| -------- | -------- |----------| ------- | ------ | ---- |
{% for item in event_list %}
{% set node_list = [] %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- for codes in object.object_types -%}
            {%- if codes.code == 16 -%}
                {% set consumer_components = object.identifier.split("/") %}
                {% set _=table.__setitem__("cons_tenant", consumer_components[1][3:]) %}
                {%- if consumer_components[2][0:3] == "out" -%}
                    {% set _=table.__setitem__("cons_type", "extepg") %}
                    {% set _=table.__setitem__("cons_l3out", consumer_components[2][4:]) %}
                    {% set _=table.__setitem__("cons_extepg", consumer_components[3][6:]) %}
                {%- elif consumer_components[2][0:2] == "ap" -%}
                    {% set _=table.__setitem__("cons_type", "epg") %}
                    {% set _=table.__setitem__("cons_app_profile", consumer_components[2][3:]) %}
                    {% set _=table.__setitem__("cons_epg", consumer_components[3][4:]) %}
                {%- elif consumer_components[2][0:3] == "ctx" -%}
                    {% set _=table.__setitem__("cons_type", "ctx") %}
                    {% set _=table.__setitem__("cons_vrf", consumer_components[2][4:]) %}
                {%- endif -%}
            {%- elif codes.code == 11 -%}
                {% set provider_components = object.identifier.split("/") %}
                {% set _=table.__setitem__("prov_tenant", provider_components[1][3:]) %}
                {%- if provider_components[2][0:3] == "out" -%}
                    {% set _=table.__setitem__("prov_type", "extepg") %}
                    {% set _=table.__setitem__("prov_l3out", provider_components[2][4:]) %}
                    {% set _=table.__setitem__("prov_extepg", provider_components[3][6:]) %}
                {%- elif provider_components[2][0:2] == "ap" -%}
                    {% set _=table.__setitem__("prov_type", "epg") %}
                    {% set _=table.__setitem__("prov_app_profile", provider_components[2][3:]) %}
                    {% set _=table.__setitem__("prov_epg", provider_components[3][4:]) %}
                {%- elif provider_components[2][0:3] == "ctx" -%}
                    {% set _=table.__setitem__("prov_type", "ctx") %}
                    {% set _=table.__setitem__("prov_vrf", provider_components[2][4:]) %}
                {%- endif -%}
            {%- elif codes.code == 21 -%}
                {% set _=table.__setitem__("filter", object.name) %}

            {%- elif codes.code == 19 -%}
                {% set _=table.__setitem__("contract", object.name) %}

            {%- elif codes.code == 20 -%}
                {% set _=table.__setitem__("subj", object.name) %}

            {%- elif codes.code == 384 -%}
                {% set _=node_list.append(object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| tenant:{{ table.cons_tenant }}{% if table.cons_type == "epg" %}, ap:{{ table.cons_app_profile }}, epg:{{ table.cons_epg}}{% elif table.cons_type == "extepg" %}, l3out:{{ table.cons_l3out }},extepg:{{ table.cons_extepg}}{% elif  table.cons_type == "ctx" %}, vrf/vzany:{{ table.cons_vrf }}{% endif %}| tenant:{{ table.prov_tenant }}{% if table.prov_type == "epg" %}, ap:{{ table.prov_app_profile }}, epg:{{ table.prov_epg}}{% elif table.prov_type == "extepg" %}, l3out:{{ table.prov_l3out }}, extepg:{{ table.prov_extepg}}{% elif  table.prov_type == "ctx" %}, vrf/vzany:{{ table.prov_vrf }} {% endif %} | {{ table.contract }} | {{ table.subj }} | {{ table.filter }}| {% if node_list|length > 1 %} {{node_list|join(", ")}} {% else %} {{node_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

It is recommended to investigate why APIC Policy and Switch Configuration are not matching on Leaf and fix the condition.

For more information on contract rule programming, refer to 'Security Policy chapter in the [Troubleshooting Cisco Application Centric Infrastructure](https://www.cisco.com/c/dam/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/troubleshooting/Cisco_TroubleshootingApplicationCentricInfrastructureSecondEdition.pdf)