<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### VLAN of deployed Device cluster interface not deployed



The cluster interface is deployed, but its VLAN is not deployed correctly to the physical interface.
The service graph won’t behave as expected.

Table: Device Clusters VLANs not deployed correctly.

{% if data_source == "ndi" %}
| Device Cluster Interface |
| ------------------------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "deviceClusterInterface" -%}
            {%- set _=table.__setitem__("deviceClusterInterface", object.objectValue) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.deviceClusterInterface|join(", ")}} |
{% endfor %}
{% else %}
| Tenant | Device Cluster | Device Cluster Interface | Leaf | Interface | VLAN |
| ------ | -------------- | ------------------------ | ---- | --------- | ---- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 486 -%}
            {% set _=table.__setitem__("device_cluster", object.name) %}
        {%- elif object.object_types[0].code == 490 -%}
            {% set _=table.__setitem__("device_cluster_intf", object.name) %}
        {%- elif object.object_types[0].code == 384 -%}
            {% set _=table.__setitem__("leaf", object.name) %}
        {%- elif object.object_types[0].code == 233 -%}
            {% set _=table.__setitem__("interface", object.name) %}
                    {%- elif object.object_types[0].code == 310 -%}
            {% set _=table.__setitem__("vlan", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.device_cluster}} | {{table.device_cluster_intf}} | {{table.leaf}} | {{table.interface}} | {{table.vlan}} |
{% endfor %}
{% endif %}

There are two failing conditions related to this event:

* The VLAN is not deployed.
* The VLAN is deployed on the expected physical interface, but is used by a different EPG.

Suggested Next steps:
Check for any other deployment related issues.
Redeploy the Service Graph.

More information about service graphs configuration can be found in the [Cisco APIC Layer 4 to Layer 7 Services Deployment Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-4-to-layer-7-services-configuration/cisco-apic-layer-4-to-layer-7-services-deployment-guide-52x.html)