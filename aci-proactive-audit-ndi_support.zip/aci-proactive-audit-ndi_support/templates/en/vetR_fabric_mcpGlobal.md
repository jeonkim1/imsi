<!--
category:
  - Best_Practice
severity: notice
affected_count: 1
-->

### Mis-cabling Protocol (MCP) - Global

The mis-cabling protocol (MCP) was designed to handle misconfiguration not detected by Link Layer Discovery Protocol (LLDP) and Spanning Tree Protocol (STP). MCP sends out layer 2 hello packets. If these packets are received on another interface, the ports that form the loop will be disabled.

Faults and events are generated when a port is disabled by MCP. MCP can be enabled globally and per-interface. By default, MCP is disabled globally and is enabled on each port. For MCP to work, it must be enabled globally, regardless of the per-interface configuration.

It is recommended to enable MCP Globally, but prior to doing this is it important to verify if the fabric potentially are affected by [CSCvn04432](https://bst.cloudapps.cisco.com/bugsearch/bug/CSCvn04432) or not. If potentially affected, then it is recommended to wait with enabling MCP globally until the fabric has been upgraded to a version not affected by this bug.

More information about MCP can be found in [ACI Infrastructure Design Guide](https://www.cisco.com/c/en/us/td/docs/dcn/whitepapers/cisco-application-centric-infrastructure-design-guide.html#MiscablingprotocolMCP) on cisco.com.
