<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
affected_count: "{{event_list|length}}"
-->

#### Policy Based Redirect (PBR) EP learning enabled
Starting with APIC release 3.1, endpoint learning is automatically disabled for Service EPGs. However, the corresponding flags are not programmed.
Endpoints from the provider or consumer EPG may incorrectly be learned under the service EPG.

Table: Service EPGs with EP learning enabled

| Tenant | Bridge Domain | Service EPG |
| ------ | ------------- | ----------- |
{% for item in event_list %}
{% set table = dict() %}
{% set ep_ip_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("shadow_epg", object.name) %}
         {%- elif object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 3 -%}
            {% set _=table.__setitem__("bd", object.name) %}

        {%- endif -%}
            
    {%- endfor -%}

| {{table.tenant}} | {{table.bd}} | {{table.shadow_epg}} |
{% endfor %}

Recommended next steps are as follow:
For service chains created with APIC releases prior to 3.1:

* Navigate to the bridge domain of the service EPG
* Disable endpoint learning from that BD.

For service chains created with later APIC releases:

* Redeploy the Service Chain
* If failure persists, contact TAC


More information about PBR service graph can be found in the [Cisco ACI Policy-Based Redirect Service Graph Design White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739971.html)