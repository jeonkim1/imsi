<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### External Routes have Policy L3Out different from Exit L3Out

The following external route(s) has its policy/contract relationship defined on a L3Out different than the L3Out used to exit the fabric. This may occur when multiple L3Out's are associated with the same VRF and in particular when dynamic routing is used on these L3Out's, as the external route may be learnt on different connection than the one used to define the policy/contract relationship.

As a result of the identified issue, communication to/from these external route(s) can be affected by unintentional policy change on one L3Out affecting other L3Out.

Table: External Routes with Policy L3Out different from Exit L3Out

{% if data_source == "ndi" %}
| Tenant | VRF | Route | Policy L3Out | Exit L3Out |
| ------ | --- | ----- | ------------ | ---------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "l3Outs" -%}
            {%- set _=table.__setitem__("l3Outs", object.objectValue) -%}

        {%- endif -%}
    {%- endfor -%}
|  | | | {{table.l3Outs|join(", ")}} | |
{% endfor %}
{% else %}
| Tenant | VRF | Route | Policy L3Out | Exit L3Out |
| ------ | --- | ----- | ------------ | ---------- |
{% for item in event_list %}
{% set table = dict() %}
{% set route_list = []%}
    {% if item[0].object_types[0].code == 28 -%}
        {% set _=table.__setitem__("policy_l3out", item[0].name) %}
    {% endif %}
    {% if item[3].object_types[0].code == 28 -%}
        {% set _=table.__setitem__("exit_l3out", item[3].name) %}
    {% endif %}

    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object_type.code == 254 -%}
                {% set _=route_list.append(object.name) %}

            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}

| {{table.tenant}} | {{table.vrf }} | {% if route_list|length > 1 %} {{route_list|join(", ")}} {% else %} {{route_list[0]}} {% endif %} | {{table.policy_l3out}} | {{table.exit_l3out}} |
{% endfor %}
{% endif %}

It is recommended to verify the configuration of the mentioned L3Outs to see if any obvious misconfiguration can be found. If this is not the case, then it is recommended to open a TAC case in order to investigate the issue further.

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
