<!--
category:
  - Best_Practice
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### AAEP not associated with any domains

The following AAEPs are not associated with any domains, which could indicate that they are not in used.

Table: AAEP not associated with any domains

{% if data_source == "ndi" %}
| AAEP Name |
| ------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "attachableAccessEntityProfiles" -%}
            {%- set _=table.__setitem__("aaep", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
{% if table.aaep != "default" %}
| {{table.aaep}} |
{% endif %}
{% endfor %}
{% else %}
| AAEP Name |
| ------ |
{% for aaep in event_list %}
{% if aaep.0.name != "default" %}
| {{aaep.0.name}} |
{% endif %}
{% endfor %}
{% endif %}

If these AAEPs are not in use, then it is recommended to remove them in order to simplify the configuration.

More information about AAEP configuration can be found in the [Cisco APIC Layer 2 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_011.html) on cisco.com.
