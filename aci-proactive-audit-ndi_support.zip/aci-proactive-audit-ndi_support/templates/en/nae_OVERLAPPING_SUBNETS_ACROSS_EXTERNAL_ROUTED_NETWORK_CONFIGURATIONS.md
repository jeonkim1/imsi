<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Overlapping Subnets between L3Out Interfaces and across L3Outs in same VRF



Communication between the following EPGs below are failing due to overlapping subnets. This subnet overlap is caused by a route learned thorough a L3Out to overlap with a BD subnet that are leaked between VRFs.

Table: Overlapping Subnets between Bridge Domain (Route Leaking) and Learned Routes across VRFs

{% if data_source == "ndi" %}
| Subnet | Tenant | VRF | L3out(s) | Nodes |
| ------ |------- | --- | -------- | ----- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "subnet" -%}
            {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3Outs", object.objectValue) %}
        {%- elif object.objectType == "leafs" -%}
            {% set _=table.__setitem__("leafs", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.subnet|join(", ")}} | {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.l3Outs|join(", ")}} | {{table.leafs|join(", ")}} |
{% endfor %}
{% else %}
| Subnet | Tenant | VRF | L3out(s) | Nodes |
| ------ |------- | --- | -------- | ----- |
{% for item in event_list %}
{% set table = dict() %}
{% set l3out_list = []%}
{% set leaf_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}
            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}
            {%- elif object_type.code == 28 -%}
                {% set _=l3out_list.append(object.name) %}
            {%- elif object_type.code == 253 -%}
                {% set _=table.__setitem__("subnet", object.name) %}
            {%- elif object_type.code == 384 -%}
                {% set _=leaf_list.append(object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}

| {{table.subnet}} | {{table.tenant}} | {{table.vrf}} | {% if l3out_list|length > 1 %} {{l3out_list|join(", ")}} {% else %} {{l3out_list[0]}} {% endif %} | {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

The following next steps are suggested in order to resolve this issue.

1. Ensure that IP addresses across all loopbacks, routed interfaces, routed sub-interfaces and/or SVIs within one or more L3Outs, attached to the same VRF are unique
2. Determine which one of the L3Out interfaces should have the subnet and modify the respective L3Out + Node Profile + Interface Profile combinations to eliminate the overlap

More information about L3Out Configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
