<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### EPG has invalid Bridge Domain

The EPG is associated to a BD that no longer exists. This BD may have been deleted.

Table: EPGs with invalid BD associated.
{% if data_source == "ndi" %}

| Tenant | Application Profile | EPG | Bridge Domain |
| ------ | ------------------- |---- | ------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epg", object.objectValue[0]) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bds", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants}} | {{table.ap}} | {{table.epg}} | {{table.bds}} |
{% endfor %}
{% else %}

| EPG | Tenant | Application Profile | Bridge Domain |
| --- | ------ | ------------------- | ------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 7 -%}
            {% set _=table.__setitem__("epg", object.name) %}
        {%- elif object.object_types[0].code == 8 -%}
            {% set _=table.__setitem__("app_profile", object.name) %}
        {%- elif object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 3 -%}
            {% set _=table.__setitem__("bd", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{ table.epg }} | {{ table.tenant }} | {{ table.app_profile }} | {{ table.bd }} |
{% endfor %}
{%- endif -%}

It is recommended to determine if the BD deletion was intentional.
If this is the case, it is recommended to associate the EPG with a valid BD, or un-provision the EPG as well if needed.

More information about BD subnet configuration can be found in the [Cisco ACI Layer-3 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/L3-configuration/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401_chapter_01001.html) on cisco.com
