<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
affected_count: "{{vlans|length}}"
-->

### APIC Infrastructure VLAN Consistency

The APIC cluster are configured with an inconsistent infrastructure VLAN across the different cluster members.

Table: Infrastructure VLANs used in APIC cluster

| VLAN |
| ---- |
{% for entry in vlans %}
| {{entry}} |
{% endfor %}

It is recommended to investigate and correct the inconsistent infrastructure VLAN configuration in the APIC cluster.

More information about Infrastructure VLAN can be found in the [Cisco ACI Getting Started Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/getting-started/Cisco-APIC-Getting-Started-Guide-421/b-Cisco-APIC-Getting-Started-Guide-421_chapter_010.html) available on cisco.com.
