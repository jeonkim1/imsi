<!--
category:
  - Healthcheck
  - Upgradecheck
severity: notice
affected_count: "{{overlappingSubnets|length}}"
-->

### L3Out Overlapping Subnets

The following BD/EPGs and L3Out are configured with overlapping subnets. This may indicate a configuration mistake, although this may also be valid configuration depending on the implemented design.

Table: L3Out Overlapping Subnets

| Tenant / BD or AP/EPG | Tenant / L3Out |
| --------------------- | -------------- |
{% for entry in overlappingSubnets %}
{% set bd_list = entry.epgOrBDdn.split('/') %}
{% set bd_tenant = bd_list[1].split('-') %}
{% set bd_name = bd_list[2].split('-') %}
{% set epg_name = bd_list[3].split('-') %}
{% set l3out_list = entry.l3outDN.split('/') %}
{% set l3out_tenant = l3out_list[1].split('-') %}
{% set l3out_name = l3out_list[2].split('-') %}
| {{bd_tenant[1]}} / {% if bd_name[0]|upper == "BD" %}{{bd_name[1]}} ({{bd_name[0]|upper}}){% else %}{{bd_name[1]}} ({{bd_name[0]|upper}}) / {{epg_name[1]}} ({{epg_name[0]|upper}}){% endif %} | {{l3out_tenant[1]}} / {{l3out_name[1]}} |
{% endfor %}

It is recommended to review the configuration of these BD/EPGs and L3Outs to assess whether this is a configuration mistake or not.

Please reference the [Cisco APIC Basic Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/basic-configuration/Cisco-APIC-Basic-Configuration-Guide-401/Cisco-APIC-Basic-Configuration-Guide-401_chapter_0110.html) for information about how to configure Tenants in ACI.
