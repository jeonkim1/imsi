<!--
category:
  - Best_Practice
  - Upgradecheck
capacity: Limit
severity: warning
affected_count: 1
-->

### Tenant Scalability

One or more of the tenants defined in the ACI fabric are exceeding the supported scalability limits.

Table: Tenant Scalability

|Tenant | VRF count | BD count | Contract count | EPG count | L3out count |
| ----- | --------- | -------- | -------------- | --------- | ----------- |
{% for entry in statsByTenant %}
| {{entry}} | {{statsByTenant[entry].vrfCount}} | {{statsByTenant[entry].bdCount}} | {{statsByTenant[entry].contractCount}} | {{statsByTenant[entry].epgCount}} | {{statsByTenant[entry].l3outCount}} |
{% endfor %}

More information about ACI scalability can be found in the section "Verified Scalability Guide" on the [Cisco ACI Support Page](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/tsd-products-support-series-home.html) on cisco.com.
