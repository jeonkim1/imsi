<!--
category:
  - Healthcheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Used Leaf PC Interface in Admin Down, Operationally Down

Port-Channel has EPG(s) attached but the Port Channel has been disabled. Reachability to End Points in End Point Groups deployed on this set of interfaces will be impacted.

Table: Configured Leaf PC Interface in Admin Down and in Use by EPG.

{% if data_source == "ndi" %}
| Interface Policy Group | Leaf |
| ---------------------- | -----|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "interfacePolicyGroups" -%}
            {%- set _=table.__setitem__("interfacePolicyGroup", object.objectValue[0]) -%}
        {%- elif object.objectType == "leafs" -%}
                {% set _=table.__setitem__("leaf", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.interfacePolicyGroup}} | {{table.leaf}} |
{% endfor %}
{% else %}
| Leaf | PC Interface Policy Group | Associated AAP | Member Interface |
| ---- | --------------------------| ---------------| ---------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 384 -%}
            {% set _=table.__setitem__("leaf", object.name) %}
        {%- elif object.object_types[0].code == 244 -%}
            {% set _=table.__setitem__("pc_ipg", object.name) %}
        {%- elif object.object_types[0].code == 237 -%}
            {% set _=table.__setitem__("aap", object.name) %}
        {%- elif object.object_types[0].code == 233 -%}
            {% set _=interface_list.append(object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leaf}} | {{table.pc_ipg}} | {{table.aap}} |{% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

If these port-channels are supposed to be in use, then it is recommended to administratively enable them.
If the port-channels are not supposed to be use, please detach the EPG static binding.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)