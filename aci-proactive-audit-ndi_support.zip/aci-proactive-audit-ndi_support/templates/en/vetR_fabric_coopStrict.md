<!--
category:
  - Best_Practice
severity: notice
affected_count: 1
-->

### COOP Authentication

Council of Oracle Protocol (COOP) is used to communicate the mapping information (location and identity) to the spine proxy. A leaf switch forwards endpoint address information to the spine switch 'Oracle' using Zero Message Queue (ZMQ). COOP running on the spine nodes will ensure all spine nodes maintain a consistent copy of endpoint address and location information and additionally maintain the distributed hash table (DHT) repository of endpoint identity to location mapping database.

COOP data path communication provides high priority to transport using secured connections. COOP is enhanced to leverage the MD5 option to protect COOP messages from malicious traffic injection. The APIC controller and switches support COOP protocol authentication.

COOP protocol is enhanced to support two ZMQ authentication modes: strict and compatible.

* Strict mode: COOP allows MD5 authenticated ZMQ connections only.
* Compatible mode: COOP accepts both MD5 authenticated and non-authenticated ZMQ connections for message transportation.

COOP strict mode protects against certain exploits that take advantage of the spine accepting unauthenticated updates.

The fabric is currently **not** using COPP strict mode and it is recommended to evaluate the usage of this.

More information about COOP can be found in the [ACI Security Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/security/b-Cisco-APIC-Security-Configuration-Guide-421/b-Cisco-APIC-Security-Configuration-Guide-421_chapter_01000.html?bookSearch=true) on cisco.com.
