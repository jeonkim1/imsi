<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Endpoint IP learned Outside Bridge Domain Subnet

A number of endpoints has been learned with an IP address that falls outside the Bridge Domain Subnet(s). This means that the endpoints may not be able to communicate outside the layer-2 domain.

Table: Endpoint IP learned Outside Bridge Domain Subnet

| Leaf(s) | EP MAC | EP IP | Tenant | VRF | BD | EPG | Interface |
| ------------- | ------ | ----- | ------ | --- | -- | --- | --------- |
{% if data_source == "ndi" %}
{% for item in event_list %}
{% set table = dict() %}
{% set leaf_list = [] %}
{% set interface_list = [] %}
{% set ep_mac_list = [] %}
{% set ep_ip_list = [] %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "vrfs" -%}
            {%- set _=table.__setitem__("vrf", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "bds" -%}
            {%- set _=table.__setitem__("bd", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "subnet" -%}
            {%- set _=table.__setitem__("subnet", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "leafs" -%}
            {% for leaf in object.objectValue %}
                {% set _=leaf_list.append(leaf) %}
            {% endfor %}
        {%- endif -%}
        {%- if object.objectType == "macs" -%}
            {% for mac in object.objectValue %}
                {% set _=ep_mac_list.append(mac) %}
            {% endfor %}
        {%- endif -%}
        {%- if object.objectType == "ips" -%}
            {% for ip in object.objectValue %}
                {% set _=ep_ip_list.append(ip) %}
            {% endfor %}
        {%- endif -%}
        {%- if object.objectType == "epgs" -%}
            {%- set _=table.__setitem__("epg", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "interfaces" -%}
            {% for if in object.objectValue %}
                {% set _=interface_list.append(if) %}
            {% endfor %}
        {%- endif -%}
    {%- endfor -%}
| {{leaf_list|join(", ")}} | {{ep_mac_list|join(", ")}} | {{ ep_ip_list|join(", ") }} | {{table.tenant}} | {{table.vrf}} | {{table.bd}} | {{table.epg}} | {{interface_list|join(", ")}} |
{% endfor %}
{% else %}
{% for item in event_list %}
{% set table = dict() %}
{% set leaf_list = []%}
{% set interface_list = []%}
{% set ep_mac_list = []%}
{% set ep_ip_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 2 -%}
                {% set _=table.__setitem__("tenant", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set _=table.__setitem__("vrf", object.name) %}

            {%- elif object_type.code == 3 -%}
                {% set _=table.__setitem__("bd", object.name) %}

            {%- elif object_type.code == 304 -%}
                {% set _=ep_mac_list.append(object.name) %}

            {%- elif object_type.code == 327 -%}
                {% set _=ep_ip_list.append(object.name) %}

            {%- elif object_type.code == 7 -%}
                {% set _=table.__setitem__("epg", object.name) %}

            {%- elif object_type.code == 384 -%}
                {% set _=leaf_list.append(object.name) %}

            {%- elif object_type.code == 233 -%}
                {% set interface_components = object.identifier.split("/") %}
                {% set interface_node = " (" ~ interface_components[2] ~ ")" %}
                {% set _=interface_list.append(object.name ~ interface_node) %}

            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} | {% if ep_mac_list|length > 1 %}{{ ep_mac_list.join(", ") }}{% else %} {{ep_mac_list[0]}} {% endif %} | {% if ep_ip_list|length > 1 %}{{ ep_ip_list|join(", ") }} {% else %} {{ep_ip_list[0]}} {% endif %} | {{table.tenant}} | {{table.vrf}} | {{table.bd}} | {{table.epg}} | {% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

It is recommended to use the following steps to investigate the Endpoint learning issue:

1. Check the Endpoint configuration for correct IP address, mask, and default-gateway configuration
2. Check the right Path Binding, VLAN encapsulation, EPG, and BD assignment
3. If the Endpoint is configured correctly, consider enabling "Limit IP Learning for Subnet" under the BD

More information about Endpoint learning can be found in the [ACI Fabric Endpoint Learning White Paper](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/white-paper-c11-739989.html) available on cisco.com.
