<!--
category:
  - Healthcheck
severity: warning
affected_count: "{{event_list|length}}"
-->

#### Fabric Endpoint with Self-Assigned IP Address

A number of fabric endpoints have a self-assigned IP address (RFC 3927), which usually occurs on DHCP failures. This may lead to the Endpoint(s) being unable to communicate outside the Layer-2 domain.

Table: Fabric Endpoint with Self-Assigned IP Address

| End Point | Tenant | VRF | BD | vlan | L3Out | Leaf(s) | Interface |
| --------- | ------ | --- | -- | ---- | ----- | ------- | --------- |
{% for item in event_list %}
{% set table = dict() %}
{% set ep_list = [] %}
{% set leaf_list = [] %}
{% set interface_list = [] %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}

        {%- elif object.object_types[0].code == 3 -%}
            {% set _=table.__setitem__("bd", object.name) %}
        {%- elif object.object_types[0].code == 3001 -%}
            {% set _=table.__setitem__("vlan", object.name) %}
        {%- elif object.object_types[0].code == 327 -%}
            {% set _=ep_list.append(object.name) %}
        {%- elif object.object_types[0].code == 304 -%}
            {% set _=ep_list.append(object.name) %}    
        {%- elif object.object_types[0].code == 28 -%}
            {% set _=table.__setitem__("l3out", object.name) %}
        {%- elif object.object_types[0].code == 1 or object.object_types[0].code == 384 -%}
            {% set _=leaf_list.append(object.name) %}
        {%- elif object.object_types[0].code == 233 -%}
            {% set interface_components = object.identifier.split("/") %}
            {% set interface_node = " (" ~ interface_components[2] ~ ")" %}
            {% set _=interface_list.append(object.name ~ interface_node) %}

        {%- endif -%}
            
    {%- endfor -%}
| {% if ep_list|length > 1 %} {{ep_list|join(", ")}} {% else %} {{ep_list[0]}} {% endif %} | {{table.tenant}} | {{table.vrf}} | {% if table.bd is defined %}{{ table.bd }}{% else %} - {% endif %} | {% if table.vlan is defined %}{{ table.vlan }}{% else %} - {% endif %}| {% if table.l3out is defined %} {{ table.l3out }} {% else %} - {% endif %} |  {% if leaf_list|length > 1 %} {{leaf_list|join(", ")}} {% else %} {{leaf_list[0]}} {% endif %} | {% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %} |
{% endfor %}

It is recommended to open a TAC case to investigate the issue.

ACI nodes receives TEP addresses via DHCP from APIC. For more information about you can refer to the Fabric Discovery Section in the [Troubleshooting Application Centric Infrastructure](https://www.cisco.com/c/dam/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/troubleshooting/Cisco_TroubleshootingApplicationCentricInfrastructureSecondEdition.pdf) available on cisco.com.
