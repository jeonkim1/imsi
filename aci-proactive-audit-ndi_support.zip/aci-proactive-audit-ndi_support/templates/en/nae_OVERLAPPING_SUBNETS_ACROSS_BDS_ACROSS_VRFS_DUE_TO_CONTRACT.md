<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Overlapping subnets have been configured on Provider and Consumer BD/EPG’s across VRF

Communication between EPGs across VRFs is failing due to overlapping subnet address.
The failing condition is that Provider BD/EPG’s subnet or Consumer BD/EPG’s subnet are not unique across both VRF’s.
Overlapping subnet configuration is causing intermittent connectivity problem between Provider and Consumer EPGs.

Table below gives the list of overlapping subnets.
In order to also capture other relevant information (Tenant, Application Profile, EPG type, etc.), the List of EPGs and BDs are given in Distinguished Name (DN) format.

Table: Overlapping Subnets.

{% if data_source == "ndi" %}
| Subnets | VRFs  | List of EPG (dn) | List of BD (dn) | Contract  |
| ------  | ----- | ---------------- | --------------- |---------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue[0]) %}
        {%- elif object.objectType == "epgs" -%}
            {% set _=table.__setitem__("epgs", object.objectValue) %}
        {%- elif object.objectType == "bds" -%}
            {% set _=table.__setitem__("bds", object.objectValue) %}
        {%- elif object.objectType == "contracts" -%}
                {% set _=table.__setitem__("contracts", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
{% endfor %}
| {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.epgs|join(", ")}} | {{table.bds|join(", ")}} | {{table.contracts|join(", ")}} |
{% else %}
| Subnets | VRFs  | List of EPG (dn) | List of BD (dn) | Contract  |
| ------  | ----- | ---------------- | --------------- |---------- |
{% for item in event_list %}
{% set sub_list = [] %}
{% set vrf_list = [] %}
{% set epg_list = [] %}
{% set bd_list = [] %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 253 -%}
        {% set _=sub_list.append(object.name) %}
        {%- elif object.object_types[0].code == 4 -%}
            {% set _=vrf_list.append(object.name) %}
        {%- elif object.object_types[0].code == 3 -%}
            {% set _=bd_list.append(object.identifier) %}
        {%- elif object.object_types[0].code == 7 -%}
            {% set _=epg_list.append(object.identifier) %}
        {%- elif object.object_types[0].code == 19 -%}
            {% set _=table.__setitem__("contract", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {% if sub_list|length==0 %} none {% elif sub_list|length > 1 %} {{sub_list|join(", ")}} {% else %} {{sub_list[0]}} {% endif %} | {% if vrf_list|length==0 %} none {% elif vrf_list|length > 1 %} {{vrf_list|join(", ")}} {% else %} {{vrf_list[0]}} {% endif %} | {% if epg_list|length==0 %} none {% elif epg_list|length > 1 %} {{epg_list|join(", ")}} {% else %} {{epg_list[0]}} {% endif %} | {% if bd_list|length==0 %} none {% elif bd_list|length > 1 %} {{bd_list|join(", ")}} {% else %} {{bd_list[0]}} {% endif %} |{{table.contract}}|
{% endfor %}
{% endif %}


Suggested Next Steps:

* Check if Provider and Consumer EPGs are required to communicate with each other using the listed contract.
* If connectivity is required ensure Provider EPG's BD subnet or Consumer EPG's BD subnet are unique across the VRFs.
* If connectivity is not required, determine if you can remove the consumer side of the imported contract relationship.

More information about BD subnet configuration can be found in the [Cisco ACI Layer-3 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/L3-configuration/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401/Cisco-APIC-Layer-3-Networking-Configuration-Guide-401_chapter_01001.html) on cisco.com

More information about Contract configuration can be found in the [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) Whitepaper on cisco.com