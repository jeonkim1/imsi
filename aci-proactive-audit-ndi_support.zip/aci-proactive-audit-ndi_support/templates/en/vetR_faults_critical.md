<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
{% set count = namespace(value = 0) %}
{% for entry in faults %}
{% set count.value = count.value + faults[entry]|length %}
{% endfor %}
affected_count: {{count.value}}
-->

### Critical Faults

The following critical faults has been raised in the ACI fabric.

Table: Critical Faults

| Fault | Description |
| ------- | ------------ |
{% for entry in faults %}
{% if faults[entry]|length > 1%}
{% for instance in faults[entry] %}
| {{entry}} | {{instance.descr}} |
{% endfor %}
{% else %}
| {{entry}} | {{faults[entry].0.descr}} |
{% endif %}
{% endfor %}

It is recommended to investigate the root cause for these faults and if an apparent reason cannot be found, then it is recommended to open a TAC case.

More information about how to troubleshoot can be found in the [Cisco ACI Troubleshooting Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/troubleshooting/Cisco-APIC-Troubleshooting-Guide-42x.html) available on cisco.com.
