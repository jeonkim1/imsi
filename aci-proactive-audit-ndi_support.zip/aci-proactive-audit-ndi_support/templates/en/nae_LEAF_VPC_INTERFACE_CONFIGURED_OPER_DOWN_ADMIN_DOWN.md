<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### vPC Interface configured to be ready to be consumed by EPG is in admin down

Virtual Port-Channel is configured by Fabric Admin to be ready for EPG consumption but the VPC has been disabled.

Table: Disabled Leaf vPC Interface Policy Groups Configured to be Ready for EPG Consumption

{% if data_source == "ndi" %}
| vPC Interface Policy Group |
| -------------------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "interfacePolicyGroups" -%}
            {%- set _=table.__setitem__("interfacePolicyGroups", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.interfacePolicyGroups}} | | | | |
{% endfor %}
{% else %}
| vPC Interface Policy Group | vPC Leaf 1 | vPC Leaf 2 | Associated AAP | Member Interface |
| -------------------------- | -----------| -----------| -------------- | ---------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set node_list = []%}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 384 -%}
            {% set _=node_list.append(object.name) %}

        {%- elif object.object_types[0].code == 244 -%}
            {% set _=table.__setitem__("pc_ipg", object.name) %}

        {%- elif object.object_types[0].code == 237 -%}
            {% set _=table.__setitem__("aap", object.name) %}

        {%- elif object.object_types[0].code == 233 -%}
            {% set interface_components = object.identifier.split("/") %}
            {% set interface_node = " (" ~ interface_components[2] ~ ")" %}
            {% set _=interface_list.append(object.name ~ interface_node) %}

        {%- endif -%}


    {%- endfor -%}
| {{table.pc_ipg}} | {{node_list[0]}} | {{node_list[1]}} | {{table.aap}} |{% if interface_list|length > 1 %} {{interface_list|join(", ")}} {% else %} {{interface_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

Sugested Next Steps:

Determine if the interface(s) in question are configured with the right set of fabric access policies.
If not, delete the interface(s) from the access-policies to clear the condition.
If yes, then admin enable this interface.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-2-configuration/cisco-apic-layer-2-networking-configuration-guide-52x/access-interfaces-52x.html)
