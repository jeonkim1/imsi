<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
affected_count: 1
-->

### Firmware Version

The software versions for Cisco Application Centric Infrastructure (ACI) are listed in the major.minor(maintenance) format:

- major - Represents major changes in the product architecture, platform, or features content
- minor - Represents a minor release with new software features
- maintenance - Represents bug fixes to a feature release of Application Policy Infrastructure Controller (APIC). This changes when there are fixes for product defects in the software, but no additional new features

In an ACI fabric are there two main components that can be upgraded:

- Switches (leaf and spine)
- Application Policy Infrastructure Controller (APIC)

The table below lists the lowest software version each component is running.

Table: Firmware Versions

| APIC version (lowest)| Spine/Leaf version (lowest) |
| -------------------- | --------------------------- |
| {{ apicVersion }}    | {{ switchVersion }}         |

In normal operation is it recommended that the APIC controllers and the Spine/Leaf switches run the same software version.

More information about Firmware management and how to upgrade an ACI fabric can be found in the [Operating Cisco ACI](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/1-x/Operating_ACI/guide/b_Cisco_Operating_ACI/b_Cisco_Operating_ACI_chapter_0101.html) as well as in the [Cisco ACI Upgrade Checklist](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/kb/Cisco-ACI-Upgrade-Checklist.html), both available on cisco.com.
