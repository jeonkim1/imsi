<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Enforced VRF with policy violations

VRF is in enforced mode, but APIC policy for implicit deny is not enforced on Leaf hardware.
When VRF is in enforced mode, ACI does not allow any communication between two EPGs, unless there is a contract between these two EPGs.
To enforce this, ACI creates a rule with a low priority that denies traffic from any source to any destination.
The enforced VRF policy violation is raised if there is an unexpected higher priority rule installed in TCAM that cannot be correlated to a configured contract.
APIC Policy and Switch Configuration are not matching on Leaf.
In this condition unauthorized traffic may be allowed in this VRF.

Table: Leaf Switches with policy violation.

{% if data_source == "ndi" %}
| Tenant | VRF | Leaf |
| ------ | --- |------|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "leafs" -%}
                {% set _=table.__setitem__("leafs", object.objectValue[0]) %}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrfs}} | {{table.leafs}} |
{% endfor %}
{% else %}
| Tenant | VRF | Leaf |
| ------ | --- |------|
{% for item in event_list %}
{% set node_list = [] %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}

        {%- elif object.object_types[0].code == 384 -%}
            {% set _=table.__setitem__("node", object.name) %}
            {% set _=node_list.append({"leaf": table.node}) %}
        {%- endif -%}
    {%- endfor -%}
    {% for node in node_list %}
        | {{ table.tenant }} | {{ table.vrf }} | {{ node.leaf }} |
    {% endfor %}
{% endfor %}
{% endif %}
Please note that if the VRFs are configured with a "permit any" contract, then this may lead to false positives.

It is recommended to investigate why APIC Policy and Switch Configuration are not matching on Leaf and fix the condition.

For more information on contract rule programming, refer to 'Security Policy chapter in the [Troubleshooting Cisco Application Centric Infrastructure](https://www.cisco.com/c/dam/en/us/td/docs/switches/datacenter/aci/apic/sw/4-x/troubleshooting/Cisco_TroubleshootingApplicationCentricInfrastructureSecondEdition.pdf)
