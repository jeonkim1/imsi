<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Overlapping Subnets Across External Learnt Routes and External Interfaces across VRFs

Communication between EPGs across VRFs is failing due to overlapping subnet address.
Static route and external interface subnets are not unique across both VRF’s.

The impact is that overlapping subnet configuration is causing intermittent connectivity problem between Provider and Consumer EPGs

Table: Overlapping Subnets and Impacted EPGs

{% if data_source == "ndi" %}
| Subnet | Tenants | VRFs |
| ------ | ------- | ---- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {% set _=table.__setitem__("vrfs", object.objectValue) %}
        {%- elif object.objectType == "subnet" -%}
            {% set _=table.__setitem__("subnet", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.subnet|join(", ")}} | {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} |
{% endfor %}
{% else %}
| Subnet | Leaked_in Tenant/VRF | EPGs | Contract | Leaked_from Tenant/VRF | L3out | ExtEPG |
| ------ | -------------------- | ---- | -------- | ---------------------- | ----- | ------ |
{% for item in event_list %}
{% set table = dict() %}
{% set tenant_list = []%}
{% set vrf_list = []%}
{% set epg_list = []%}
{% set leaf_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 253 -%}
                {% set _=table.__setitem__("subnet", object.name) %}

            {%- elif object_type.code == 4 -%}
                {% set vrf_components = object.identifier.split("/") %}
                {% set _=tenant_list.append(vrf_components[1][3:]) %}
                {% set _=vrf_list.append(vrf_components[2][4:]) %}

            {%- elif object_type.code == 19 -%}
                {% set _=table.__setitem__("contract", object.name) %}

            {%- elif object_type.code == 28 -%}
                {% set _=table.__setitem__("l3out", object.name) %}

            {%- elif object_type.code == 7 -%}
            {% set epg_components = object.identifier.split("/") %}
                {%- if epg_components[2][0:2] == "ap" -%}
                    {% set _=epg_list.append(object.name) %}
                {%- elif epg_components[2][0:3] == "out" -%}
                    {% set _=table.__setitem__("extepg", epg_components[3][6:]) %}
                {%- elif epg_components[2][0:3] == "ctx" -%}
                    {% set _=epg_list.append(object.name) %}
                {%- endif -%}

            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}

    {%- for epg in epg_list -%}
| {{table.subnet}} | {{tenant_list[0]}}/{{vrf_list[0]}} | {{epg}} |  {{table.contract}} | {{tenant_list[1]}}/{{vrf_list[1]}} | {{table.l3out}} | {{table.extepg}} |
{% endfor %}
{% endfor %}
{% endif %}

Suggested next steps:

1. Check if the L3Out and EPGs are required to communicate with each other using the listed contracts.
2. If connectivity is required, ensure that the L3Out interface are unique across the VRFs.
3. If connectivity is not required, determine if you can remove the consumer (not the provider) side of the imported contract relationship


More information about L3Out configuration can be found in the [ACI L3 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/l3-configuration/cisco-apic-layer-3-networking-configuration-guide-52x.html) and in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com
