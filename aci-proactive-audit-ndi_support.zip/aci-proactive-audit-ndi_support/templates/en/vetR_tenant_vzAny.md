<!--
category:
  - Optimization
severity: notice
affected_count: "{{contracts|length}}"
-->

### Opportunities to use vzAny

vzAny is a special object in Cisco ACI that represents all EPGs associated with a given VRF instance, including the Layer 3 external EPG.

This concept is useful when a configuration has contract rules that are common across all the EPGs under the same VRF. In this case, you can place the rules that are common across the VRF into a contract associated with vzAny.

One common use of the vzAny object relates to consumption of the same set of shared services provided by an EPG in a different VRF. vzAny can only be a consumer of shared services, not a provider. By using vzAny is it possible to reduce the TCAM usage in the leaf nodes significantly.

The following contracts are consumed by all EPGs in the mentioned VRF, which could indicate that the contract instead could be consumed as a vzAny contract.

Table: Opportunities to use vzAny

| Tenant | VRF | Contract |
| ------ | --- | -------- |
{% for entry in contracts %}
| {{entry.tenant}} | {{entry.vrf}} | {{entry.contract}} |
{% endfor %}

It is recommended to review the usage of the contracts listed above and evaluate if vzAny could be used to simplify the configuration and reduce TCAM consumption.

More information about vzAny can be found in the [Cisco ACI Design Guide](https://www.cisco.com/c/en/us/td/docs/dcn/whitepapers/cisco-application-centric-infrastructure-design-guide.html) on cisco.com.
