<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Bridge Domain with Subnet has Unicast Routing Disabled

The following bridge domain(s) are configured with a subnet, but unicast routing is not enabled. As unicast routing is disabled will the ACI fabric not route traffic to/from this bridge domain.

Table: Bridge Domain with Subnet has Unicast Routing Disabled

| Tenant | Bridge Domain | Subnet |Associated VRF |
| ------ | ------------- | ------ | -------------- |
{% if data_source == "ndi" %}
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "vrfs" -%}
            {%- set _=table.__setitem__("vrf", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "bds" -%}
            {%- set _=table.__setitem__("bd", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "subnet" -%}
            {%- set _=table.__setitem__("subnet", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.bd}} | {{table.subnet}} | {{table.vrf}} |
{% endfor %}
{% else %}
{% for bd in event_list %}
| {{bd.2.name}} | {{bd.3.name}} | {{bd.0.name}} | {{bd.1.name}} |
{% endfor %}
{% endif %}

It is recommended to review and modify the configuration of these bridge domain(s), by either removing the subnet or enable unicast routing, as the current configuration is invalid.

More information about Bridge Domain configuration can be found in the [Cisco API Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_010.html)
