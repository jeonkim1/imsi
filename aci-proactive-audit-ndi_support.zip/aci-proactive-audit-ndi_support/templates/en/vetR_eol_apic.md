<!--
category:
  - Best_Practice
  - Upgradecheck
severity: notice
{% set count = namespace(value = 0) %}
{% if state.hasM1L1 == True %}
{% set count.value = count.value + 1 %}
{% endif %}
{% if state.hasM2L2 == True%}
{% set count.value = count.value + 1 %}
{% endif %}
affected_count: {{count.value}}
-->

### APIC Refresh

One or more of the APICs used in the fabric are affected by an End of Life announce (EoL).

Table: APIC End-of-Life

| APIC Model |EoL Date | EoL URL |
| ---------- | --------------------- | -------------------- |
{% if state.hasM1L1 == True %}
| M1 and/or L1  | {{m1l1Notice.announcementDate}} | [{{m1l1Notice.url}}]({{m1l1Notice.url}}) |
{% endif %}
{% if state.hasM2L2 == True%}
| M2 and/or L2  | {{m2l2Notice.announcementDate}} | [{{m2l2Notice.url}}]({{m2l2Notice.url}}) |
{% endif %}

It is recommended to include the APICs in upcoming life cycle management activities.
