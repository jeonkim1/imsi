<!--
category:
  - Healthcheck
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Used Leaf Interface in Admin Down (shutdown)

The following Leaf interface is in use by EPGs and is Admin Down (shutdown).

Table: Configured Leaf Interface in Admin Down (shutdown)

{% if data_source == "ndi" %}
| Leaf | Interface |
| ---- | --------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "leafs" -%}
            {%- set _=table.__setitem__("leafs", object.objectValue[0]) -%}
        {%- elif object.objectType == "interfaces" -%}
                {% set _=table.__setitem__("interfaces", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.leafs}} | {{table.interfaces}} |
{% endfor %}
{% else %}
| Leaf | Interface | Associated Interface Policy Group | Associated Interface Profile | Associated AAEP |
| ---- | --------- | --------------------------------- | ---------------------------- | --------------- |
{% for item in event_list %}
{% set table = dict() %}
{% set node_list = []%}
{% set interface_list = []%}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 384 -%}
                {% set _=table.__setitem__("leaf", object.name) %}
            {%- elif object.object_types[0].code == 233 -%}
                {% set _=table.__setitem__("interface", object.name) %}
            {%- elif object.object_types[0].code == 234 -%}
                {% set _=table.__setitem__("interface_profile", object.name) %}
            {%- elif object.object_types[0].code == 244 -%}
                {% set _=table.__setitem__("interface_policy_group", object.name) %}
            {%- elif object.object_types[0].code == 237 -%}
                {% set _=table.__setitem__("aap", object.name) %}
            {%- endif -%}
        {%- endfor -%}
    {%- endfor -%}
| {{table.leaf}} | {{table.interface}} | {{table.interface_policy_group}} | {{table.interface_profile}} | {{table.aap}} |
{% endfor %}
{% endif %}

If interfaces are supposed to be in use, then it is recommended to investigate why they are Admin Down / Shutdown.
If these interfaces are not supposed to be used, then it is recommended to detach the EPG static binding.

More information about interface configuration can be found in the [Cisco ACI Layer 2 Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_0100.html)
