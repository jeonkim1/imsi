<!--
category:
  - Best_Practice
severity: notice
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Application Profile has no EPG

The following Application Profile has no EPGs which may indicate a misconfiguration.

Table: Application Profile with no EPGs

{% if data_source == "ndi" %}
| Tenant | Application Profile |
| ------ | ------------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "appProfiles" -%}
                {% set _=table.__setitem__("ap", object.objectValue[0]) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.ap}} |
{% endfor %}
{% else %}
| Tenant | Application Profile |
| ------ | ------------------- |
{% for app in event_list %}
| {{app.1.name}} | {{app.0.name}} |
{% endfor %}
{% endif %}

It is recommended to review the configuration of these application profiles to check if the configuration of one or more EPGs has been omitted by mistake.

More information about tenant configuration can be found in the [Cisco APIC Basic Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/3-x/basic_config/b_APIC_Basic_Config_Guide_3_x/b_APIC_Basic_Config_Guide_3_x_chapter_0101.html)
