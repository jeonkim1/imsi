<!--
category:
  - Healthcheck
  - Upgradecheck
severity: critical
{% set count = namespace(value = 0) %}
{% for fault, node_list in faults.items() %}
    {% for node in node_list %}
        {% set count.value = count.value + 1 %}
    {% endfor %}
{% endfor %}
affected_count: {{count.value}}
-->

### APIC and Switch SSD (fault based findings)

{% if state.apicFaultCount > 0 and state.switchFaultCount > 0 %}
The one or more of the APICs and switches in the fabric are affected by SSD fault(s).
{% elif state.apicFaultCount > 0 %}
The one or more of the APICs in the fabric are affected by SSD fault(s).
{% elif state.switchFaultCount > 0 %}
The one or more of the switches in the fabric are affected by SSD fault(s).
{% endif %}

Table: Nodes with SSD faults

| POD | Node | Fault | Description |
| --- | ---- | ----- | ----------- |
{% for fault, node_list in faults.items() %}
    {% for node in node_list %}
    {% set node_components = node.dn.split("/") %}
| {{node_components[1]}} | {{node_components[2]}} | {{fault}} | {{node.descr}} |
    {% endfor %}
{% endfor %}

It is recommended to open a TAC case in order to investigate fault(s) and possible RMA the affected devices.

More information about SSD faults in ACI can be found in [Field Notice - 70538](https://www.cisco.com/c/en/us/support/docs/field-notices/705/fn70538.html) and the [ACI Switch Node SSD Lifetime Explained](https://www.cisco.com/c/en/us/support/docs/software/aci-data-center/215167-aci-switch-node-ssd-lifetime-explained.html) TechNote both available on cisco.com.
