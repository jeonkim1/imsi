<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Device cluster has no interfaces

The following device cluster(s) has no interfaces defined.

Table: Device Cluster has no interfaces

{% if data_source == "ndi" %}
| Tenant | Device Cluster |
| ------ | ---------------|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "deviceCluster" -%}
            {%- set _=table.__setitem__("deviceCluster", object.objectValue[0]) -%}

        {%- endif -%}
    {%- endfor -%}
| | {{table.deviceCluster}} |
{% endfor %}
{% else %}
| Tenant | Device Cluster |
| ------ | ---------------|
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}

        {%- elif object.object_types[0].code == 486 -%}
            {% set _=table.__setitem__("device_cluster", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.device_cluster}} |
{% endfor %}
{% endif %}
It is recommended to assess why the device cluster does not have any interfaces defined.
If the device cluster is not needed, it is recommended to un-provision it.

More information about service graphs configuration can be found in the [Cisco APIC Layer 4 to Layer 7 Services Deployment Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-4-to-layer-7-services-configuration/cisco-apic-layer-4-to-layer-7-services-deployment-guide-52x.html)