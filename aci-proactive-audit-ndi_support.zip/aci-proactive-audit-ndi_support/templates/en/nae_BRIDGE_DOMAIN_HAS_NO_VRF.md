<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Bridge Domain has no VRF

The following Bridge Domain(s) are not associated with a VRF, which results in Layer-3 forwarding from these Bridge Domains (BD) to other BDs or other VRFs will not work. Contracts with the EPGs associated with these BDs may not get pushed to the leafs and even if pushed traffic may not flow across the contract if the EPGs are in two separate BDs where one of the BDs has no VRF.

Table: Bridge Domain has no VRF

| Tenant | Bridge Domain |
| ------ |-------------- |
{% if data_source == "ndi" %}
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- endif -%}
        {%- if object.objectType == "bds" -%}
            {%- set _=table.__setitem__("bd", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.bd}} |
{% endfor %}
{% else %}
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- for object_type in object.object_types -%}
            {%- if object_type.code == 3 -%}
                {% set bd_components = object.identifier.split("/") %}
                {% set _=table.__setitem__("bd", object.name) %}
                {%- if bd_components[1][0:3] == "tn-" -%}
                    {% set _=table.__setitem__("tenant", bd_components[1][3:]) %}
                {%- else -%}
                    {% set _=table.__setitem__("tenant", "") %}
                {%- endif -%}

            {%- endif -%}
        {%- endfor -%}

    {%- endfor -%}
| {{table.tenant}} | {{table.bd}} |
{% endfor %}
{% endif %}

If these Bridge Domain(s) are supposed to be used, then it is recommended to associate them with the correct VRF. If they are not supposed to be used, then it is recommended to remove the Bridge Domain(s) to simplify the configuration.

More information about bridge domain configuration can be found in the [Cisco ACI Layer 2 Networking Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/L2_config/b_Cisco_APIC_Layer_2_Configuration_Guide/b_Cisco_APIC_Layer_2_Configuration_Guide_chapter_010.html) on cisco.com.
