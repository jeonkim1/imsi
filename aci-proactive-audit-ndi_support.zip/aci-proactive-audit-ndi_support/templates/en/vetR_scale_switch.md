<!--
category:
  - Best_Practice
  - Upgradecheck
capacity: Limit
severity: warning
affected_count: 1
-->

### Switch Scalability

One or more of the switches are exceeding the supported scalability limits.

Table: Switch Scalability

| Switch | Count / Limit | VLANs | VRFs | BDs | EPGs | TCAM | L2 Endpoints (total / local / remote) | L3 Endpoints (total / local / remote) |
| ------ | ------------- | ----- |----- | --- | ---- | ---- | ------------------------------------- | ------------------------------------- |
{% for entry in metrics %}
| {{entry.name}} | Count | {{entry.vlans.count}} | {{entry.vrfs.count}} | {{entry.bds.count}} | {{entry.epgs.count}} | {{entry.tcam.count}} | {{entry.l2Total.count}} / {{entry.l2Local.count}} / {{entry.l2Remote.count}} | {{entry.l3Total.count}} / {{entry.l3Local.count}} / {{entry.l3Remote.count}} |
{% endfor %}

More information about ACI scalability can be found in the section "Verified Scalability Guide" on the [Cisco ACI Support Page](https://www.cisco.com/c/en/us/support/cloud-systems-management/application-policy-infrastructure-controller-apic/tsd-products-support-series-home.html) on cisco.com.
