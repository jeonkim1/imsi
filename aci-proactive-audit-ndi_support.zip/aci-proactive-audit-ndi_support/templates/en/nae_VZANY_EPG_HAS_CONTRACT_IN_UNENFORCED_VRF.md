<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### VzAny EPG has a Contract in Unenforced VRF

VzAny is providing or consuming a contract but the VRF is not in enforced mode.
EPGs configured under this VRF will pass traffic that may be unintended.

Table: Unenforced VRF with vzAny Contract

{% if data_source == "ndi" %}
| Tenant | VRF | EPG | Contract(s) |
| ------ | --- | --- | ----------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenants", object.objectValue) -%}
        {%- elif object.objectType == "vrfs" -%}
            {%- set _=table.__setitem__("vrfs", object.objectValue) -%}
        {%- elif object.objectType == "epgs" -%}
            {%- set _=table.__setitem__("epgs", object.objectValue) -%}
        {%- elif object.objectType == "contracts" -%}
            {%- set _=table.__setitem__("contracts", object.objectValue) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenants|join(", ")}} | {{table.vrfs|join(", ")}} | {{table.epgs|join(", ")}} | {{table.contracts|join(", ")}} |
{% endfor %}
{% else %}
| Tenant | VRF | Contract(s) |
| ------ | --- | ----------- |
{% for item in event_list %}
{% set table = dict() %}
{% set contract_list = [] %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 19 -%}
            {% set _=contract_list.append(object.name) %}
        {%- elif object.object_types[0].code == 4 -%}
            {% set _=table.__setitem__("vrf", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{ table.tenant }} | {{ table.vrf }} | {% if contract_list|length > 1 %} {{contract_list|join(", ")}} {% else %} {{contract_list[0]}} {% endif %} |
{% endfor %}
{% endif %}

If it is intended to have VRF in unenforced mode, please disassociate the contract from the Collection of EPGs under the VRF (vzAny).
Any EPG in VRF in Unenforced mode will pass traffic.


More information on Contracts and VRF in unenforced mode can be found in [Cisco ACI Contract Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/cisco-aci-contract-guide-wp.html) Whitepaper on cisco.com