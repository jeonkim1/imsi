<!--
category:
  - Healthcheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### Logical Interface has no Concrete Interface Association


The logical interface is not associated with a concrete interface.
The following logical interfaces have no concrete interfaces associated.

Table: Logical Interfaces with no Concrete Interface Association

{% if data_source == "ndi" %}
| Device Cluster Interface |
| ------------------------ |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "deviceClusterInterface" -%}
            {%- set _=table.__setitem__("deviceClusterInterface", object.objectValue[0]) -%}
        {%- endif -%}
    {%- endfor -%}
| {{table.deviceClusterInterface}} |
{% endfor %}
{% else %}
| Tenant | Device Cluster | Logical Interface |
| ------ | -------------- | ----------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.object_types[0].code == 2 -%}
            {% set _=table.__setitem__("tenant", object.name) %}
        {%- elif object.object_types[0].code == 486 -%}
            {% set _=table.__setitem__("device_cluster", object.name) %}
        {%- elif object.object_types[0].code == 490 -%}
            {% set _=table.__setitem__("logical_interface", object.name) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.device_cluster}} | {{table.logical_interface}} |
{% endfor %}
{% endif %}

Suggested Next Steps:

* Navigate to the specified device cluster.
* Go to the specified logical interface.
* Add a concrete interface.

More information about service graphs configuration can be found in the [Cisco APIC Layer 4 to Layer 7 Services Deployment Guide](https://www.cisco.com/c/en/us/td/docs/dcn/aci/apic/5x/layer-4-to-layer-7-services-configuration/cisco-apic-layer-4-to-layer-7-services-deployment-guide-52x.html)
