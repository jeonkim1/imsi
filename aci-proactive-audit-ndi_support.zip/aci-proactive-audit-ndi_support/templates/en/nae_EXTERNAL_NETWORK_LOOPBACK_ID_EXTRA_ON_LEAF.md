<!--
category:
  - Healthcheck
  - Upgradecheck
severity: warning
ndi_support: True
affected_count: "{{event_list|length}}"
-->

#### External Network Loopback ID is Also Found in Routing Table of Other Leaf


A loopback IP address that is configured on APIC for border leaf, or a set of border leafs, is also found in the routing table of other leaf(s).
If the IP address in question is configured on other entities, routing issues may result as a result of the extra information present in the routing table of the border leaf.

Table: Loopback IP Addresses Impacted
{% if data_source == "ndi" %}

| Tenant | VRF | L3Out | Loopback | Impacted Leaf |
| ------ |---- | ----- | -------- | ------------- |
{% for item in event_list %}
{% set table = dict() %}
    {%- for object in item -%}
        {%- if object.objectType == "tenants" -%}
            {%- set _=table.__setitem__("tenant", object.objectValue[0]) -%}
        {%- elif object.objectType == "vrfs" -%}
                {% set _=table.__setitem__("vrf", object.objectValue[0]) %}
        {%- elif object.objectType == "l3Outs" -%}
            {% set _=table.__setitem__("l3out", object.objectValue[0]) %}
        {%- elif object.objectType == "subnet" -%}
                {% set _=table.__setitem__("subnet", object.objectValue[0]) %}
        {%- elif object.objectType == "leafs" -%}
                {% set _=table.__setitem__("leaf", object.objectValue) %}
        {%- endif -%}
    {%- endfor -%}
| {{table.tenant}} | {{table.vrf}} | {{table.l3out}} | {{table.subnet}} | {% if table.leaf|length > 1 %} {{table.leaf|join(", ")}} {% elif table.leaf|length == 1 %}  %} {{table.leaf[0]}} {% else %} n/a {% endif %}  |
{% endfor %}
{% else %}

| Loopback | Tenant | VRF | L3Out | L3Out Node |
| -------- | ------ |---- | ----- | ---------- |
{% for item in event_list %}
    {% set table =dict() %}
    {% for object in item %}
        {% if object.object_types[0].code == 253 %}
            {% set _=table.__setitem__("loopback", object.name) %}
        {% elif object.object_types[0].code == 384 or object.object_types[0].code == 1%}
            {% set _=table.__setitem__("node", object.name) %}
        {% elif object.object_types[0].code == 2 %}
            {% set _=table.__setitem__("tenant", object.name) %}
        {% elif object.object_types[0].code == 4 %}
            {% set _=table.__setitem__("vrf", object.name) %}
        {% elif object.object_types[0].code == 28 %}
            {% set _=table.__setitem__("l3out", object.name) %}
        {% endif %}
    {% endfor %}
|{{ table.loopback }}| {{table.tenant}} | {{table.vrf}} | {{table.l3out}} | {{table.node}} |
{% endfor %}
{% endif %}

It is recommended to collect a techsupport from the affected leaf switch and contact Cisco TAC for assistance with root causing the issue.

More information about L3Out configuration can be found in the [ACI Fabric L3Out Configuration Guide](https://www.cisco.com/c/en/us/solutions/collateral/data-center-virtualization/application-centric-infrastructure/guide-c07-743150.html) on cisco.com.


